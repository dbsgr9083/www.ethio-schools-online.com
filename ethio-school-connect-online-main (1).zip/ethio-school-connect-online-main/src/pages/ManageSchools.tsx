
import React, { useState, useEffect } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from "@/components/ui/table";
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { toast } from 'sonner';
import { School, Users, User, Trash2, Eye, Search, RefreshCw } from 'lucide-react';
import Header from '@/components/Header';
import { v4 as uuidv4 } from 'uuid';

const ManageSchools = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const [schools, setSchools] = useState<any[]>([]);
  const [selectedSchool, setSelectedSchool] = useState<any>(null);
  const [isDetailsOpen, setIsDetailsOpen] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [isResetDialogOpen, setIsResetDialogOpen] = useState(false);
  const [newPassword, setNewPassword] = useState('');

  useEffect(() => {
    // Load schools from localStorage
    loadSchools();
    
    // Check if there's an ID in the query params
    const params = new URLSearchParams(location.search);
    const schoolId = params.get('id');
    
    if (schoolId) {
      const schoolsString = localStorage.getItem('schoolRegistrations');
      if (schoolsString) {
        const allSchools = JSON.parse(schoolsString);
        const school = allSchools.find((s: any) => s.id === schoolId);
        if (school) {
          setSelectedSchool(school);
          setIsDetailsOpen(true);
        }
      }
    }
  }, [location.search]);

  const loadSchools = () => {
    const schoolRegistrationsString = localStorage.getItem('schoolRegistrations');
    if (schoolRegistrationsString) {
      const schoolRegistrations = JSON.parse(schoolRegistrationsString);
      const approvedSchools = schoolRegistrations.filter((school: any) => school.status === 'approved');
      setSchools(approvedSchools);
    }
  };

  const handleSearch = (e: React.ChangeEvent<HTMLInputElement>) => {
    setSearchTerm(e.target.value);
  };

  const filteredSchools = schools.filter(school => 
    school.schoolName.toLowerCase().includes(searchTerm.toLowerCase()) ||
    school.licenseNumber.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const handleViewDetails = (school: any) => {
    setSelectedSchool(school);
    setIsDetailsOpen(true);
  };

  const handleDeleteSchool = (schoolId: string) => {
    if (window.confirm('Are you sure you want to delete this school? This action cannot be undone.')) {
      try {
        // Get existing registrations
        const registrationsString = localStorage.getItem('schoolRegistrations');
        if (registrationsString) {
          const registrations = JSON.parse(registrationsString);
          
          // Filter out the deleted school
          const updatedRegistrations = registrations.filter((school: any) => school.id !== schoolId);
          
          // Save back to localStorage
          localStorage.setItem('schoolRegistrations', JSON.stringify(updatedRegistrations));
          
          // Update UI
          setSchools(prev => prev.filter(school => school.id !== schoolId));
          
          toast.success('School deleted successfully');
        }
      } catch (error) {
        console.error('Error deleting school:', error);
        toast.error('Failed to delete school');
      }
    }
  };

  const handleResetPassword = (school: any) => {
    setSelectedSchool(school);
    setNewPassword(Math.random().toString(36).slice(-8)); // Generate random password
    setIsResetDialogOpen(true);
  };

  const confirmResetPassword = () => {
    try {
      // Get existing registrations
      const registrationsString = localStorage.getItem('schoolRegistrations');
      if (registrationsString && selectedSchool) {
        const registrations = JSON.parse(registrationsString);
        
        // Find the selected school
        const schoolIndex = registrations.findIndex((s: any) => s.id === selectedSchool.id);
        
        if (schoolIndex !== -1) {
          // Find the admin account
          const adminIndex = registrations[schoolIndex].users.findIndex((u: any) => u.role === 'admin');
          
          if (adminIndex !== -1) {
            // Update admin password
            registrations[schoolIndex].users[adminIndex].password = newPassword;
            
            // Save back to localStorage
            localStorage.setItem('schoolRegistrations', JSON.stringify(registrations));
            
            toast.success('Admin password reset successfully');
            setIsResetDialogOpen(false);
          } else {
            toast.error('Admin account not found');
          }
        }
      }
    } catch (error) {
      console.error('Error resetting password:', error);
      toast.error('Failed to reset password');
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      
      <div className="container mx-auto px-4 py-8">
        <div className="flex justify-between items-center mb-8">
          <div>
            <h1 className="text-2xl font-bold">Manage Schools</h1>
            <p className="text-gray-600">View and manage all approved schools</p>
          </div>
          
          <Button variant="outline" onClick={() => navigate('/admin-dashboard')}>
            Back to Dashboard
          </Button>
        </div>
        
        <Card className="mb-8">
          <CardContent className="pt-6">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
              <Input
                placeholder="Search schools by name or license number..."
                value={searchTerm}
                onChange={handleSearch}
                className="pl-10"
              />
            </div>
          </CardContent>
        </Card>
        
        {filteredSchools.length > 0 ? (
          <Card>
            <CardHeader>
              <CardTitle>Approved Schools</CardTitle>
              <CardDescription>
                Total of {filteredSchools.length} approved schools
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>School Name</TableHead>
                    <TableHead>License Number</TableHead>
                    <TableHead>Type</TableHead>
                    <TableHead>Users</TableHead>
                    <TableHead>Approval Date</TableHead>
                    <TableHead className="text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredSchools.map(school => {
                    const teacherCount = school.users ? school.users.filter((u: any) => u.role === 'teacher').length : 0;
                    const studentCount = school.users ? school.users.filter((u: any) => u.role === 'student').length : 0;
                    
                    return (
                      <TableRow key={school.id}>
                        <TableCell className="font-medium">{school.schoolName}</TableCell>
                        <TableCell>{school.licenseNumber}</TableCell>
                        <TableCell>
                          <Badge variant="outline" className="capitalize">
                            {school.schoolType}
                          </Badge>
                        </TableCell>
                        <TableCell>
                          <div className="flex items-center space-x-2">
                            <div className="flex items-center">
                              <User className="h-3 w-3 mr-1 text-blue-600" />
                              <span className="text-xs">{teacherCount}</span>
                            </div>
                            <div className="flex items-center">
                              <Users className="h-3 w-3 mr-1 text-purple-600" />
                              <span className="text-xs">{studentCount}</span>
                            </div>
                          </div>
                        </TableCell>
                        <TableCell className="text-sm text-gray-500">
                          {new Date(school.createdAt).toLocaleDateString()}
                        </TableCell>
                        <TableCell className="text-right">
                          <div className="flex justify-end space-x-2">
                            <Button 
                              variant="ghost" 
                              size="sm"
                              onClick={() => handleResetPassword(school)}
                              title="Reset Admin Password"
                            >
                              <RefreshCw className="h-4 w-4 text-amber-600" />
                            </Button>
                            <Button 
                              variant="ghost" 
                              size="sm"
                              onClick={() => handleViewDetails(school)}
                            >
                              <Eye className="h-4 w-4 text-blue-600" />
                            </Button>
                            <Button 
                              variant="ghost" 
                              size="sm"
                              onClick={() => handleDeleteSchool(school.id)}
                            >
                              <Trash2 className="h-4 w-4 text-red-600" />
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    );
                  })}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        ) : (
          <div className="flex flex-col items-center justify-center py-12 text-gray-500">
            <School className="h-16 w-16 mb-4 text-gray-300" />
            <h2 className="text-xl font-medium mb-2">No Schools Found</h2>
            <p>There are no approved schools matching your search criteria.</p>
          </div>
        )}
      </div>
      
      {/* School Details Dialog */}
      <Dialog open={isDetailsOpen} onOpenChange={setIsDetailsOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>{selectedSchool?.schoolName}</DialogTitle>
            <DialogDescription>
              School details and administrator account information
            </DialogDescription>
          </DialogHeader>
          
          {selectedSchool && (
            <div className="space-y-4 py-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <p className="text-sm font-medium text-gray-500">School Type</p>
                  <p className="capitalize">{selectedSchool.schoolType}</p>
                </div>
                <div>
                  <p className="text-sm font-medium text-gray-500">License Number</p>
                  <p>{selectedSchool.licenseNumber}</p>
                </div>
              </div>
              
              <div>
                <p className="text-sm font-medium text-gray-500">Contact Info</p>
                <p>{selectedSchool.email}</p>
                <p>{selectedSchool.phone}</p>
              </div>
              
              <div>
                <p className="text-sm font-medium text-gray-500">Address</p>
                <p>{selectedSchool.address}</p>
              </div>
              
              <div>
                <p className="text-sm font-medium text-gray-500">Principal/Director</p>
                <p>{selectedSchool.principalName}</p>
              </div>
              
              <div className="pt-2 border-t">
                <p className="text-sm font-medium text-gray-500 mb-2">Admin Account Details</p>
                {selectedSchool.users && selectedSchool.users.find((u: any) => u.role === 'admin') ? (
                  <div className="bg-gray-50 p-3 rounded">
                    <p className="text-sm">
                      <span className="font-medium">Username:</span> {
                        selectedSchool.users.find((u: any) => u.role === 'admin').username
                      }
                    </p>
                  </div>
                ) : (
                  <p className="text-sm text-red-500">No admin account found for this school.</p>
                )}
              </div>
            </div>
          )}
          
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsDetailsOpen(false)}>
              Close
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
      
      {/* Reset Password Dialog */}
      <Dialog open={isResetDialogOpen} onOpenChange={setIsResetDialogOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Reset Admin Password</DialogTitle>
            <DialogDescription>
              You are resetting the administrator password for {selectedSchool?.schoolName}.
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <p className="text-sm font-medium">New Password:</p>
              <div className="bg-gray-100 p-3 rounded text-center font-mono">
                {newPassword}
              </div>
              <p className="text-xs text-gray-500 mt-1">
                Please save this password. You will not be able to see it again.
              </p>
            </div>
          </div>
          
          <DialogFooter className="sm:justify-between">
            <Button
              variant="outline"
              onClick={() => setIsResetDialogOpen(false)}
            >
              Cancel
            </Button>
            <Button
              onClick={confirmResetPassword}
              className="bg-ethio-warning hover:bg-amber-600"
            >
              Reset Password
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default ManageSchools;
