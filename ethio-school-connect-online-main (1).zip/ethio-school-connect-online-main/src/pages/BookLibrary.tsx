
import React, { useState, useEffect, useRef } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { BookOpen, Search, Filter, User, Calendar, Trash2, Eye, Library, Book, BookText, Upload } from 'lucide-react';
import { toast } from 'sonner';
import Header from '@/components/Header';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { v4 as uuidv4 } from 'uuid';

const BookLibrary = () => {
  const navigate = useNavigate();
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [currentUser, setCurrentUser] = useState<any>(null);
  const [books, setBooks] = useState<any[]>([]);
  const [filteredBooks, setFilteredBooks] = useState<any[]>([]);
  const [activeTab, setActiveTab] = useState('all');
  const [searchTerm, setSearchTerm] = useState('');
  const [filters, setFilters] = useState({
    grade: 'all',
    category: 'all'
  });
  const [uploadedFile, setUploadedFile] = useState<File | null>(null);
  
  const [newBook, setNewBook] = useState({
    title: '',
    description: '',
    grade: '1',
    category: 'textbook',
    url: '',
    coverUrl: '',
    file: null as File | null,
  });

  useEffect(() => {
    if (!localStorage.getItem('books')) {
      localStorage.setItem('books', JSON.stringify([]));
    }
  }, []);

  useEffect(() => {
    const userString = localStorage.getItem('currentUser');
    if (userString) {
      const user = JSON.parse(userString);
      setCurrentUser(user);
      
      const booksString = localStorage.getItem('books');
      if (booksString) {
        const allBooks = JSON.parse(booksString);
        
        if (user.role === 'student') {
          // Filter books for students - only show books of their grade and not teacher guides
          const filteredBooks = allBooks.filter((book: any) => 
            book.category !== 'teacherguide' && 
            (book.grade === user.grade || book.grade === 'all')
          );
          setBooks(filteredBooks);
          setFilteredBooks(filteredBooks);
        } else {
          setBooks(allBooks);
          setFilteredBooks(allBooks);
        }
      }
    } else {
      navigate('/');
    }
  }, [navigate]);

  const handleTabChange = (value: string) => {
    setActiveTab(value);
    applyFilters(value, searchTerm, filters);
  };

  const handleSearch = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value;
    setSearchTerm(value);
    applyFilters(activeTab, value, filters);
  };

  const handleFilterChange = (name: string, value: string) => {
    const newFilters = { ...filters, [name]: value };
    setFilters(newFilters);
    applyFilters(activeTab, searchTerm, newFilters);
  };

  const clearFilters = () => {
    setFilters({ grade: 'all', category: 'all' });
    applyFilters(activeTab, searchTerm, { grade: 'all', category: 'all' });
  };

  const applyFilters = (tab: string, search: string, filterValues: typeof filters) => {
    let filtered = books;
    
    if (tab !== 'all') {
      filtered = filtered.filter(item => item.category === tab);
    }
    
    if (search) {
      filtered = filtered.filter(item => 
        item.title.toLowerCase().includes(search.toLowerCase()) ||
        item.description?.toLowerCase().includes(search.toLowerCase())
      );
    }
    
    if (filterValues.category && filterValues.category !== 'all') {
      filtered = filtered.filter(item => item.category === filterValues.category);
    }
    
    if (filterValues.grade && filterValues.grade !== 'all') {
      filtered = filtered.filter(item => item.grade === filterValues.grade);
    }
    
    setFilteredBooks(filtered);
  };
  
  const handleBookFormChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setNewBook({
      ...newBook,
      [name]: value
    });
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0] || null;
    if (file) {
      setUploadedFile(file);
      
      const fileUrl = URL.createObjectURL(file);
      
      setNewBook({
        ...newBook,
        file,
        url: fileUrl,
        title: file.name.split('.')[0] || newBook.title
      });
      
      toast.success(`File "${file.name}" selected for upload`);
    }
  };

  const triggerFileInput = () => {
    fileInputRef.current?.click();
  };
  
  const handleSubmitBook = (e: React.FormEvent) => {
    e.preventDefault();
    
    try {
      if (!newBook.title) {
        toast.error('Book title is required');
        return;
      }
      
      const booksString = localStorage.getItem('books');
      const existingBooks = booksString ? JSON.parse(booksString) : [];
      
      const book = {
        id: uuidv4(),
        title: newBook.title,
        description: newBook.description,
        grade: newBook.grade,
        category: newBook.category,
        url: newBook.url,
        coverUrl: newBook.coverUrl || 'https://via.placeholder.com/150?text=Book+Cover',
        createdAt: new Date().toISOString(),
        createdBy: currentUser.id,
        createdByName: currentUser.name,
        fileName: newBook.file ? newBook.file.name : undefined
      };
      
      const updatedBooks = [...existingBooks, book];
      localStorage.setItem('books', JSON.stringify(updatedBooks));
      
      setBooks(updatedBooks);
      applyFilters(activeTab, searchTerm, filters);
      
      setNewBook({
        title: '',
        description: '',
        grade: '1',
        category: 'textbook',
        url: '',
        coverUrl: '',
        file: null
      });
      setUploadedFile(null);
      
      toast.success('Book added successfully');
    } catch (error) {
      console.error('Error adding book:', error);
      toast.error('Failed to add book');
    }
  };
  
  const handleDeleteBook = (id: string) => {
    if (window.confirm('Are you sure you want to delete this book? This action cannot be undone.')) {
      try {
        const booksString = localStorage.getItem('books');
        if (booksString) {
          const allBooks = JSON.parse(booksString);
          
          const updatedBooks = allBooks.filter((item: any) => item.id !== id);
          
          localStorage.setItem('books', JSON.stringify(updatedBooks));
          
          setBooks(updatedBooks);
          applyFilters(activeTab, searchTerm, filters);
          
          toast.success('Book deleted successfully');
        }
      } catch (error) {
        console.error('Error deleting book:', error);
        toast.error('Failed to delete book');
      }
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      
      <div className="container mx-auto px-4 py-8">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-8">
          <div>
            <h1 className="text-2xl font-bold">Book Library</h1>
            <p className="text-gray-600">
              {currentUser?.role === 'student' 
                ? `Access textbooks and reference materials for Grade ${currentUser.grade}` 
                : 'Access textbooks and reference materials for all grades'}
            </p>
          </div>
          
          <div className="flex gap-2 mt-4 md:mt-0">
            {currentUser?.role === 'system_admin' && (
              <Dialog>
                <DialogTrigger asChild>
                  <Button className="flex items-center gap-2">
                    <BookOpen className="h-4 w-4" />
                    <span>Upload Book</span>
                  </Button>
                </DialogTrigger>
                <DialogContent className="sm:max-w-[525px]">
                  <DialogHeader>
                    <DialogTitle>Upload New Book</DialogTitle>
                    <DialogDescription>
                      Add a new textbook, reference book, scientific book, or teacher guide to the library
                    </DialogDescription>
                  </DialogHeader>
                  <form onSubmit={handleSubmitBook}>
                    <div className="grid gap-4 py-4">
                      <div className="flex flex-col gap-2 p-4 border border-dashed rounded-lg border-gray-300 bg-gray-50 text-center cursor-pointer" onClick={triggerFileInput}>
                        <Upload className="w-8 h-8 mx-auto text-gray-400" />
                        <p className="text-sm font-medium">
                          {uploadedFile ? `Selected: ${uploadedFile.name}` : 'Click to upload a book file'}
                        </p>
                        <p className="text-xs text-gray-500">
                          PDF, Word, or other document formats accepted
                        </p>
                        <input 
                          type="file" 
                          ref={fileInputRef}
                          className="hidden" 
                          accept=".pdf,.doc,.docx,.ppt,.pptx,.xls,.xlsx,.txt"
                          onChange={handleFileUpload}
                        />
                      </div>

                      <div className="grid grid-cols-4 items-center gap-4">
                        <Label className="text-right" htmlFor="title">Title</Label>
                        <Input
                          id="title"
                          name="title"
                          value={newBook.title}
                          onChange={handleBookFormChange}
                          className="col-span-3"
                          required
                        />
                      </div>
                      <div className="grid grid-cols-4 items-center gap-4">
                        <Label className="text-right" htmlFor="description">Description</Label>
                        <Textarea
                          id="description"
                          name="description"
                          value={newBook.description}
                          onChange={handleBookFormChange}
                          className="col-span-3"
                        />
                      </div>
                      <div className="grid grid-cols-4 items-center gap-4">
                        <Label className="text-right" htmlFor="category">Category</Label>
                        <Select 
                          name="category" 
                          value={newBook.category}
                          onValueChange={(value) => setNewBook({...newBook, category: value})}
                        >
                          <SelectTrigger className="col-span-3">
                            <SelectValue placeholder="Select category" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="textbook">Student Textbook</SelectItem>
                            <SelectItem value="reference">Reference Book</SelectItem>
                            <SelectItem value="scientific">Scientific Book</SelectItem>
                            <SelectItem value="teacherguide">Teacher Guide</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                      <div className="grid grid-cols-4 items-center gap-4">
                        <Label className="text-right" htmlFor="grade">Grade</Label>
                        <Select 
                          name="grade" 
                          value={newBook.grade}
                          onValueChange={(value) => setNewBook({...newBook, grade: value})}
                        >
                          <SelectTrigger className="col-span-3">
                            <SelectValue placeholder="Select grade" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="all">All Grades</SelectItem>
                            {[1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12].map((grade) => (
                              <SelectItem key={grade} value={grade.toString()}>
                                Grade {grade}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                      {!uploadedFile && (
                        <div className="grid grid-cols-4 items-center gap-4">
                          <Label className="text-right" htmlFor="url">Book URL</Label>
                          <Input
                            id="url"
                            name="url"
                            placeholder="https://example.com/book.pdf"
                            value={newBook.url}
                            onChange={handleBookFormChange}
                            className="col-span-3"
                          />
                        </div>
                      )}
                      <div className="grid grid-cols-4 items-center gap-4">
                        <Label className="text-right" htmlFor="coverUrl">Cover Image URL</Label>
                        <Input
                          id="coverUrl"
                          name="coverUrl"
                          placeholder="https://example.com/cover.jpg"
                          value={newBook.coverUrl}
                          onChange={handleBookFormChange}
                          className="col-span-3"
                        />
                      </div>
                    </div>
                    <DialogFooter>
                      <Button type="submit" disabled={!newBook.title || (!newBook.url && !uploadedFile)}>
                        Upload Book
                      </Button>
                    </DialogFooter>
                  </form>
                </DialogContent>
              </Dialog>
            )}
            <Link to="/content-library">
              <Button variant="outline" className="flex items-center gap-2">
                <BookOpen className="h-4 w-4" />
                <span>Content Library</span>
              </Button>
            </Link>
            <Button variant="outline" onClick={() => {
              if (currentUser?.role === 'teacher') {
                navigate('/teacher-dashboard');
              } else if (currentUser?.role === 'student') {
                navigate('/student-dashboard');
              } else if (currentUser?.role === 'admin') {
                navigate('/school-admin-dashboard');
              } else {
                navigate('/admin-dashboard');
              }
            }}>
              Back to Dashboard
            </Button>
          </div>
        </div>
        
        <Card className="mb-8">
          <CardContent className="pt-6">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
                <Input
                  placeholder="Search by title or description..."
                  value={searchTerm}
                  onChange={handleSearch}
                  className="pl-10"
                />
              </div>
              
              <div>
                <Select
                  value={filters.category}
                  onValueChange={(value) => handleFilterChange('category', value)}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Filter by category" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Categories</SelectItem>
                    <SelectItem value="textbook">Student Textbook</SelectItem>
                    <SelectItem value="reference">Reference Book</SelectItem>
                    <SelectItem value="scientific">Scientific Book</SelectItem>
                    {currentUser?.role !== 'student' && (
                      <SelectItem value="teacherguide">Teacher Guide</SelectItem>
                    )}
                  </SelectContent>
                </Select>
              </div>
              
              <div>
                <Select
                  value={filters.grade}
                  onValueChange={(value) => handleFilterChange('grade', value)}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Filter by grade" />
                  </SelectTrigger>
                  <SelectContent>
                    {currentUser?.role === 'student' ? (
                      <SelectItem value={currentUser.grade}>{`Grade ${currentUser.grade}`}</SelectItem>
                    ) : (
                      <>
                        <SelectItem value="all">All Grades</SelectItem>
                        {[1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12].map((grade) => (
                          <SelectItem key={grade} value={grade.toString()}>
                            Grade {grade}
                          </SelectItem>
                        ))}
                      </>
                    )}
                  </SelectContent>
                </Select>
              </div>
            </div>
            
            {(filters.category !== 'all' || filters.grade !== 'all') && (
              <div className="flex items-center justify-between mt-4 pt-4 border-t">
                <div className="flex items-center">
                  <Filter className="h-4 w-4 mr-2 text-gray-500" />
                  <span className="text-sm text-gray-700">
                    Filters applied: 
                    {filters.category !== 'all' && (
                      <span className="ml-1">
                        Category: {
                          filters.category === 'textbook' ? 'Student Textbook' : 
                          filters.category === 'reference' ? 'Reference Book' : 
                          filters.category === 'scientific' ? 'Scientific Book' :
                          'Teacher Guide'
                        }
                      </span>
                    )}
                    {filters.grade !== 'all' && <span className="ml-1">Grade: {filters.grade}</span>}
                  </span>
                </div>
                {currentUser?.role !== 'student' && (
                  <Button variant="ghost" size="sm" onClick={clearFilters}>
                    Clear Filters
                  </Button>
                )}
              </div>
            )}
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader>
            <CardTitle>Books Collection</CardTitle>
            <CardDescription>
              {filteredBooks.length} books found
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Tabs value={activeTab} onValueChange={handleTabChange} className="w-full">
              <TabsList className="grid w-full max-w-md grid-cols-4 mb-6">
                <TabsTrigger value="all" className="flex items-center gap-2">
                  <Library className="h-4 w-4" />
                  <span>All</span>
                </TabsTrigger>
                <TabsTrigger value="textbook" className="flex items-center gap-2">
                  <BookOpen className="h-4 w-4" />
                  <span>Textbooks</span>
                </TabsTrigger>
                <TabsTrigger value="reference" className="flex items-center gap-2">
                  <Book className="h-4 w-4" />
                  <span>Reference</span>
                </TabsTrigger>
                {currentUser?.role === 'student' ? (
                  <TabsTrigger value="scientific" className="flex items-center gap-2">
                    <BookText className="h-4 w-4" />
                    <span>Scientific</span>
                  </TabsTrigger>
                ) : (
                  <TabsTrigger value="teacherguide" className="flex items-center gap-2">
                    <BookText className="h-4 w-4" />
                    <span>Teacher Guides</span>
                  </TabsTrigger>
                )}
              </TabsList>
              
              <TabsContent value="all" className="mt-0">
                {renderBookItems(filteredBooks)}
              </TabsContent>
              
              <TabsContent value="textbook" className="mt-0">
                {renderBookItems(filteredBooks)}
              </TabsContent>
              
              <TabsContent value="reference" className="mt-0">
                {renderBookItems(filteredBooks)}
              </TabsContent>
              
              <TabsContent value="scientific" className="mt-0">
                {renderBookItems(filteredBooks)}
              </TabsContent>
              
              <TabsContent value="teacherguide" className="mt-0">
                {renderBookItems(filteredBooks)}
              </TabsContent>
            </Tabs>
          </CardContent>
        </Card>
      </div>
    </div>
  );

  function renderBookItems(items: any[]) {
    if (items.length === 0) {
      return (
        <div className="text-center py-12 text-gray-500">
          <BookOpen className="h-12 w-12 mx-auto mb-3 text-gray-300" />
          <h2 className="text-xl font-medium mb-2">No Books Found</h2>
          <p>There are no books matching your search criteria.</p>
          {currentUser?.role === 'system_admin' && (
            <Dialog>
              <DialogTrigger asChild>
                <Button variant="outline" className="mt-4">
                  Upload New Book
                </Button>
              </DialogTrigger>
              <DialogContent className="sm:max-w-[525px]">
                <form onSubmit={handleSubmitBook}>
                  <div className="grid gap-4 py-4">
                    <div className="flex flex-col gap-2 p-4 border border-dashed rounded-lg border-gray-300 bg-gray-50 text-center cursor-pointer" onClick={triggerFileInput}>
                      <Upload className="w-8 h-8 mx-auto text-gray-400" />
                      <p className="text-sm font-medium">
                        {uploadedFile ? `Selected: ${uploadedFile.name}` : 'Click to upload a book file'}
                      </p>
                      <p className="text-xs text-gray-500">
                        PDF, Word, or other document formats accepted
                      </p>
                      <input 
                        type="file" 
                        ref={fileInputRef}
                        className="hidden" 
                        accept=".pdf,.doc,.docx,.ppt,.pptx,.xls,.xlsx,.txt"
                        onChange={handleFileUpload}
                      />
                    </div>

                    <div className="grid grid-cols-4 items-center gap-4">
                      <Label className="text-right" htmlFor="title">Title</Label>
                      <Input
                        id="title"
                        name="title"
                        value={newBook.title}
                        onChange={handleBookFormChange}
                        className="col-span-3"
                        required
                      />
                    </div>
                    <div className="grid grid-cols-4 items-center gap-4">
                      <Label className="text-right" htmlFor="description">Description</Label>
                      <Textarea
                        id="description"
                        name="description"
                        value={newBook.description}
                        onChange={handleBookFormChange}
                        className="col-span-3"
                      />
                    </div>
                    <div className="grid grid-cols-4 items-center gap-4">
                      <Label className="text-right" htmlFor="category">Category</Label>
                      <Select 
                        name="category" 
                        value={newBook.category}
                        onValueChange={(value) => setNewBook({...newBook, category: value})}
                      >
                        <SelectTrigger className="col-span-3">
                          <SelectValue placeholder="Select category" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="textbook">Student Textbook</SelectItem>
                          <SelectItem value="reference">Reference Book</SelectItem>
                          <SelectItem value="teacherguide">Teacher Guide</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="grid grid-cols-4 items-center gap-4">
                      <Label className="text-right" htmlFor="grade">Grade</Label>
                      <Select 
                        name="grade" 
                        value={newBook.grade}
                        onValueChange={(value) => setNewBook({...newBook, grade: value})}
                      >
                        <SelectTrigger className="col-span-3">
                          <SelectValue placeholder="Select grade" />
                        </SelectTrigger>
                        <SelectContent>
                          {[1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12].map((grade) => (
                            <SelectItem key={grade} value={grade.toString()}>
                              Grade {grade}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                    {!uploadedFile && (
                      <div className="grid grid-cols-4 items-center gap-4">
                        <Label className="text-right" htmlFor="url">Book URL</Label>
                        <Input
                          id="url"
                          name="url"
                          placeholder="https://example.com/book.pdf"
                          value={newBook.url}
                          onChange={handleBookFormChange}
                          className="col-span-3"
                        />
                      </div>
                    )}
                    <div className="grid grid-cols-4 items-center gap-4">
                      <Label className="text-right" htmlFor="coverUrl">Cover Image URL</Label>
                      <Input
                        id="coverUrl"
                        name="coverUrl"
                        placeholder="https://example.com/cover.jpg"
                        value={newBook.coverUrl}
                        onChange={handleBookFormChange}
                        className="col-span-3"
                      />
                    </div>
                  </div>
                  <DialogFooter>
                    <Button type="submit" disabled={!newBook.title || (!newBook.url && !uploadedFile)}>
                      Upload Book
                    </Button>
                  </DialogFooter>
                </form>
              </DialogContent>
            </Dialog>
          )}
        </div>
      );
    }

    return (
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {items.map((book) => (
          <Card key={book.id} className="overflow-hidden">
            <div className="aspect-w-3 aspect-h-4 bg-gray-100">
              <img 
                src={book.coverUrl || 'https://via.placeholder.com/300x400?text=Book+Cover'} 
                alt={book.title}
                className="object-cover w-full h-48"
                onError={(e) => {
                  const target = e.target as HTMLImageElement;
                  target.src = 'https://via.placeholder.com/300x400?text=Book+Cover';
                }}
              />
            </div>
            <CardHeader className="pb-2">
              <CardTitle className="text-lg line-clamp-1">{book.title}</CardTitle>
              <CardDescription>
                <Badge className="mr-2">
                  {book.grade === 'all' ? 'All Grades' : `Grade ${book.grade}`}
                </Badge>
                <Badge variant="outline">
                  {book.category === 'textbook' ? 'Student Textbook' : 
                   book.category === 'reference' ? 'Reference Book' : 
                   book.category === 'scientific' ? 'Scientific Book' :
                   'Teacher Guide'}
                </Badge>
              </CardDescription>
            </CardHeader>
            <CardContent className="pb-2">
              {book.description && (
                <p className="text-sm text-gray-600 line-clamp-2 mb-3">{book.description}</p>
              )}
              {book.fileName && (
                <p className="text-xs text-gray-500 mb-2">
                  <span className="font-medium">File:</span> {book.fileName}
                </p>
              )}
              <div className="flex items-center text-xs text-gray-500">
                <Calendar className="h-3 w-3 mr-1" />
                <span>Added: {new Date(book.createdAt).toLocaleDateString()}</span>
              </div>
            </CardContent>
            <CardFooter className="pt-2 flex justify-between">
              <a 
                href={book.url} 
                target="_blank" 
                rel="noopener noreferrer"
              >
                <Button variant="outline" size="sm">
                  <Eye className="h-4 w-4 mr-1" />
                  View Book
                </Button>
              </a>
              
              {currentUser?.role === 'system_admin' && (
                <Button 
                  variant="ghost" 
                  size="sm" 
                  className="text-red-600 hover:bg-red-50 hover:text-red-700"
                  onClick={() => handleDeleteBook(book.id)}
                >
                  <Trash2 className="h-4 w-4 mr-1" />
                  Delete
                </Button>
              )}
            </CardFooter>
          </Card>
        ))}
      </div>
    );
  }
};

export default BookLibrary;
