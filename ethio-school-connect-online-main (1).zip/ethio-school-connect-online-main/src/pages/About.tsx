
import React from 'react';
import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { BookOpen, HelpCircle, FileText, FileClock, Video, School } from 'lucide-react';
import Header from '@/components/Header';

const About = () => {
  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      
      <div className="container mx-auto px-4 py-8">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-8">
          <div>
            <h1 className="text-2xl font-bold">About Ethio Schools Online</h1>
            <p className="text-gray-600">
              Learn more about our educational platform
            </p>
          </div>
          
          <Link to="/">
            <Button variant="outline">
              Back to Dashboard
            </Button>
          </Link>
        </div>
        
        <Tabs defaultValue="about" className="w-full">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="about">About Platform</TabsTrigger>
            <TabsTrigger value="guide">User Guide</TabsTrigger>
            <TabsTrigger value="faq">Frequently Asked Questions</TabsTrigger>
          </TabsList>
          
          <TabsContent value="about">
            <Card>
              <CardHeader>
                <CardTitle>About Ethio Schools Online</CardTitle>
                <CardDescription>
                  A digital platform connecting students and teachers across Ethiopia
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="flex flex-col md:flex-row gap-8">
                  <div className="md:w-1/2">
                    <h3 className="text-xl font-medium mb-4">Our Mission</h3>
                    <p className="text-gray-700 leading-relaxed">
                      Ethio Schools Online is dedicated to improving educational outcomes across Ethiopia by providing a centralized 
                      platform for students and teachers to share educational content, collaborate, and access quality learning materials.
                      We believe that by connecting schools and standardizing access to resources, we can help bridge educational gaps 
                      and support academic excellence for all students.
                    </p>
                  </div>
                  <div className="md:w-1/2">
                    <h3 className="text-xl font-medium mb-4">Who We Serve</h3>
                    <ul className="space-y-3">
                      <li className="flex items-start">
                        <School className="h-5 w-5 text-ethio-primary mr-2 mt-0.5" />
                        <div>
                          <span className="font-medium">Schools</span>
                          <p className="text-gray-600 text-sm">Public and private schools can register on our platform to create their digital presence.</p>
                        </div>
                      </li>
                      <li className="flex items-start">
                        <BookOpen className="h-5 w-5 text-ethio-secondary mr-2 mt-0.5" />
                        <div>
                          <span className="font-medium">Teachers</span>
                          <p className="text-gray-600 text-sm">Upload educational content, create quizzes, and share teaching materials.</p>
                        </div>
                      </li>
                      <li className="flex items-start">
                        <FileText className="h-5 w-5 text-ethio-accent mr-2 mt-0.5" />
                        <div>
                          <span className="font-medium">Students</span>
                          <p className="text-gray-600 text-sm">Access study materials, take quizzes, and communicate with teachers.</p>
                        </div>
                      </li>
                    </ul>
                  </div>
                </div>
                
                <div className="border-t pt-6">
                  <h3 className="text-xl font-medium mb-4">Key Features</h3>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <Card>
                      <CardContent className="pt-6">
                        <div className="flex items-start">
                          <div className="p-2 bg-blue-50 rounded-full mr-4">
                            <FileText className="h-5 w-5 text-ethio-primary" />
                          </div>
                          <div>
                            <h4 className="font-medium">Educational Notes</h4>
                            <p className="text-sm text-gray-600">Access and share formatted study notes by subject and grade level</p>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                    
                    <Card>
                      <CardContent className="pt-6">
                        <div className="flex items-start">
                          <div className="p-2 bg-amber-50 rounded-full mr-4">
                            <FileClock className="h-5 w-5 text-ethio-warning" />
                          </div>
                          <div>
                            <h4 className="font-medium">Interactive Quizzes</h4>
                            <p className="text-sm text-gray-600">Create and take quizzes to test knowledge and track progress</p>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                    
                    <Card>
                      <CardContent className="pt-6">
                        <div className="flex items-start">
                          <div className="p-2 bg-purple-50 rounded-full mr-4">
                            <Video className="h-5 w-5 text-ethio-accent" />
                          </div>
                          <div>
                            <h4 className="font-medium">Video Lessons</h4>
                            <p className="text-sm text-gray-600">Watch educational videos aligned with the Ethiopian curriculum</p>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
          
          <TabsContent value="guide">
            <Card>
              <CardHeader>
                <CardTitle>User Guide</CardTitle>
                <CardDescription>
                  How to use the Ethio Schools Online platform
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="space-y-4">
                  <div className="border rounded-lg p-4">
                    <h3 className="text-lg font-medium mb-2">For Students</h3>
                    <ol className="list-decimal ml-5 space-y-3">
                      <li>
                        <span className="font-medium">Access Content Library:</span>
                        <p className="text-gray-600 text-sm">Browse all available content filtered for your grade level. Use search and filters to find specific materials.</p>
                      </li>
                      <li>
                        <span className="font-medium">Take Quizzes:</span>
                        <p className="text-gray-600 text-sm">Access quizzes created by teachers, submit your answers, and view your results and correct answers.</p>
                      </li>
                      <li>
                        <span className="font-medium">Study Notes:</span>
                        <p className="text-gray-600 text-sm">Read educational notes shared by teachers to enhance your understanding of topics.</p>
                      </li>
                      <li>
                        <span className="font-medium">Watch Video Lessons:</span>
                        <p className="text-gray-600 text-sm">View educational videos to complement your studies.</p>
                      </li>
                      <li>
                        <span className="font-medium">Communication:</span>
                        <p className="text-gray-600 text-sm">Send messages to teachers and receive announcements.</p>
                      </li>
                    </ol>
                  </div>
                  
                  <div className="border rounded-lg p-4">
                    <h3 className="text-lg font-medium mb-2">For Teachers</h3>
                    <ol className="list-decimal ml-5 space-y-3">
                      <li>
                        <span className="font-medium">Upload Content:</span>
                        <p className="text-gray-600 text-sm">Create and upload notes, quizzes, and video links. Choose whether to make content private or available to specific students from all schools.</p>
                      </li>
                      <li>
                        <span className="font-medium">Create Quizzes:</span>
                        <p className="text-gray-600 text-sm">Design multiple-choice quizzes with automatic grading. Set time limits and view student results.</p>
                      </li>
                      <li>
                        <span className="font-medium">Manage Content:</span>
                        <p className="text-gray-600 text-sm">Edit, update, or delete your uploaded content as needed.</p>
                      </li>
                      <li>
                        <span className="font-medium">Communicate:</span>
                        <p className="text-gray-600 text-sm">Send messages to students and other teachers.</p>
                      </li>
                    </ol>
                  </div>
                  
                  <div className="border rounded-lg p-4">
                    <h3 className="text-lg font-medium mb-2">For School Administrators</h3>
                    <ol className="list-decimal ml-5 space-y-3">
                      <li>
                        <span className="font-medium">Manage Users:</span>
                        <p className="text-gray-600 text-sm">Add and manage teacher and student accounts for your school.</p>
                      </li>
                      <li>
                        <span className="font-medium">School Profile:</span>
                        <p className="text-gray-600 text-sm">Update your school information and settings.</p>
                      </li>
                      <li>
                        <span className="font-medium">Review Content:</span>
                        <p className="text-gray-600 text-sm">Monitor educational content uploaded by your school's teachers.</p>
                      </li>
                    </ol>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
          
          <TabsContent value="faq">
            <Card>
              <CardHeader>
                <CardTitle>Frequently Asked Questions</CardTitle>
                <CardDescription>
                  Common questions about using the platform
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="divide-y">
                  <div className="py-4">
                    <h4 className="font-medium flex items-center">
                      <HelpCircle className="h-4 w-4 mr-2 text-ethio-primary" />
                      How do I reset my password?
                    </h4>
                    <p className="mt-2 text-gray-600">
                      You can reset your password by contacting your school administrator or the system administrator.
                    </p>
                  </div>
                  
                  <div className="py-4">
                    <h4 className="font-medium flex items-center">
                      <HelpCircle className="h-4 w-4 mr-2 text-ethio-primary" />
                      What is the difference between private and school-wide content?
                    </h4>
                    <p className="mt-2 text-gray-600">
                      Private content is only visible to you as the creator. School-wide content is available to specific students from all schools who access this platform based on their grade level.
                    </p>
                  </div>
                  
                  <div className="py-4">
                    <h4 className="font-medium flex items-center">
                      <HelpCircle className="h-4 w-4 mr-2 text-ethio-primary" />
                      Can I upload videos directly to the platform?
                    </h4>
                    <p className="mt-2 text-gray-600">
                      Currently, the platform supports linking to externally hosted videos (such as YouTube). You provide the video URL when creating video content.
                    </p>
                  </div>
                  
                  <div className="py-4">
                    <h4 className="font-medium flex items-center">
                      <HelpCircle className="h-4 w-4 mr-2 text-ethio-primary" />
                      How do I filter content for my specific grade?
                    </h4>
                    <p className="mt-2 text-gray-600">
                      In the Content Library, use the Grade filter dropdown to select your specific grade level. The platform also automatically shows content relevant to your grade on your dashboard.
                    </p>
                  </div>
                  
                  <div className="py-4">
                    <h4 className="font-medium flex items-center">
                      <HelpCircle className="h-4 w-4 mr-2 text-ethio-primary" />
                      Can I edit or delete content after uploading it?
                    </h4>
                    <p className="mt-2 text-gray-600">
                      Yes, teachers can edit or delete their own content after uploading. Look for edit and delete options on your dashboard or in the content management section.
                    </p>
                  </div>
                  
                  <div className="py-4">
                    <h4 className="font-medium flex items-center">
                      <HelpCircle className="h-4 w-4 mr-2 text-ethio-primary" />
                      Who can see my quiz results?
                    </h4>
                    <p className="mt-2 text-gray-600">
                      Quiz results are visible to you and the teacher who created the quiz. School administrators may also have access to view performance data.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
};

export default About;
