import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { BookOpen, User, FileText, Video, FileClock, GraduationCap, MessageSquare, Library, Eye } from 'lucide-react';
import Header from '@/components/Header';

const StudentDashboard = () => {
  const navigate = useNavigate();
  const [currentUser, setCurrentUser] = useState<any>(null);
  const [schoolData, setSchoolData] = useState<any>(null);
  const [contentStats, setContentStats] = useState({
    notes: 0,
    quizzes: 0,
    videos: 0,
    total: 0
  });
  const [recentContent, setRecentContent] = useState<any[]>([]);
  const [quizzes, setQuizzes] = useState<any[]>([]);

  useEffect(() => {
    const userString = localStorage.getItem('currentUser');
    if (userString) {
      const user = JSON.parse(userString);
      setCurrentUser(user);
      
      const contentString = localStorage.getItem('educationalContent');
      if (contentString) {
        const allContent = JSON.parse(contentString);
        
        const userContent = allContent.filter((content: any) => 
          (content.schoolId === user.schoolId && !content.isPrivate) ||
          (content.isPublic && content.grade === user.grade) ||
          content.isPublicized
        );
        
        const notes = userContent.filter((content: any) => content.type === 'note').length;
        const quizzes = userContent.filter((content: any) => content.type === 'quiz').length;
        const videos = userContent.filter((content: any) => content.type === 'video').length;
        
        setContentStats({
          notes,
          quizzes,
          videos,
          total: userContent.length
        });
        
        const sortedContent = [...userContent]
          .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())
          .slice(0, 5);
        
        setRecentContent(sortedContent);
        
        const availableQuizzes = userContent.filter((content: any) => content.type === 'quiz');
        setQuizzes(availableQuizzes);
      }
      
      const booksString = localStorage.getItem('books');
      if (booksString) {
        const allBooks = JSON.parse(booksString);
        
        const filteredBooks = allBooks.filter((book: any) => 
          book.category !== 'teacherguide' && 
          (book.grade === user.grade || book.grade === 'all')
        );
        
        if (user.role === 'student') {
          localStorage.setItem('studentFilteredBooks', JSON.stringify(filteredBooks));
        }
      }
    }
  }, []);

  const getContentTypeIcon = (type: string) => {
    switch (type) {
      case 'note':
        return <FileText className="h-5 w-5 text-ethio-primary" />;
      case 'quiz':
        return <FileClock className="h-5 w-5 text-ethio-warning" />;
      case 'video':
        return <Video className="h-5 w-5 text-ethio-accent" />;
      default:
        return <BookOpen className="h-5 w-5 text-gray-500" />;
    }
  };

  const handleViewQuiz = (quizId: string) => {
    navigate(`/view-quiz/${quizId}`);
  };

  const handleViewNote = (noteId: string) => {
    navigate(`/view-note/${noteId}`);
  };

  const handleViewVideo = (videoUrl: string) => {
    if (videoUrl) {
      window.open(videoUrl, '_blank');
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      
      <div className="container mx-auto px-4 py-8">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-8">
          <div>
            <h1 className="text-2xl font-bold">Student Dashboard</h1>
            <p className="text-gray-600">
              Welcome, {currentUser?.name}! Access your Grade {currentUser?.grade} learning materials and track your progress.
            </p>
          </div>
          
          <div className="flex flex-wrap gap-2 mt-4 md:mt-0">
            <Link to="/communication">
              <Button variant="outline" className="flex items-center gap-2">
                <MessageSquare className="h-4 w-4" />
                <span>Messages</span>
              </Button>
            </Link>
            <Link to="/book-library">
              <Button variant="outline" className="flex items-center gap-2">
                <Library className="h-4 w-4" />
                <span>Book Library</span>
              </Button>
            </Link>
          </div>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-lg">Total Content</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-center">
                <BookOpen className="h-8 w-8 mr-3 text-ethio-primary" />
                <span className="text-3xl font-bold">{contentStats.total}</span>
              </div>
            </CardContent>
            <CardFooter className="pt-0">
              <span className="text-sm text-gray-500">Available learning materials for Grade {currentUser?.grade}</span>
            </CardFooter>
          </Card>
          
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-lg">Notes</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-center">
                <FileText className="h-8 w-8 mr-3 text-ethio-secondary" />
                <span className="text-3xl font-bold">{contentStats.notes}</span>
              </div>
            </CardContent>
            <CardFooter className="pt-0">
              <span className="text-sm text-gray-500">Study materials</span>
            </CardFooter>
          </Card>
          
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-lg">Quizzes</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-center">
                <FileClock className="h-8 w-8 mr-3 text-ethio-warning" />
                <span className="text-3xl font-bold">{contentStats.quizzes}</span>
              </div>
            </CardContent>
            <CardFooter className="pt-0">
              <span className="text-sm text-gray-500">Assessment tests</span>
            </CardFooter>
          </Card>
          
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-lg">Videos</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-center">
                <Video className="h-8 w-8 mr-3 text-ethio-accent" />
                <span className="text-3xl font-bold">{contentStats.videos}</span>
              </div>
            </CardContent>
            <CardFooter className="pt-0">
              <span className="text-sm text-gray-500">Video lessons</span>
            </CardFooter>
          </Card>
        </div>
        
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2">
            <Card>
              <CardHeader>
                <CardTitle>Recent Content</CardTitle>
                <CardDescription>Latest materials added to your Grade {currentUser?.grade} curriculum including content from schools across the platform</CardDescription>
              </CardHeader>
              <CardContent>
                {recentContent.length > 0 ? (
                  <div className="space-y-4">
                    {recentContent.map((content) => (
                      <div key={content.id} className="flex items-start space-x-4 border-b pb-4">
                        <div className="p-2 bg-gray-100 rounded">
                          {getContentTypeIcon(content.type)}
                        </div>
                        <div className="flex-1">
                          <h3 className="font-medium">{content.title}</h3>
                          <p className="text-sm text-gray-500 mb-1">
                            {content.subject} - Teacher: {content.teacherName}
                          </p>
                          <div className="flex items-center text-xs text-gray-500">
                            <span>Added: {new Date(content.createdAt).toLocaleDateString()}</span>
                            <Badge 
                              variant="outline"
                              className="ml-2 capitalize text-xs bg-gray-50"
                            >
                              {content.type}
                            </Badge>
                            {content.isPublicized && (
                              <Badge 
                                className="ml-2 text-xs bg-purple-100 text-purple-800 border-purple-300"
                              >
                                Publicized
                              </Badge>
                            )}
                          </div>
                        </div>
                        {content.type === 'quiz' ? (
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => handleViewQuiz(content.id)}
                          >
                            <Eye className="h-4 w-4 mr-1" />
                            Take Quiz
                          </Button>
                        ) : content.type === 'note' ? (
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => handleViewNote(content.id)}
                          >
                            <Eye className="h-4 w-4 mr-1" />
                            View Note
                          </Button>
                        ) : content.type === 'video' ? (
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => handleViewVideo(content.videoUrl)}
                          >
                            <Eye className="h-4 w-4 mr-1" />
                            Watch Video
                          </Button>
                        ) : (
                          <Link 
                            to="/content-library"
                            className="shrink-0"
                          >
                            <Button variant="ghost" size="sm">
                              <Eye className="h-4 w-4 mr-1" />
                              View
                            </Button>
                          </Link>
                        )}
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-8 text-gray-500">
                    <BookOpen className="h-12 w-12 mx-auto mb-3 text-gray-300" />
                    <p>No content available for your Grade {currentUser?.grade} yet</p>
                  </div>
                )}
              </CardContent>
              {recentContent.length > 0 && (
                <CardFooter>
                  <Link to="/content-library">
                    <Button variant="outline" className="w-full">Browse All Content</Button>
                  </Link>
                </CardFooter>
              )}
            </Card>
          </div>
          
          <div>
            <Card>
              <CardHeader>
                <CardTitle>Your Information</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center p-4 bg-gray-50 rounded-lg">
                  <GraduationCap className="h-10 w-10 text-ethio-accent mr-4" />
                  <div>
                    <p className="font-medium">{currentUser?.name}</p>
                    <p className="text-sm text-gray-500">Student ID: {currentUser?.username}</p>
                    <p className="text-sm text-gray-500">Grade: {currentUser?.grade}</p>
                  </div>
                </div>
                
                <div>
                  <h3 className="text-sm font-medium text-gray-500 mb-2">School</h3>
                  <p className="font-medium">{schoolData?.schoolName}</p>
                  <p className="text-sm text-gray-500 capitalize">{schoolData?.schoolType} School</p>
                </div>
              </CardContent>
            </Card>
            
            <Card className="mt-6">
              <CardHeader>
                <CardTitle>Available Quizzes</CardTitle>
              </CardHeader>
              <CardContent>
                {quizzes.length > 0 ? (
                  <div className="space-y-3">
                    {quizzes.map((quiz) => (
                      <div key={quiz.id} className="flex items-center justify-between border-b pb-3">
                        <div>
                          <p className="font-medium">{quiz.title}</p>
                          <p className="text-xs text-gray-500">{quiz.subject}</p>
                          {quiz.timeLimit && (
                            <p className="text-xs text-gray-500">Time: {quiz.timeLimit} min</p>
                          )}
                        </div>
                        <Button 
                          variant="outline" 
                          size="sm"
                          onClick={() => handleViewQuiz(quiz.id)}
                        >
                          Take Quiz
                        </Button>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-4 text-gray-500">
                    <p>No quizzes available yet</p>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
};

export default StudentDashboard;
