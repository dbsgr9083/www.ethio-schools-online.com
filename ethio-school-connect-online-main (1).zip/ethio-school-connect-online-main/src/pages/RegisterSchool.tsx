
import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { toast } from 'sonner';
import Header from '@/components/Header';
import { v4 as uuidv4 } from 'uuid';
import { supabase } from '@/integrations/supabase/client';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { AlertCircle, Upload, Info } from 'lucide-react';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';

const RegisterSchool = () => {
  const navigate = useNavigate();
  const [formData, setFormData] = useState({
    schoolName: '',
    schoolType: 'government',
    email: '',
    phone: '',
    address: '',
    principalName: '',
    licenseNumber: '', // Added license number field
  });
  
  const [activeTab, setActiveTab] = useState('details');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [paymentMethods, setPaymentMethods] = useState<any[]>([]);
  const [receiptFile, setReceiptFile] = useState<File | null>(null);
  const [transactionNumber, setTransactionNumber] = useState('');
  const [selectedPaymentMethod, setSelectedPaymentMethod] = useState('');
  const [isUploading, setIsUploading] = useState(false);
  const [schoolId, setSchoolId] = useState<string>('');

  // Load payment methods on component mount
  useEffect(() => {
    fetchPaymentMethods();
  }, []);

  const fetchPaymentMethods = async () => {
    try {
      const { data, error } = await supabase
        .from('payment_settings')
        .select('*');
        
      if (error) {
        console.error('Error fetching payment methods:', error);
        return;
      }
      
      setPaymentMethods(data || []);
      if (data && data.length > 0) {
        setSelectedPaymentMethod(data[0].id);
      }
    } catch (error) {
      console.error('Error:', error);
    }
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSelectChange = (name: string, value: string) => {
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      // Check file size (5MB limit)
      if (file.size > 5 * 1024 * 1024) {
        toast.error('File size exceeds 5MB limit');
        return;
      }
      setReceiptFile(file);
    }
  };

  const validateSchoolDetails = () => {
    // Validate form
    const requiredFields = ['schoolName', 'email', 'phone', 'address', 'principalName', 'licenseNumber'];
    const missingFields = requiredFields.filter(field => !formData[field as keyof typeof formData]);
    
    if (missingFields.length > 0) {
      toast.error("Please fill in all required fields");
      return false;
    }
    
    // Email validation
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(formData.email)) {
      toast.error("Please enter a valid email address");
      return false;
    }
    
    // License number validation - ensure it's provided
    if (!formData.licenseNumber.trim()) {
      toast.error("Please enter your school license number");
      return false;
    }
    
    return true;
  };

  const validatePaymentDetails = () => {
    if (!selectedPaymentMethod) {
      toast.error("Please select a payment method");
      return false;
    }

    if (!transactionNumber) {
      toast.error("Please enter the transaction number");
      return false;
    }

    if (!receiptFile) {
      toast.error("Please upload the receipt file");
      return false;
    }

    return true;
  };

  const uploadReceiptFile = async (schoolId: string) => {
    if (!receiptFile) return null;
    
    setIsUploading(true);
    
    try {
      const fileExt = receiptFile.name.split('.').pop();
      const fileName = `receipts/${schoolId}-${Date.now()}.${fileExt}`;
      
      const { error: uploadError, data } = await supabase.storage
        .from('school_receipts')
        .upload(fileName, receiptFile);
        
      if (uploadError) {
        console.error('Error uploading receipt:', uploadError);
        toast.error('Failed to upload receipt file');
        setIsUploading(false);
        return null;
      }
      
      setIsUploading(false);
      return fileName;
    } catch (error) {
      console.error('Upload error:', error);
      toast.error('An error occurred during file upload');
      setIsUploading(false);
      return null;
    }
  };

  const savePaymentRecord = async (schoolId: string, receiptPath: string | null) => {
    try {
      const selectedMethod = paymentMethods.find(method => method.id === selectedPaymentMethod);
      
      const { error } = await supabase
        .from('school_payments')
        .insert({
          school_id: schoolId,
          amount: 1000, // 1,000 ETB fixed amount
          currency: 'ETB',
          transaction_number: transactionNumber,
          payment_method: selectedMethod ? selectedMethod.bank_name : 'Other',
          receipt_file_path: receiptPath,
          payment_status: 'pending',
          admin_verified: false
        });
        
      if (error) {
        console.error('Error saving payment record:', error);
        toast.error('Failed to save payment information');
        return false;
      }
      
      return true;
    } catch (error) {
      console.error('Payment record error:', error);
      toast.error('An error occurred while saving payment information');
      return false;
    }
  };

  const handleDetailsSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!validateSchoolDetails()) {
      return;
    }
    
    // Generate a unique ID for the school
    const newSchoolId = uuidv4();
    setSchoolId(newSchoolId);
    
    // Move to the payment tab
    setActiveTab('payment');
  };

  const handlePaymentSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!validatePaymentDetails()) {
      return;
    }
    
    setIsSubmitting(true);
    
    // Upload receipt file
    const receiptPath = await uploadReceiptFile(schoolId);
    
    if (!receiptPath) {
      setIsSubmitting(false);
      return;
    }
    
    // Save the school registration
    const newRegistration = {
      id: schoolId,
      ...formData,
      status: 'pending',
      setupComplete: false,
      createdAt: new Date().toISOString(),
      users: []
    };
    
    try {
      // Get existing registrations
      const existingRegistrationsString = localStorage.getItem('schoolRegistrations');
      const existingRegistrations = existingRegistrationsString 
        ? JSON.parse(existingRegistrationsString) 
        : [];
      
      // Check if school with same name or license already exists
      const nameExists = existingRegistrations.some(
        (reg: any) => reg.schoolName.toLowerCase() === formData.schoolName.toLowerCase()
      );
      
      const licenseExists = existingRegistrations.some(
        (reg: any) => reg.licenseNumber === formData.licenseNumber
      );
      
      if (nameExists) {
        toast.error("A school with this name is already registered");
        setIsSubmitting(false);
        return;
      }
      
      if (licenseExists) {
        toast.error("A school with this license number is already registered");
        setIsSubmitting(false);
        return;
      }
      
      // Save payment record
      const paymentSaved = await savePaymentRecord(schoolId, receiptPath);
      
      if (!paymentSaved) {
        setIsSubmitting(false);
        return;
      }
      
      // Add new registration
      existingRegistrations.push(newRegistration);
      localStorage.setItem('schoolRegistrations', JSON.stringify(existingRegistrations));
      
      // Success
      toast.success("School registration and payment submitted successfully! Please wait for administrator approval.");
      setTimeout(() => {
        navigate('/');
      }, 2000);
    } catch (error) {
      console.error("Registration error:", error);
      toast.error("There was an error submitting your registration. Please try again.");
      setIsSubmitting(false);
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      
      <div className="container mx-auto px-4 py-12">
        <Card className="max-w-2xl mx-auto">
          <CardHeader>
            <CardTitle>Register Your School</CardTitle>
            <CardDescription>
              Complete this form to register your school with Ethio-Schools Online. 
              Your application will be reviewed by our system administrators.
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
              <TabsList className="grid w-full grid-cols-2">
                <TabsTrigger value="details">School Details</TabsTrigger>
                <TabsTrigger value="payment" disabled={!schoolId}>Payment (1,000 ETB)</TabsTrigger>
              </TabsList>
              
              <TabsContent value="details">
                <form onSubmit={handleDetailsSubmit} className="space-y-4 mt-4">
                  <div className="space-y-2">
                    <Label htmlFor="schoolName">School Name *</Label>
                    <Input
                      id="schoolName"
                      name="schoolName"
                      value={formData.schoolName}
                      onChange={handleInputChange}
                      placeholder="Enter school name"
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="schoolType">School Type *</Label>
                    <Select
                      value={formData.schoolType}
                      onValueChange={(value) => handleSelectChange('schoolType', value)}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Select school type" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="government">Government</SelectItem>
                        <SelectItem value="private">Private</SelectItem>
                        <SelectItem value="faith_based">Faith-based</SelectItem>
                        <SelectItem value="international">International</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="licenseNumber">School License Number *</Label>
                    <Input
                      id="licenseNumber"
                      name="licenseNumber"
                      value={formData.licenseNumber}
                      onChange={handleInputChange}
                      placeholder="Enter school license number"
                    />
                    <p className="text-xs text-gray-500">
                      Enter the official license number issued by the Ministry of Education
                    </p>
                  </div>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="email">Email Address *</Label>
                      <Input
                        id="email"
                        name="email"
                        type="email"
                        value={formData.email}
                        onChange={handleInputChange}
                        placeholder="Enter school email"
                      />
                    </div>
                    
                    <div className="space-y-2">
                      <Label htmlFor="phone">Phone Number *</Label>
                      <Input
                        id="phone"
                        name="phone"
                        value={formData.phone}
                        onChange={handleInputChange}
                        placeholder="Enter phone number"
                      />
                    </div>
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="address">School Address *</Label>
                    <Textarea
                      id="address"
                      name="address"
                      value={formData.address}
                      onChange={handleInputChange}
                      placeholder="Enter full school address"
                      rows={3}
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="principalName">Principal/Director Name *</Label>
                    <Input
                      id="principalName"
                      name="principalName"
                      value={formData.principalName}
                      onChange={handleInputChange}
                      placeholder="Enter principal or director name"
                    />
                  </div>
                  
                  <div className="pt-4">
                    <Button type="submit" className="w-full">
                      Continue to Payment
                    </Button>
                  </div>
                </form>
              </TabsContent>
              
              <TabsContent value="payment">
                <form onSubmit={handlePaymentSubmit} className="space-y-4 mt-4">
                  <Alert className="mb-6">
                    <AlertCircle className="h-4 w-4" />
                    <AlertTitle>Registration Fee Required</AlertTitle>
                    <AlertDescription>
                      A one-time registration fee of 1,000 ETB is required to process your school registration.
                    </AlertDescription>
                  </Alert>
                  
                  <div className="space-y-2">
                    <Label htmlFor="paymentMethod">Payment Method *</Label>
                    <Select
                      value={selectedPaymentMethod}
                      onValueChange={setSelectedPaymentMethod}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Select payment method" />
                      </SelectTrigger>
                      <SelectContent>
                        {paymentMethods.map((method) => (
                          <SelectItem key={method.id} value={method.id}>
                            {method.bank_name} {method.is_telebirr ? "(TeleBirr)" : ""}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  
                  {selectedPaymentMethod && (
                    <div className="bg-blue-50 p-4 rounded-md">
                      <div className="flex items-start gap-2">
                        <Info className="h-5 w-5 text-blue-500 mt-0.5" />
                        <div>
                          <h3 className="font-medium text-blue-800">Payment Instructions</h3>
                          {paymentMethods.filter(m => m.id === selectedPaymentMethod).map((method) => (
                            <div key={method.id} className="mt-2 text-sm text-blue-800">
                              <p><strong>{method.bank_name}</strong></p>
                              <p><strong>Account Name:</strong> {method.account_name}</p>
                              <p><strong>{method.is_telebirr ? "Phone" : "Account"} Number:</strong> {method.account_number}</p>
                              <p className="mt-2 text-xs">Please transfer exactly 1,000 ETB to this account and enter the transaction details below.</p>
                            </div>
                          ))}
                        </div>
                      </div>
                    </div>
                  )}
                  
                  <div className="space-y-2">
                    <Label htmlFor="transactionNumber">Transaction/Reference Number *</Label>
                    <Input
                      id="transactionNumber"
                      value={transactionNumber}
                      onChange={(e) => setTransactionNumber(e.target.value)}
                      placeholder="Enter transaction reference number"
                    />
                    <p className="text-xs text-gray-500">
                      Enter the reference number from your bank transfer or TeleBirr payment
                    </p>
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="receiptFile">Upload Receipt/Screenshot *</Label>
                    <div className="border-2 border-dashed border-gray-300 rounded-md p-6 text-center">
                      <Input
                        id="receiptFile"
                        type="file"
                        className="hidden"
                        onChange={handleFileChange}
                        accept="image/png, image/jpeg, image/jpg, application/pdf"
                      />
                      <label 
                        htmlFor="receiptFile" 
                        className="cursor-pointer flex flex-col items-center justify-center"
                      >
                        <Upload className="h-8 w-8 text-gray-400 mb-2" />
                        {receiptFile ? (
                          <span className="text-sm font-medium text-blue-600">{receiptFile.name}</span>
                        ) : (
                          <span className="text-sm text-gray-500">Click to upload receipt (PNG, JPEG, PDF)</span>
                        )}
                        <span className="text-xs text-gray-400 mt-1">Max size: 5MB</span>
                      </label>
                    </div>
                  </div>
                  
                  <div className="pt-4">
                    <Button 
                      type="submit" 
                      className="w-full" 
                      disabled={isSubmitting || isUploading}
                    >
                      {isSubmitting || isUploading ? "Processing..." : "Submit Registration & Payment"}
                    </Button>
                  </div>
                </form>
              </TabsContent>
            </Tabs>
          </CardContent>
          <CardFooter className="flex flex-col items-start border-t pt-6">
            <h3 className="font-semibold text-sm mb-2">What happens next?</h3>
            <ol className="list-decimal list-inside text-sm text-gray-600 space-y-1">
              <li>Your payment and registration will be reviewed by system administrators</li>
              <li>Upon approval, you'll receive admin credentials via email</li>
              <li>You can then login and manage your school's digital platform</li>
            </ol>
          </CardFooter>
        </Card>
      </div>
    </div>
  );
};

export default RegisterSchool;
