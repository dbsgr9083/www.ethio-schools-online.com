
import React, { useState, useEffect } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { BookOpen, FileText, User, Calendar, AlertCircle } from 'lucide-react';
import Header from '@/components/Header';

const ViewNote = () => {
  const navigate = useNavigate();
  const { noteId } = useParams<{ noteId: string }>();
  const [currentUser, setCurrentUser] = useState<any>(null);
  const [note, setNote] = useState<any>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const userString = localStorage.getItem('currentUser');
    if (userString) {
      const user = JSON.parse(userString);
      setCurrentUser(user);
      
      // Load note
      const contentString = localStorage.getItem('educationalContent');
      if (contentString && noteId) {
        const allContent = JSON.parse(contentString);
        const noteContent = allContent.find((content: any) => content.id === noteId && content.type === 'note');
        
        if (noteContent) {
          setNote(noteContent);
        } else {
          navigate('/content-library');
        }
      }
    } else {
      navigate('/');
    }
    
    setIsLoading(false);
  }, [noteId, navigate]);

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-ethio-primary mx-auto"></div>
          <p className="mt-4 text-gray-600">Loading note...</p>
        </div>
      </div>
    );
  }

  if (!note) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="text-center">
          <AlertCircle className="h-12 w-12 text-red-500 mx-auto" />
          <h2 className="mt-4 text-xl font-bold">Note Not Found</h2>
          <p className="mt-2 text-gray-600">The note you're looking for doesn't exist or has been removed.</p>
          <Button 
            className="mt-4"
            onClick={() => navigate('/content-library')}
          >
            Return to Content Library
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      
      <div className="container mx-auto px-4 py-8">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-8">
          <div>
            <h1 className="text-2xl font-bold">{note.title}</h1>
            <p className="text-gray-600">
              {note.subject} - Grade {note.grade}
            </p>
          </div>
          
          <Button 
            variant="outline" 
            onClick={() => navigate('/content-library')} 
            className="mt-4 md:mt-0"
          >
            Back to Content Library
          </Button>
        </div>
        
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
          <div className="lg:col-span-3">
            <Card>
              <CardHeader>
                <CardTitle>Note Content</CardTitle>
                <div className="flex flex-wrap items-center gap-2 mt-2">
                  <Badge variant="outline">Grade {note.grade}</Badge>
                  <Badge variant="outline">{note.subject}</Badge>
                  {note.isPublicized && (
                    <Badge className="bg-purple-100 text-purple-800 border-purple-300">
                      Publicized
                    </Badge>
                  )}
                </div>
              </CardHeader>
              <CardContent>
                <div className="bg-white p-6 rounded-md border border-gray-200">
                  <pre className="whitespace-pre-wrap font-sans text-gray-800">
                    {note.content}
                  </pre>
                </div>
              </CardContent>
            </Card>
          </div>
          
          <div>
            <Card>
              <CardHeader>
                <CardTitle>Note Information</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center gap-2">
                  <FileText className="h-4 w-4 text-gray-500" />
                  <span className="text-sm font-medium">Study Note</span>
                </div>
                
                <div>
                  <h3 className="text-sm font-medium text-gray-500">Teacher</h3>
                  <div className="flex items-center mt-1">
                    <User className="h-4 w-4 mr-2 text-gray-500" />
                    <span>{note.teacherName}</span>
                  </div>
                </div>
                
                <div>
                  <h3 className="text-sm font-medium text-gray-500">Date Added</h3>
                  <div className="flex items-center mt-1">
                    <Calendar className="h-4 w-4 mr-2 text-gray-500" />
                    <span>{new Date(note.createdAt).toLocaleDateString()}</span>
                  </div>
                </div>
                
                {note.description && (
                  <div>
                    <h3 className="text-sm font-medium text-gray-500">Description</h3>
                    <p className="text-sm mt-1">{note.description}</p>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ViewNote;
