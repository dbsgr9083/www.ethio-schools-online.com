
import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Users, User, GraduationCap, BookOpen, CheckCircle2, Plus, MessageSquare, Briefcase } from 'lucide-react';
import Header from '@/components/Header';
import SchoolActivityLog from '@/components/SchoolActivityLog';

const SchoolAdminDashboard = () => {
  const [currentUser, setCurrentUser] = useState<any>(null);
  const [schoolData, setSchoolData] = useState<any>(null);
  const [stats, setStats] = useState({
    totalTeachers: 0,
    totalStudents: 0,
    totalContent: 0
  });

  useEffect(() => {
    // Get current user
    const userString = localStorage.getItem('currentUser');
    if (userString) {
      const user = JSON.parse(userString);
      setCurrentUser(user);
      
      // Load school data
      const schoolRegistrationsString = localStorage.getItem('schoolRegistrations');
      if (schoolRegistrationsString) {
        const schoolRegistrations = JSON.parse(schoolRegistrationsString);
        const school = schoolRegistrations.find((s: any) => s.id === user.schoolId);
        
        if (school) {
          setSchoolData(school);
          
          // Calculate statistics
          const teacherCount = school.users ? school.users.filter((u: any) => u.role === 'teacher').length : 0;
          const studentCount = school.users ? school.users.filter((u: any) => u.role === 'student').length : 0;
          
          // Count educational content for this school
          const contentString = localStorage.getItem('educationalContent');
          const content = contentString ? JSON.parse(contentString) : [];
          const schoolContent = content.filter((c: any) => c.schoolId === user.schoolId);
          
          setStats({
            totalTeachers: teacherCount,
            totalStudents: studentCount,
            totalContent: schoolContent.length
          });
        }
      }
    }
  }, []);

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      
      <div className="container mx-auto px-4 py-8">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-8">
          <div>
            <h1 className="text-2xl font-bold">School Administrator Dashboard</h1>
            <p className="text-gray-600">
              Manage {schoolData?.schoolName || 'your school'}'s teachers, students, and content
            </p>
          </div>
          
          <div className="mt-4 md:mt-0 flex gap-2">
            <Link to="/manage-users">
              <Button className="flex items-center gap-2">
                <Users className="h-4 w-4" />
                <span>Manage Users</span>
              </Button>
            </Link>
            <Link to="/communication">
              <Button variant="outline" className="flex items-center gap-2">
                <MessageSquare className="h-4 w-4" />
                <span>Communication</span>
              </Button>
            </Link>
          </div>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-lg">Teachers</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-center">
                <User className="h-8 w-8 mr-3 text-ethio-primary" />
                <span className="text-3xl font-bold">{stats.totalTeachers}</span>
              </div>
            </CardContent>
            <CardFooter className="pt-0">
              <Link to="/manage-users?tab=teachers" className="text-sm text-ethio-primary hover:underline">
                Manage Teachers
              </Link>
            </CardFooter>
          </Card>
          
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-lg">Students</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-center">
                <GraduationCap className="h-8 w-8 mr-3 text-ethio-accent" />
                <span className="text-3xl font-bold">{stats.totalStudents}</span>
              </div>
            </CardContent>
            <CardFooter className="pt-0">
              <Link to="/manage-users?tab=students" className="text-sm text-ethio-primary hover:underline">
                Manage Students
              </Link>
            </CardFooter>
          </Card>
          
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-lg">Educational Content</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-center">
                <BookOpen className="h-8 w-8 mr-3 text-ethio-secondary" />
                <span className="text-3xl font-bold">{stats.totalContent}</span>
              </div>
            </CardContent>
            <CardFooter className="pt-0">
              <Link to="/content-library" className="text-sm text-ethio-primary hover:underline">
                View Content Library
              </Link>
            </CardFooter>
          </Card>
        </div>
        
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 mb-8">
          <div className="lg:col-span-2">
            <Card>
              <CardHeader>
                <CardTitle>School Information</CardTitle>
                <CardDescription>Details about your school</CardDescription>
              </CardHeader>
              <CardContent>
                {schoolData ? (
                  <div className="space-y-4">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <h3 className="text-sm font-medium text-gray-500">School Name</h3>
                        <p>{schoolData.schoolName}</p>
                      </div>
                      <div>
                        <h3 className="text-sm font-medium text-gray-500">School Type</h3>
                        <p className="capitalize">{schoolData.schoolType}</p>
                      </div>
                    </div>
                    
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <h3 className="text-sm font-medium text-gray-500">License Number</h3>
                        <p>{schoolData.licenseNumber}</p>
                      </div>
                      <div>
                        <h3 className="text-sm font-medium text-gray-500">Email</h3>
                        <p>{schoolData.email}</p>
                      </div>
                    </div>
                    
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <h3 className="text-sm font-medium text-gray-500">Phone</h3>
                        <p>{schoolData.phone}</p>
                      </div>
                      <div>
                        <h3 className="text-sm font-medium text-gray-500">Principal/Director</h3>
                        <p>{schoolData.principalName}</p>
                      </div>
                    </div>
                    
                    <div>
                      <h3 className="text-sm font-medium text-gray-500">Address</h3>
                      <p>{schoolData.address}</p>
                    </div>
                    
                    <div>
                      <h3 className="text-sm font-medium text-gray-500">Registration Date</h3>
                      <p>{new Date(schoolData.createdAt).toLocaleDateString()}</p>
                    </div>
                  </div>
                ) : (
                  <div className="text-center py-8 text-gray-500">
                    <p>School information not available.</p>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
          
          <div>
            <Card>
              <CardHeader>
                <CardTitle>Quick Actions</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <Link to="/manage-users?tab=teachers">
                  <Button variant="outline" className="w-full justify-start">
                    <Plus className="h-4 w-4 mr-2" />
                    Add New Teacher
                  </Button>
                </Link>
                <Link to="/manage-users?tab=students">
                  <Button variant="outline" className="w-full justify-start">
                    <Plus className="h-4 w-4 mr-2" />
                    Add New Student
                  </Button>
                </Link>
                <Link to="/content-library">
                  <Button variant="outline" className="w-full justify-start">
                    <BookOpen className="h-4 w-4 mr-2" />
                    Browse Content Library
                  </Button>
                </Link>
                <Link to="/communication?tab=jobs">
                  <Button variant="outline" className="w-full justify-start">
                    <Briefcase className="h-4 w-4 mr-2" />
                    Post Job Vacancy
                  </Button>
                </Link>
                <Link to="/communication">
                  <Button variant="outline" className="w-full justify-start">
                    <MessageSquare className="h-4 w-4 mr-2" />
                    Message Teachers
                  </Button>
                </Link>
              </CardContent>
            </Card>
            
            <Card className="mt-6">
              <CardHeader>
                <CardTitle>Status</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex items-center">
                  <CheckCircle2 className="h-5 w-5 text-ethio-secondary mr-2" />
                  <span className="text-sm">Your school is active</span>
                </div>
                <div className="mt-2">
                  <Badge variant="outline" className="bg-green-50 text-green-700 hover:bg-green-50">
                    Approved
                  </Badge>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
        
        {currentUser && currentUser.schoolId && (
          <div className="mt-8">
            <SchoolActivityLog schoolId={currentUser.schoolId} />
          </div>
        )}
      </div>
    </div>
  );
};

export default SchoolAdminDashboard;
