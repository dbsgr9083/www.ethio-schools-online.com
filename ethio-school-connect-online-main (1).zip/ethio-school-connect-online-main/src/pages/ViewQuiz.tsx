
import React, { useState, useEffect } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { 
  Dialog, 
  DialogContent, 
  DialogDescription, 
  DialogFooter, 
  DialogHeader, 
  DialogTitle 
} from "@/components/ui/dialog";
import { Progress } from '@/components/ui/progress';
import { toast } from 'sonner';
import { CheckCircle2, ChevronRight, AlertCircle, Trophy, FileText, User, Clock, RepeatIcon } from 'lucide-react';
import Header from '@/components/Header';

const ViewQuiz = () => {
  const navigate = useNavigate();
  const { quizId } = useParams<{ quizId: string }>();
  const [currentUser, setCurrentUser] = useState<any>(null);
  const [quiz, setQuiz] = useState<any>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [selectedOptions, setSelectedOptions] = useState<number[]>([]);
  const [quizCompleted, setQuizCompleted] = useState(false);
  const [results, setResults] = useState({
    score: 0,
    total: 0,
    percentage: 0,
    correctAnswers: 0,
    incorrectAnswers: 0
  });
  const [isResultsDialogOpen, setIsResultsDialogOpen] = useState(false);
  const [timeLeft, setTimeLeft] = useState<number | null>(null);
  const [timeStarted, setTimeStarted] = useState<number | null>(null);
  const [previousAttempts, setPreviousAttempts] = useState<any[]>([]);
  const [attemptCount, setAttemptCount] = useState(0);
  const [attemptsExceeded, setAttemptsExceeded] = useState(false);

  useEffect(() => {
    // Get current user
    const userString = localStorage.getItem('currentUser');
    if (userString) {
      const user = JSON.parse(userString);
      setCurrentUser(user);
      
      // Load quiz
      const contentString = localStorage.getItem('educationalContent');
      if (contentString && quizId) {
        const allContent = JSON.parse(contentString);
        const quizContent = allContent.find((content: any) => content.id === quizId && content.type === 'quiz');
        
        if (quizContent) {
          setQuiz(quizContent);
          // Initialize selected options array with -1 (no selection) for each question
          setSelectedOptions(new Array(quizContent.questions.length).fill(-1));
          
          // Set time limit if exists, or default to 2 minutes per question
          if (quizContent.timeLimit) {
            setTimeLeft(quizContent.timeLimit * 60); // Convert minutes to seconds
          } else {
            // Default to 2 minutes per question if no time limit is set
            const defaultTimeLimit = quizContent.questions.length * 2; // 2 minutes per question
            setTimeLeft(defaultTimeLimit * 60); // Convert minutes to seconds
          }
          setTimeStarted(Date.now());
          
          // Check previous attempts
          checkPreviousAttempts(user.id, quizContent.id, quizContent.attemptLimit);
        } else {
          toast.error('Quiz not found');
          navigate('/content-library');
        }
      }
    } else {
      navigate('/');
    }
    
    setIsLoading(false);
  }, [quizId, navigate]);

  const checkPreviousAttempts = (userId: string, quizId: string, attemptLimit: number | null) => {
    const quizResultsString = localStorage.getItem('quizResults');
    if (quizResultsString) {
      const allResults = JSON.parse(quizResultsString);
      const userAttempts = allResults.filter((result: any) => 
        result.studentId === userId && result.quizId === quizId
      );
      
      setPreviousAttempts(userAttempts);
      setAttemptCount(userAttempts.length);
      
      // Check if attempts exceeded
      if (attemptLimit !== null && userAttempts.length >= attemptLimit) {
        setAttemptsExceeded(true);
        toast.error(`You have reached the maximum number of attempts (${attemptLimit}) for this quiz`);
      }
    }
  };

  useEffect(() => {
    let timerId: number | undefined;
    
    if (timeLeft !== null && timeLeft > 0 && !quizCompleted) {
      timerId = window.setInterval(() => {
        setTimeLeft((prev) => {
          if (prev !== null && prev <= 1) {
            clearInterval(timerId);
            // Auto-submit when time runs out
            calculateResults();
            return 0;
          }
          return prev !== null ? prev - 1 : null;
        });
      }, 1000);
    }
    
    return () => {
      if (timerId) clearInterval(timerId);
    };
  }, [timeLeft, quizCompleted]);

  const handleOptionSelect = (optionIndex: number) => {
    const newSelectedOptions = [...selectedOptions];
    newSelectedOptions[currentQuestion] = optionIndex;
    setSelectedOptions(newSelectedOptions);
  };

  const handleNextQuestion = () => {
    if (selectedOptions[currentQuestion] === -1) {
      toast.error('Please select an answer');
      return;
    }
    
    if (currentQuestion < quiz.questions.length - 1) {
      setCurrentQuestion(currentQuestion + 1);
    } else {
      // Last question, calculate results
      calculateResults();
    }
  };

  const calculateResults = () => {
    let correctCount = 0;
    
    quiz.questions.forEach((question: any, index: number) => {
      if (selectedOptions[index] === question.correctOption) {
        correctCount++;
      }
    });
    
    const percentage = (correctCount / quiz.questions.length) * 100;
    
    const resultData = {
      score: correctCount,
      total: quiz.questions.length,
      percentage,
      correctAnswers: correctCount,
      incorrectAnswers: quiz.questions.length - correctCount
    };
    
    setResults(resultData);
    setQuizCompleted(true);
    setIsResultsDialogOpen(true);
    
    // Save quiz result to localStorage
    saveQuizResult(resultData);
  };

  const saveQuizResult = (resultData: any) => {
    // Get existing quiz results or initialize empty array
    const quizResultsString = localStorage.getItem('quizResults');
    const quizResults = quizResultsString ? JSON.parse(quizResultsString) : [];
    
    // Create new result entry
    const newResult = {
      id: crypto.randomUUID(),
      quizId: quizId,
      quizTitle: quiz.title,
      studentId: currentUser.id,
      studentName: currentUser.name,
      schoolId: currentUser.schoolId,
      grade: currentUser.grade || 'N/A',
      completedAt: new Date().toISOString(),
      timeSpent: timeStarted ? Math.floor((Date.now() - timeStarted) / 1000) : null,
      attemptNumber: attemptCount + 1,
      ...resultData
    };
    
    // Add to results array
    quizResults.push(newResult);
    
    // Save back to localStorage
    localStorage.setItem('quizResults', JSON.stringify(quizResults));
    
    // Update attempt count
    setAttemptCount(prevCount => prevCount + 1);
    
    // Show success message
    toast.success('Quiz completed and results saved');
  };

  const handleRestartQuiz = () => {
    // Check if the user has reached the attempt limit
    if (quiz.attemptLimit !== null && attemptCount >= quiz.attemptLimit) {
      toast.error(`You have reached the maximum number of attempts (${quiz.attemptLimit}) for this quiz`);
      setIsResultsDialogOpen(false);
      setAttemptsExceeded(true);
      return;
    }
    
    setCurrentQuestion(0);
    setSelectedOptions(new Array(quiz.questions.length).fill(-1));
    setQuizCompleted(false);
    setIsResultsDialogOpen(false);
    
    // Reset timer if there was a time limit
    if (quiz.timeLimit) {
      setTimeLeft(quiz.timeLimit * 60);
      setTimeStarted(Date.now());
    }
  };

  const getResultMessage = () => {
    const percentage = results.percentage;
    
    if (percentage >= 90) {
      return "Excellent work! Outstanding performance!";
    } else if (percentage >= 80) {
      return "Great job! You have a strong understanding of the material.";
    } else if (percentage >= 70) {
      return "Good work! You've grasped most of the concepts.";
    } else if (percentage >= 60) {
      return "Not bad! Keep practicing to improve your understanding.";
    } else {
      return "You might want to review the material and try again.";
    }
  };

  const formatTime = (seconds: number): string => {
    const minutes = Math.floor(seconds / 60);
    const remainingSeconds = seconds % 60;
    return `${minutes}:${remainingSeconds < 10 ? '0' : ''}${remainingSeconds}`;
  };

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-ethio-primary mx-auto"></div>
          <p className="mt-4 text-gray-600">Loading quiz...</p>
        </div>
      </div>
    );
  }

  if (!quiz) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="text-center">
          <AlertCircle className="h-12 w-12 text-red-500 mx-auto" />
          <h2 className="mt-4 text-xl font-bold">Quiz Not Found</h2>
          <p className="mt-2 text-gray-600">The quiz you're looking for doesn't exist or has been removed.</p>
          <Button 
            className="mt-4"
            onClick={() => navigate('/content-library')}
          >
            Return to Content Library
          </Button>
        </div>
      </div>
    );
  }

  if (attemptsExceeded) {
    return (
      <div className="min-h-screen bg-gray-50">
        <Header />
        
        <div className="container mx-auto px-4 py-12">
          <div className="max-w-md mx-auto bg-white rounded-lg shadow-md p-8 text-center">
            <AlertCircle className="h-16 w-16 text-amber-500 mx-auto mb-4" />
            <h2 className="text-2xl font-bold text-gray-800 mb-2">Maximum Attempts Reached</h2>
            <p className="text-gray-600 mb-6">
              You have reached the maximum number of attempts ({quiz.attemptLimit}) for this quiz.
            </p>
            
            <div className="bg-gray-50 p-4 rounded-lg mb-6">
              <h3 className="font-medium text-gray-700 mb-2">Your Past Attempts</h3>
              <div className="space-y-2">
                {previousAttempts.map((attempt, index) => (
                  <div key={attempt.id} className="bg-white p-3 rounded-md border border-gray-200">
                    <div className="flex justify-between items-center">
                      <span className="text-sm font-medium">Attempt {index + 1}</span>
                      <span className="text-sm font-bold">{attempt.percentage.toFixed(0)}%</span>
                    </div>
                    <div className="flex justify-between items-center text-xs text-gray-500">
                      <span>{new Date(attempt.completedAt).toLocaleDateString()}</span>
                      <span>{attempt.correctAnswers}/{attempt.total} correct</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
            
            <Button
              onClick={() => navigate('/content-library')}
              className="w-full"
            >
              Return to Content Library
            </Button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      
      <div className="container mx-auto px-4 py-8">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-8">
          <div>
            <h1 className="text-2xl font-bold">{quiz.title}</h1>
            <p className="text-gray-600">
              {quiz.subject} - Grade {quiz.grade}
            </p>
          </div>
          
          <Button 
            variant="outline" 
            onClick={() => navigate('/content-library')} 
            className="mt-4 md:mt-0"
          >
            Back to Content Library
          </Button>
        </div>
        
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
          <div className="lg:col-span-3">
            <Card>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle>Question {currentQuestion + 1} of {quiz.questions.length}</CardTitle>
                  <span className="text-sm font-medium text-gray-500">
                    {Math.round((currentQuestion / quiz.questions.length) * 100)}% Complete
                  </span>
                </div>
                <Progress 
                  value={(currentQuestion / quiz.questions.length) * 100} 
                  className="h-2 mt-2"
                />
                {timeLeft !== null && (
                  <div className="flex items-center mt-2 text-sm text-ethio-warning font-medium">
                    <Clock className="h-4 w-4 mr-1" />
                    Time remaining: {formatTime(timeLeft)}
                  </div>
                )}
              </CardHeader>
              <CardContent className="pt-6">
                <div className="mb-6">
                  <h2 className="text-xl font-medium mb-4">{quiz.questions[currentQuestion].question}</h2>
                  
                  <div className="space-y-3">
                    {quiz.questions[currentQuestion].options.map((option: string, index: number) => (
                      <div 
                        key={index}
                        className={`
                          border rounded-lg p-4 cursor-pointer transition-all
                          ${selectedOptions[currentQuestion] === index 
                            ? 'border-ethio-primary bg-blue-50' 
                            : 'border-gray-200 hover:border-gray-300 hover:bg-gray-50'}
                        `}
                        onClick={() => handleOptionSelect(index)}
                      >
                        <div className="flex items-center">
                          <div className={`
                            w-6 h-6 rounded-full mr-3 flex items-center justify-center
                            ${selectedOptions[currentQuestion] === index 
                              ? 'bg-ethio-primary text-white' 
                              : 'bg-gray-100 text-gray-500'}
                          `}>
                            {String.fromCharCode(65 + index)}
                          </div>
                          <span>{option}</span>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </CardContent>
              <CardFooter className="border-t pt-4 flex justify-between">
                <div></div>
                <Button 
                  onClick={handleNextQuestion}
                  disabled={selectedOptions[currentQuestion] === -1}
                  className="flex items-center"
                >
                  {currentQuestion < quiz.questions.length - 1 ? (
                    <>
                      <span>Next Question</span>
                      <ChevronRight className="ml-2 h-4 w-4" />
                    </>
                  ) : (
                    <>
                      <span>Complete Quiz</span>
                      <CheckCircle2 className="ml-2 h-4 w-4" />
                    </>
                  )}
                </Button>
              </CardFooter>
            </Card>
          </div>
          
          <div>
            <Card>
              <CardHeader>
                <CardTitle>Quiz Information</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <h3 className="text-sm font-medium text-gray-500">Subject</h3>
                  <p>{quiz.subject}</p>
                </div>
                
                <div>
                  <h3 className="text-sm font-medium text-gray-500">Teacher</h3>
                  <p>{quiz.teacherName}</p>
                </div>
                
                <div className="flex items-center gap-2">
                  <FileText className="h-4 w-4 text-gray-500" />
                  <span className="text-sm">{quiz.questions.length} Questions</span>
                </div>
                
                {quiz.timeLimit && (
                  <div className="flex items-center gap-2">
                    <Clock className="h-4 w-4 text-gray-500" />
                    <span className="text-sm">{quiz.timeLimit} Minutes</span>
                  </div>
                )}

                {quiz.attemptLimit && (
                  <div className="flex items-center gap-2">
                    <RepeatIcon className="h-4 w-4 text-gray-500" />
                    <span className="text-sm">
                      {attemptCount}/{quiz.attemptLimit} Attempts used
                    </span>
                  </div>
                )}
                
                {previousAttempts.length > 0 && (
                  <div>
                    <h3 className="text-sm font-medium text-gray-500 mb-1">Previous Attempts</h3>
                    <div className="space-y-1">
                      {previousAttempts.map((attempt, index) => (
                        <div key={attempt.id} className="text-xs flex justify-between border-b pb-1">
                          <span>Attempt {index + 1}: </span>
                          <span className="font-medium">{attempt.percentage.toFixed(0)}%</span>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
                
                {quiz.description && (
                  <div>
                    <h3 className="text-sm font-medium text-gray-500">Description</h3>
                    <p className="text-sm">{quiz.description}</p>
                  </div>
                )}
              </CardContent>
            </Card>
            
            <Card className="mt-6">
              <CardHeader className="pb-3">
                <CardTitle className="text-lg">Your Progress</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  <div className="flex justify-between text-sm">
                    <span>Current Question</span>
                    <span className="font-medium">{currentQuestion + 1} of {quiz.questions.length}</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span>Answered</span>
                    <span className="font-medium">
                      {selectedOptions.filter(opt => opt !== -1).length} of {quiz.questions.length}
                    </span>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
      
      {/* Results Dialog */}
      <Dialog open={isResultsDialogOpen} onOpenChange={setIsResultsDialogOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="text-center text-xl">Quiz Results</DialogTitle>
            <DialogDescription className="text-center">
              You've completed the quiz!
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-6 py-6">
            <div className="flex flex-col items-center">
              <Trophy className="h-16 w-16 text-yellow-500 mb-2" />
              <div className="text-center">
                <h3 className="text-2xl font-bold">
                  {results.score}/{results.total}
                </h3>
                <p className="text-lg font-medium text-gray-700">
                  {results.percentage.toFixed(0)}%
                </p>
              </div>
            </div>
            
            <div className="bg-gray-50 p-4 rounded-lg">
              <p className="text-center font-medium">
                {getResultMessage()}
              </p>
            </div>
            
            <div className="grid grid-cols-2 gap-3 text-center">
              <div className="bg-green-50 p-3 rounded-lg">
                <CheckCircle2 className="h-5 w-5 text-green-600 mx-auto mb-1" />
                <h4 className="font-medium text-green-800">Correct</h4>
                <p className="text-lg font-bold text-green-700">
                  {results.correctAnswers}
                </p>
              </div>
              <div className="bg-red-50 p-3 rounded-lg">
                <AlertCircle className="h-5 w-5 text-red-600 mx-auto mb-1" />
                <h4 className="font-medium text-red-800">Incorrect</h4>
                <p className="text-lg font-bold text-red-700">
                  {results.incorrectAnswers}
                </p>
              </div>
            </div>

            {quiz.attemptLimit && (
              <div className="text-center text-sm">
                <span className="text-amber-600 font-medium">
                  Attempt {attemptCount} of {quiz.attemptLimit} used
                </span>
              </div>
            )}
          </div>
          
          <DialogFooter className="sm:justify-between">
            {(quiz.attemptLimit === null || attemptCount < quiz.attemptLimit) && (
              <Button
                variant="outline"
                onClick={handleRestartQuiz}
              >
                Retake Quiz
              </Button>
            )}
            <Button
              onClick={() => navigate('/content-library')}
              className="bg-ethio-primary hover:bg-blue-700"
            >
              Finish
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default ViewQuiz;
