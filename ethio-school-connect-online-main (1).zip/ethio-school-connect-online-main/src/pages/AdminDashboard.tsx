import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { School, Users, BookOpen, CheckCircle2, Clock, ShieldAlert, MessageSquare, CreditCard } from 'lucide-react';
import Header from '@/components/Header';
import PaymentApprovalList from '@/components/PaymentApprovalList';

const AdminDashboard = () => {
  const [stats, setStats] = useState({
    totalSchools: 0,
    approvedSchools: 0,
    pendingSchools: 0,
    totalStudents: 0,
    totalTeachers: 0,
    recentRegistrations: [] as any[]
  });

  useEffect(() => {
    // Load data from localStorage
    const schoolRegistrationsString = localStorage.getItem('schoolRegistrations');
    if (schoolRegistrationsString) {
      const schoolRegistrations = JSON.parse(schoolRegistrationsString);
      
      // Calculate statistics
      const approved = schoolRegistrations.filter((school: any) => school.status === 'approved').length;
      const pending = schoolRegistrations.filter((school: any) => school.status === 'pending').length;
      
      let studentCount = 0;
      let teacherCount = 0;
      
      schoolRegistrations.forEach((school: any) => {
        if (school.users && Array.isArray(school.users)) {
          studentCount += school.users.filter((user: any) => user.role === 'student').length;
          teacherCount += school.users.filter((user: any) => user.role === 'teacher').length;
        }
      });
      
      // Get recent registrations (last 5)
      const recentRegistrations = [...schoolRegistrations]
        .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())
        .slice(0, 5);
      
      setStats({
        totalSchools: schoolRegistrations.length,
        approvedSchools: approved,
        pendingSchools: pending,
        totalStudents: studentCount,
        totalTeachers: teacherCount,
        recentRegistrations
      });
    }
  }, []);

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      
      <div className="container mx-auto px-4 py-8">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-8">
          <div>
            <h1 className="text-2xl font-bold">System Administration Dashboard</h1>
            <p className="text-gray-600">Manage schools, registrations, and system settings</p>
          </div>
          
          <div className="flex gap-2 mt-4 md:mt-0">
            <Link to="/pending-schools">
              <Button variant="outline" className="flex items-center gap-2">
                <Clock className="h-4 w-4" />
                <span>Pending Approvals</span>
                {stats.pendingSchools > 0 && (
                  <Badge variant="destructive" className="ml-1">{stats.pendingSchools}</Badge>
                )}
              </Button>
            </Link>
            <Link to="/manage-schools">
              <Button className="flex items-center gap-2">
                <School className="h-4 w-4" />
                <span>Manage Schools</span>
              </Button>
            </Link>
          </div>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-lg">Total Schools</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-center">
                <School className="h-8 w-8 mr-3 text-ethio-primary" />
                <span className="text-3xl font-bold">{stats.totalSchools}</span>
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-lg">Approved Schools</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-center">
                <CheckCircle2 className="h-8 w-8 mr-3 text-ethio-secondary" />
                <span className="text-3xl font-bold">{stats.approvedSchools}</span>
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-lg">Total Teachers</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-center">
                <Users className="h-8 w-8 mr-3 text-ethio-warning" />
                <span className="text-3xl font-bold">{stats.totalTeachers}</span>
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-lg">Total Students</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-center">
                <BookOpen className="h-8 w-8 mr-3 text-ethio-accent" />
                <span className="text-3xl font-bold">{stats.totalStudents}</span>
              </div>
            </CardContent>
          </Card>
        </div>
        
        <Tabs defaultValue="schools" className="mb-8">
          <TabsList className="mb-4">
            <TabsTrigger value="schools" className="flex items-center gap-2">
              <School className="h-4 w-4" />
              <span>Recent Schools</span>
            </TabsTrigger>
            <TabsTrigger value="payments" className="flex items-center gap-2">
              <CreditCard className="h-4 w-4" />
              <span>Payment Approvals</span>
            </TabsTrigger>
          </TabsList>
          
          <TabsContent value="schools">
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
              <div className="lg:col-span-2">
                <Card>
                  <CardHeader>
                    <CardTitle>Recent School Registrations</CardTitle>
                    <CardDescription>Latest schools that have registered on the platform</CardDescription>
                  </CardHeader>
                  <CardContent>
                    {stats.recentRegistrations.length > 0 ? (
                      <div className="space-y-4">
                        {stats.recentRegistrations.map((school) => (
                          <div key={school.id} className="flex items-start justify-between border-b pb-4">
                            <div>
                              <h3 className="font-medium">{school.schoolName}</h3>
                              <p className="text-sm text-gray-500 capitalize">{school.schoolType} School</p>
                              <p className="text-sm text-gray-500">License: {school.licenseNumber}</p>
                              <div className="flex items-center mt-1">
                                <p className="text-xs text-gray-500">
                                  {new Date(school.createdAt).toLocaleDateString()}
                                </p>
                                <Badge 
                                  variant={school.status === 'approved' ? 'outline' : 'secondary'}
                                  className={`ml-2 ${
                                    school.status === 'approved' 
                                      ? 'bg-green-50 text-green-700 hover:bg-green-50' 
                                      : 'bg-amber-50 text-amber-700 hover:bg-amber-50'
                                  }`}
                                >
                                  {school.status === 'approved' ? 'Approved' : 'Pending'}
                                </Badge>
                              </div>
                            </div>
                            
                            <div>
                              {school.status === 'pending' && (
                                <Link to={`/pending-schools?id=${school.id}`}>
                                  <Button variant="ghost" size="sm">Review</Button>
                                </Link>
                              )}
                              {school.status === 'approved' && (
                                <Link to={`/manage-schools?id=${school.id}`}>
                                  <Button variant="ghost" size="sm">Manage</Button>
                                </Link>
                              )}
                            </div>
                          </div>
                        ))}
                      </div>
                    ) : (
                      <div className="text-center py-8 text-gray-500">
                        <School className="h-12 w-12 mx-auto mb-3 text-gray-400" />
                        <p>No school registrations yet</p>
                      </div>
                    )}
                  </CardContent>
                  <CardFooter>
                    <Link to="/manage-schools">
                      <Button variant="outline" className="w-full">View All Schools</Button>
                    </Link>
                  </CardFooter>
                </Card>
              </div>
              
              <div>
                <Card>
                  <CardHeader>
                    <CardTitle>System Administration</CardTitle>
                    <CardDescription>Quick access to administrative functions</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <Link to="/pending-schools">
                      <Button variant="outline" className="w-full justify-start">
                        <Clock className="h-4 w-4 mr-2" />
                        Pending School Approvals
                        {stats.pendingSchools > 0 && (
                          <Badge variant="destructive" className="ml-auto">{stats.pendingSchools}</Badge>
                        )}
                      </Button>
                    </Link>
                    <Link to="/manage-schools">
                      <Button variant="outline" className="w-full justify-start">
                        <School className="h-4 w-4 mr-2" />
                        Manage Schools
                      </Button>
                    </Link>
                    <Link to="/payment-settings">
                      <Button variant="outline" className="w-full justify-start">
                        <CreditCard className="h-4 w-4 mr-2" />
                        Payment Settings
                      </Button>
                    </Link>
                    <Link to="/communication">
                      <Button variant="outline" className="w-full justify-start">
                        <MessageSquare className="h-4 w-4 mr-2" />
                        View Communication Portal
                      </Button>
                    </Link>
                    <Button variant="outline" className="w-full justify-start">
                      <ShieldAlert className="h-4 w-4 mr-2" />
                      System Settings
                    </Button>
                  </CardContent>
                </Card>
              </div>
            </div>
          </TabsContent>
          
          <TabsContent value="payments">
            <PaymentApprovalList />
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
};

export default AdminDashboard;
