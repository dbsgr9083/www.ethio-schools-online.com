
import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { BookOpen, FileText, FileClock, Video, Eye, Search, Filter, SlidersHorizontal } from 'lucide-react';
import Header from '@/components/Header';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';

const ContentLibrary = () => {
  const navigate = useNavigate();
  const [currentUser, setCurrentUser] = useState<any>(null);
  const [content, setContent] = useState<any[]>([]);
  const [filteredContent, setFilteredContent] = useState<any[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [subjectFilter, setSubjectFilter] = useState('all');
  const [gradeFilter, setGradeFilter] = useState('all');
  const [typeFilter, setTypeFilter] = useState('all');
  const [sortBy, setSortBy] = useState('newest');
  const [uniqueSubjects, setUniqueSubjects] = useState<string[]>([]);
  const [uniqueGrades, setUniqueGrades] = useState<string[]>([]);

  useEffect(() => {
    const userString = localStorage.getItem('currentUser');
    if (userString) {
      const user = JSON.parse(userString);
      setCurrentUser(user);
    } else {
      navigate('/');
      return;
    }

    const contentString = localStorage.getItem('educationalContent');
    if (contentString) {
      const allContent = JSON.parse(contentString);
      setContent(allContent);
      
      // Fix the type casting issue by explicitly casting to string[]
      const subjects = [...new Set(allContent.map((item: any) => item.subject))] as string[];
      const grades = [...new Set(allContent.map((item: any) => item.grade))] as string[];
      
      setUniqueSubjects(subjects);
      setUniqueGrades(grades);
    }
  }, [navigate]);

  useEffect(() => {
    // Apply filters to content
    let result = content.filter((item) => {
      return (
        !item.isPrivate && 
        (item.schoolId === currentUser?.schoolId || item.isGlobal)
      );
    });

    // Apply search term
    if (searchTerm) {
      const term = searchTerm.toLowerCase();
      result = result.filter(
        (item) => 
          item.title.toLowerCase().includes(term) || 
          item.subject.toLowerCase().includes(term) ||
          (item.description && item.description.toLowerCase().includes(term))
      );
    }

    // Apply subject filter
    if (subjectFilter !== 'all') {
      result = result.filter((item) => item.subject === subjectFilter);
    }

    // Apply grade filter
    if (gradeFilter !== 'all') {
      result = result.filter((item) => item.grade === gradeFilter);
    }

    // Apply type filter
    if (typeFilter !== 'all') {
      result = result.filter((item) => item.type === typeFilter);
    }

    // Apply sorting
    result.sort((a, b) => {
      if (sortBy === 'newest') {
        return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime();
      } else if (sortBy === 'oldest') {
        return new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime();
      } else if (sortBy === 'alphabetical') {
        return a.title.localeCompare(b.title);
      }
      return 0;
    });

    setFilteredContent(result);
  }, [content, currentUser, searchTerm, subjectFilter, gradeFilter, typeFilter, sortBy]);

  const getContentTypeIcon = (type: string) => {
    switch (type) {
      case 'note':
        return <FileText className="h-5 w-5 text-ethio-primary" />;
      case 'quiz':
        return <FileClock className="h-5 w-5 text-ethio-warning" />;
      case 'video':
        return <Video className="h-5 w-5 text-ethio-accent" />;
      default:
        return <BookOpen className="h-5 w-5 text-gray-500" />;
    }
  };

  const handleViewQuiz = (quizId: string) => {
    navigate(`/view-quiz/${quizId}`);
  };

  const handleViewNote = (noteId: string) => {
    navigate(`/view-note/${noteId}`);
  };

  const handleViewVideo = (videoUrl: string) => {
    if (videoUrl) {
      window.open(videoUrl, '_blank');
    }
  };

  const resetFilters = () => {
    setSearchTerm('');
    setSubjectFilter('all');
    setGradeFilter('all');
    setTypeFilter('all');
    setSortBy('newest');
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      
      <div className="container mx-auto px-4 py-8">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-8">
          <div>
            <h1 className="text-2xl font-bold">Content Library</h1>
            <p className="text-gray-600">
              Browse available educational content
            </p>
          </div>
          
          <Link to="/content-upload">
            <Button>
              Upload Content
            </Button>
          </Link>
        </div>
        
        <div className="bg-white rounded-lg shadow p-4 mb-6">
          <div className="flex flex-col md:flex-row gap-4">
            <div className="flex-1">
              <div className="relative">
                <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-gray-500" />
                <Input
                  type="text"
                  placeholder="Search by title, subject or description"
                  className="pl-9"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                />
              </div>
            </div>
            
            <div className="flex flex-wrap gap-2">
              <Select value={subjectFilter} onValueChange={setSubjectFilter}>
                <SelectTrigger className="w-[160px]">
                  <SelectValue placeholder="Subject" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Subjects</SelectItem>
                  {uniqueSubjects.map(subject => (
                    <SelectItem key={subject} value={subject}>
                      {subject}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              
              <Select value={gradeFilter} onValueChange={setGradeFilter}>
                <SelectTrigger className="w-[160px]">
                  <SelectValue placeholder="Grade" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Grades</SelectItem>
                  {uniqueGrades.map(grade => (
                    <SelectItem key={grade} value={grade}>
                      Grade {grade}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              
              <Select value={typeFilter} onValueChange={setTypeFilter}>
                <SelectTrigger className="w-[160px]">
                  <SelectValue placeholder="Content Type" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Types</SelectItem>
                  <SelectItem value="note">Notes</SelectItem>
                  <SelectItem value="quiz">Quizzes</SelectItem>
                  <SelectItem value="video">Videos</SelectItem>
                </SelectContent>
              </Select>
              
              <Select value={sortBy} onValueChange={setSortBy}>
                <SelectTrigger className="w-[160px]">
                  <SelectValue placeholder="Sort By" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="newest">Newest First</SelectItem>
                  <SelectItem value="oldest">Oldest First</SelectItem>
                  <SelectItem value="alphabetical">Alphabetical</SelectItem>
                </SelectContent>
              </Select>
              
              <Button variant="outline" onClick={resetFilters} className="flex items-center gap-1">
                <SlidersHorizontal className="h-4 w-4" />
                Reset
              </Button>
            </div>
          </div>
        </div>

        <div>
          <Tabs defaultValue="grid" className="w-full">
            <div className="flex justify-between items-center mb-4">
              <TabsList>
                <TabsTrigger value="grid">Grid View</TabsTrigger>
                <TabsTrigger value="list">List View</TabsTrigger>
              </TabsList>
              <div className="text-sm text-gray-500">
                {filteredContent.length} {filteredContent.length === 1 ? 'item' : 'items'} found
              </div>
            </div>
            
            <TabsContent value="grid">
              {filteredContent.length > 0 ? (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {filteredContent.map((content) => (
                    <Card key={content.id}>
                      <CardContent className="pt-6">
                        <div className="flex items-start space-x-4">
                          <div className="p-2 bg-gray-100 rounded">
                            {getContentTypeIcon(content.type)}
                          </div>
                          <div>
                            <h3 className="font-medium">{content.title}</h3>
                            <p className="text-sm text-gray-500 mb-1">
                              {content.subject} - Grade {content.grade}
                            </p>
                            <div className="flex flex-wrap items-center gap-2 text-xs text-gray-500 mt-2">
                              {content.isPrivate ? (
                                <Badge className="bg-amber-100 text-amber-800 border-amber-300">
                                  Private
                                </Badge>
                              ) : (
                                <Badge className="bg-green-100 text-green-800 border-green-300">
                                  School-wide
                                </Badge>
                              )}
                            </div>
                            {content.type === 'quiz' ? (
                              <Button
                                variant="ghost"
                                size="sm"
                                onClick={() => handleViewQuiz(content.id)}
                              >
                                <Eye className="h-4 w-4 mr-1" />
                                View Quiz
                              </Button>
                            ) : content.type === 'note' ? (
                              <Button
                                variant="ghost"
                                size="sm"
                                onClick={() => handleViewNote(content.id)}
                              >
                                <Eye className="h-4 w-4 mr-1" />
                                View Note
                              </Button>
                            ) : content.type === 'video' ? (
                              <Button
                                variant="ghost"
                                size="sm"
                                onClick={() => handleViewVideo(content.videoUrl)}
                              >
                                <Eye className="h-4 w-4 mr-1" />
                                Watch Video
                              </Button>
                            ) : null}
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              ) : (
                <div className="text-center py-12">
                  <BookOpen className="h-12 w-12 mx-auto text-gray-300 mb-3" />
                  <h3 className="text-lg font-medium text-gray-900">No content found</h3>
                  <p className="text-gray-500 mt-2">Try adjusting your filters or search term</p>
                  <Button variant="outline" onClick={resetFilters} className="mt-4">
                    Reset Filters
                  </Button>
                </div>
              )}
            </TabsContent>
            
            <TabsContent value="list">
              {filteredContent.length > 0 ? (
                <div className="rounded-lg border">
                  <div className="divide-y">
                    {filteredContent.map((content) => (
                      <div key={content.id} className="flex items-center p-4 hover:bg-gray-50">
                        <div className="p-2 bg-gray-100 rounded mr-4">
                          {getContentTypeIcon(content.type)}
                        </div>
                        <div className="flex-1">
                          <h3 className="font-medium">{content.title}</h3>
                          <div className="flex items-center text-sm text-gray-500">
                            <span>{content.subject} - Grade {content.grade}</span>
                            <span className="mx-2">•</span>
                            <span className="capitalize">{content.type}</span>
                            <span className="mx-2">•</span>
                            <span>Added: {new Date(content.createdAt).toLocaleDateString()}</span>
                          </div>
                        </div>
                        {content.type === 'quiz' ? (
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => handleViewQuiz(content.id)}
                          >
                            <Eye className="h-4 w-4 mr-1" />
                            View Quiz
                          </Button>
                        ) : content.type === 'note' ? (
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => handleViewNote(content.id)}
                          >
                            <Eye className="h-4 w-4 mr-1" />
                            View Note
                          </Button>
                        ) : content.type === 'video' ? (
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => handleViewVideo(content.videoUrl)}
                          >
                            <Eye className="h-4 w-4 mr-1" />
                            Watch Video
                          </Button>
                        ) : null}
                      </div>
                    ))}
                  </div>
                </div>
              ) : (
                <div className="text-center py-12">
                  <BookOpen className="h-12 w-12 mx-auto text-gray-300 mb-3" />
                  <h3 className="text-lg font-medium text-gray-900">No content found</h3>
                  <p className="text-gray-500 mt-2">Try adjusting your filters or search term</p>
                  <Button variant="outline" onClick={resetFilters} className="mt-4">
                    Reset Filters
                  </Button>
                </div>
              )}
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </div>
  );
};

export default ContentLibrary;
