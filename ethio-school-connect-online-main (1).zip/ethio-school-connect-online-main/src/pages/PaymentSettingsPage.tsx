
import React from 'react';
import Header from '@/components/Header';
import PaymentSettings from '@/components/PaymentSettings';
import { Button } from '@/components/ui/button';
import { Link } from 'react-router-dom';
import { ChevronLeft } from 'lucide-react';

const PaymentSettingsPage = () => {
  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      
      <div className="container mx-auto px-4 py-8">
        <div className="mb-6">
          <Link to="/admin-dashboard">
            <Button variant="ghost" className="flex items-center gap-2 mb-4">
              <ChevronLeft className="h-4 w-4" />
              Back to Dashboard
            </Button>
          </Link>
          
          <h1 className="text-2xl font-bold">Payment Settings</h1>
          <p className="text-gray-600">Manage payment methods for school registrations</p>
        </div>
        
        <PaymentSettings />
      </div>
    </div>
  );
};

export default PaymentSettingsPage;
