
import React, { useState, useEffect } from 'react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Briefcase, PaperclipIcon, UploadIcon } from 'lucide-react';
import { toast } from 'sonner';
import Header from '@/components/Header';
import UserMessaging from '@/components/UserMessaging';
import JobVacancyManagement from '@/components/JobVacancyManagement';
import JobVacancyApproval from '@/components/JobVacancyApproval';

const Communication = () => {
  const [currentUser, setCurrentUser] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState('messaging');
  const [selectedVacancy, setSelectedVacancy] = useState<any>(null);
  const [vacancies, setVacancies] = useState<any[]>([]);
  const [jobApplications, setJobApplications] = useState<any[]>([]);
  const [applicationData, setApplicationData] = useState({
    coverLetter: '',
    cvFile: null as File | null,
    certificateFile: null as File | null
  });

  useEffect(() => {
    // Get current user
    const userString = localStorage.getItem('currentUser');
    const searchParams = new URLSearchParams(window.location.search);
    const tabParam = searchParams.get('tab');
    const vacancyId = searchParams.get('vacancy');
    
    if (tabParam) {
      setActiveTab(tabParam);
    }
    
    if (userString) {
      const user = JSON.parse(userString);
      setCurrentUser(user);
      
      // Load vacancies
      const vacanciesString = localStorage.getItem('jobVacancies');
      if (vacanciesString) {
        const allVacancies = JSON.parse(vacanciesString);
        const approvedVacancies = allVacancies.filter((vacancy: any) => 
          vacancy.status === 'approved'
        );
        setVacancies(approvedVacancies);
        
        if (vacancyId) {
          const vacancy = approvedVacancies.find((v: any) => v.id === vacancyId);
          if (vacancy) {
            setSelectedVacancy(vacancy);
          }
        }
      }
      
      // Load job applications
      const applicationsString = localStorage.getItem('jobApplications');
      if (applicationsString) {
        setJobApplications(JSON.parse(applicationsString));
      } else {
        localStorage.setItem('jobApplications', JSON.stringify([]));
      }
    }
    setLoading(false);
  }, []);

  // Determine allowed roles for messaging based on current user's role
  const getAllowedRoles = () => {
    if (!currentUser) return [];
    
    switch (currentUser.role) {
      case 'system_admin':
        return ['admin', 'teacher', 'student']; // System admins can message everyone
      case 'admin': // School admin
        return ['admin', 'teacher', 'student']; // Can message admins, teachers and students
      case 'teacher':
        return ['admin', 'teacher', 'student']; // Can message admins, other teachers and students
      case 'student':
        return ['teacher', 'student']; // Can message teachers and other students
      default:
        return [];
    }
  };

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>, fileType: 'cv' | 'certificate') => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      if (fileType === 'cv') {
        setApplicationData({
          ...applicationData,
          cvFile: file
        });
      } else {
        setApplicationData({
          ...applicationData,
          certificateFile: file
        });
      }
    }
  };

  const handleApply = () => {
    if (!selectedVacancy) {
      toast.error('Please select a vacancy to apply for');
      return;
    }

    if (!applicationData.coverLetter.trim()) {
      toast.error('Please provide a cover letter');
      return;
    }

    if (!applicationData.cvFile) {
      toast.error('Please upload your CV');
      return;
    }

    try {
      // In a real app, we would upload the files to a server
      // Here we'll just simulate it by storing the file names
      const newApplication = {
        id: Math.random().toString(36).substr(2, 9),
        vacancyId: selectedVacancy.id,
        schoolId: selectedVacancy.schoolId,
        applicantId: currentUser.id,
        applicantName: currentUser.name,
        applicantRole: currentUser.role,
        position: selectedVacancy.position,
        schoolName: selectedVacancy.schoolName,
        coverLetter: applicationData.coverLetter,
        cvFileName: applicationData.cvFile?.name || 'CV.pdf',
        certificateFileName: applicationData.certificateFile?.name || '',
        status: 'pending',
        createdAt: new Date().toISOString()
      };

      const updatedApplications = [...jobApplications, newApplication];
      localStorage.setItem('jobApplications', JSON.stringify(updatedApplications));
      setJobApplications(updatedApplications);

      toast.success('Your job application has been submitted successfully');
      
      // Reset form
      setApplicationData({
        coverLetter: '',
        cvFile: null,
        certificateFile: null
      });
      setSelectedVacancy(null);
    } catch (error) {
      console.error('Error submitting application:', error);
      toast.error('Failed to submit application. Please try again.');
    }
  };

  const renderJobApplication = () => {
    if (!selectedVacancy) {
      return (
        <div className="text-center py-8">
          <Briefcase className="h-12 w-12 mx-auto mb-4 text-gray-300" />
          <p className="text-gray-500">Select a vacancy to apply for</p>
        </div>
      );
    }

    return (
      <div className="space-y-6">
        <div className="bg-gray-50 p-4 rounded-lg">
          <h3 className="font-medium text-lg">{selectedVacancy.position}</h3>
          <p className="text-sm text-gray-600">{selectedVacancy.schoolName}</p>
          <div className="mt-2 flex gap-2">
            <span className="px-2 py-1 bg-blue-100 text-blue-800 text-xs rounded">
              {selectedVacancy.type}
            </span>
            <span className="px-2 py-1 bg-green-100 text-green-800 text-xs rounded">
              {selectedVacancy.salary}
            </span>
          </div>
          {selectedVacancy.description && (
            <p className="mt-4 text-sm">{selectedVacancy.description}</p>
          )}
        </div>

        <div className="space-y-4">
          <div>
            <Label htmlFor="coverLetter">Cover Letter</Label>
            <textarea
              id="coverLetter"
              className="w-full mt-1 p-2 border border-gray-300 rounded-md min-h-[150px]"
              placeholder="Write a brief cover letter explaining why you're a good fit for this position..."
              value={applicationData.coverLetter}
              onChange={(e) => setApplicationData({
                ...applicationData,
                coverLetter: e.target.value
              })}
            />
          </div>

          <div>
            <Label htmlFor="cvUpload" className="block mb-2">Upload CV/Resume (Required)</Label>
            <div className="flex items-center gap-2">
              <Input
                id="cvUpload"
                type="file"
                accept=".pdf,.doc,.docx"
                onChange={(e) => handleFileSelect(e, 'cv')}
                className="flex-1"
              />
              {applicationData.cvFile && (
                <span className="text-sm text-green-600 flex items-center">
                  <PaperclipIcon className="h-4 w-4 mr-1" />
                  {applicationData.cvFile.name}
                </span>
              )}
            </div>
          </div>

          <div>
            <Label htmlFor="certificateUpload" className="block mb-2">Upload Certificates (Optional)</Label>
            <div className="flex items-center gap-2">
              <Input
                id="certificateUpload"
                type="file"
                accept=".pdf,.doc,.docx,.jpg,.jpeg,.png"
                onChange={(e) => handleFileSelect(e, 'certificate')}
                className="flex-1"
              />
              {applicationData.certificateFile && (
                <span className="text-sm text-green-600 flex items-center">
                  <PaperclipIcon className="h-4 w-4 mr-1" />
                  {applicationData.certificateFile.name}
                </span>
              )}
            </div>
          </div>

          <Button 
            className="w-full mt-6" 
            onClick={handleApply}
            disabled={!applicationData.coverLetter || !applicationData.cvFile}
          >
            <UploadIcon className="h-4 w-4 mr-2" />
            Submit Application
          </Button>
        </div>
      </div>
    );
  };

  if (loading) {
    return <div className="flex items-center justify-center h-screen">Loading...</div>;
  }

  if (!currentUser) {
    return <div className="flex items-center justify-center h-screen">You must be logged in to access this page.</div>;
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      
      <div className="container mx-auto px-4 py-8">
        <h1 className="text-2xl font-bold mb-2">Communication Portal</h1>
        <p className="text-gray-600 mb-6">
          Interact with others and access school resources
        </p>
        
        <Tabs defaultValue={activeTab} value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="mb-4">
            <TabsTrigger value="messaging">Messaging</TabsTrigger>
            {currentUser.role === 'admin' && (
              <TabsTrigger value="jobs">Job Vacancies</TabsTrigger>
            )}
            {(currentUser.role === 'teacher' || currentUser.role === 'student') && (
              <>
                <TabsTrigger value="jobs">View Job Vacancies</TabsTrigger>
                {currentUser.role === 'teacher' && (
                  <TabsTrigger value="apply">Apply for Jobs</TabsTrigger>
                )}
              </>
            )}
            {currentUser.role === 'system_admin' && (
              <>
                <TabsTrigger value="vacancy-approval">Vacancy Approval</TabsTrigger>
                <TabsTrigger value="all-vacancies">View All Vacancies</TabsTrigger>
              </>
            )}
          </TabsList>
          
          <TabsContent value="messaging">
            <Card>
              <CardHeader>
                <CardTitle>Messages</CardTitle>
                <CardDescription>
                  Connect with {getAllowedRoles().map(role => role).join(' and ')}
                </CardDescription>
              </CardHeader>
              <CardContent>
                <UserMessaging currentUser={currentUser} allowedRoles={getAllowedRoles()} />
              </CardContent>
            </Card>
          </TabsContent>
          
          {currentUser.role === 'admin' && (
            <TabsContent value="jobs">
              <JobVacancyManagement currentUser={currentUser} />
            </TabsContent>
          )}
          
          {(currentUser.role === 'teacher' || currentUser.role === 'student') && (
            <TabsContent value="jobs">
              <Card>
                <CardHeader>
                  <CardTitle>Job Vacancies</CardTitle>
                  <CardDescription>
                    View available job opportunities across schools
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <JobVacancyManagement 
                    currentUser={currentUser} 
                    viewOnly={true} 
                    onSelect={currentUser.role === 'teacher' ? (vacancy) => {
                      setSelectedVacancy(vacancy);
                      setActiveTab('apply');
                    } : undefined}
                  />
                </CardContent>
              </Card>
            </TabsContent>
          )}
          
          {currentUser.role === 'teacher' && (
            <TabsContent value="apply">
              <Card>
                <CardHeader>
                  <CardTitle>Apply for Job</CardTitle>
                  <CardDescription>
                    Submit your application for the selected position
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  {renderJobApplication()}
                </CardContent>
              </Card>
            </TabsContent>
          )}
          
          {currentUser.role === 'system_admin' && (
            <>
              <TabsContent value="vacancy-approval">
                <JobVacancyApproval currentUser={currentUser} />
              </TabsContent>
              
              <TabsContent value="all-vacancies">
                <Card>
                  <CardHeader>
                    <CardTitle>All Job Vacancies</CardTitle>
                    <CardDescription>
                      Overview of all job vacancies across schools
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <JobVacancyManagement currentUser={currentUser} viewOnly={true} />
                  </CardContent>
                </Card>
              </TabsContent>
            </>
          )}
        </Tabs>
      </div>
    </div>
  );
};

export default Communication;
