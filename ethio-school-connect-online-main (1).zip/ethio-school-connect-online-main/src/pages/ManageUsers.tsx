
import React, { useState, useEffect } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from "@/components/ui/table";
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { toast } from 'sonner';
import { User, Trash2, Plus, Pencil, Key, UserRound, BookOpen } from 'lucide-react';
import Header from '@/components/Header';
import { v4 as uuidv4 } from 'uuid';

const ManageUsers = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const [currentUser, setCurrentUser] = useState<any>(null);
  const [schoolData, setSchoolData] = useState<any>(null);
  const [activeTab, setActiveTab] = useState('teachers');
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);
  const [isResetDialogOpen, setIsResetDialogOpen] = useState(false);
  const [selectedUser, setSelectedUser] = useState<any>(null);
  const [formData, setFormData] = useState({
    name: '',
    username: '',
    password: '',
    confirmPassword: '',
    role: 'teacher',
    grade: '1',
    section: 'A',
    gender: 'male',
    education: 'Bachelors',
    maritalStatus: 'single'
  });
  const [searchTerm, setSearchTerm] = useState('');

  useEffect(() => {
    // Get current user
    const userString = localStorage.getItem('currentUser');
    if (userString) {
      const user = JSON.parse(userString);
      setCurrentUser(user);
      
      // Load school data
      const schoolRegistrationsString = localStorage.getItem('schoolRegistrations');
      if (schoolRegistrationsString) {
        const schoolRegistrations = JSON.parse(schoolRegistrationsString);
        const school = schoolRegistrations.find((s: any) => s.id === user.schoolId);
        
        if (school) {
          setSchoolData(school);
        }
      }
    }
    
    // Check for tab in URL params
    const params = new URLSearchParams(location.search);
    const tabParam = params.get('tab');
    if (tabParam === 'teachers' || tabParam === 'students') {
      setActiveTab(tabParam);
    }
  }, [location.search]);

  const handleTabChange = (value: string) => {
    setActiveTab(value);
  };

  const handleSearch = (e: React.ChangeEvent<HTMLInputElement>) => {
    setSearchTerm(e.target.value);
  };

  const filteredUsers = schoolData?.users
    ? schoolData.users
        .filter((user: any) => user.role === activeTab.substring(0, activeTab.length - 1)) // Remove 's' from end
        .filter((user: any) => 
          user.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
          user.username.toLowerCase().includes(searchTerm.toLowerCase())
        )
    : [];

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSelectChange = (name: string, value: string) => {
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleAddUser = () => {
    setFormData({
      name: '',
      username: '',
      password: '',
      confirmPassword: '',
      role: activeTab === 'teachers' ? 'teacher' : 'student',
      grade: '1',
      section: 'A',
      gender: 'male',
      education: 'Bachelors',
      maritalStatus: 'single'
    });
    setIsAddDialogOpen(true);
  };

  const handleEditUser = (user: any) => {
    setSelectedUser(user);
    setFormData({
      name: user.name,
      username: user.username,
      password: '',
      confirmPassword: '',
      role: user.role,
      grade: user.grade || '1',
      section: user.section || 'A',
      gender: user.gender || 'male',
      education: user.education || 'Bachelors',
      maritalStatus: user.maritalStatus || 'single'
    });
    setIsEditDialogOpen(true);
  };

  const handleResetPassword = (user: any) => {
    setSelectedUser(user);
    setFormData(prev => ({
      ...prev,
      password: Math.random().toString(36).slice(-8), // Generate random password
      confirmPassword: ''
    }));
    setIsResetDialogOpen(true);
  };

  const handleDeleteUser = (userId: string) => {
    if (window.confirm('Are you sure you want to delete this user?')) {
      try {
        // Get existing registrations
        const registrationsString = localStorage.getItem('schoolRegistrations');
        if (registrationsString && currentUser) {
          const registrations = JSON.parse(registrationsString);
          
          // Find the school
          const schoolIndex = registrations.findIndex((s: any) => s.id === currentUser.schoolId);
          
          if (schoolIndex !== -1) {
            // Filter out the deleted user
            registrations[schoolIndex].users = registrations[schoolIndex].users.filter(
              (u: any) => u.id !== userId
            );
            
            // Save back to localStorage
            localStorage.setItem('schoolRegistrations', JSON.stringify(registrations));
            
            // Update school data
            setSchoolData(registrations[schoolIndex]);
            
            toast.success('User deleted successfully');
          }
        }
      } catch (error) {
        console.error('Error deleting user:', error);
        toast.error('Failed to delete user');
      }
    }
  };

  const handleSubmitAdd = () => {
    // Validate form
    if (!formData.name || !formData.username || !formData.password) {
      toast.error('Please fill in all required fields');
      return;
    }
    
    if (formData.password !== formData.confirmPassword) {
      toast.error('Passwords do not match');
      return;
    }
    
    if (formData.password.length < 6) {
      toast.error('Password must be at least 6 characters long');
      return;
    }
    
    try {
      // Get existing registrations
      const registrationsString = localStorage.getItem('schoolRegistrations');
      if (registrationsString && currentUser) {
        const registrations = JSON.parse(registrationsString);
        
        // Find the school
        const schoolIndex = registrations.findIndex((s: any) => s.id === currentUser.schoolId);
        
        if (schoolIndex !== -1) {
          // Check if username already exists in this school
          const usernameExists = registrations[schoolIndex].users.some(
            (u: any) => u.username === formData.username
          );
          
          if (usernameExists) {
            toast.error('Username already exists');
            return;
          }
          
          // Create new user with additional fields
          const newUser = {
            id: uuidv4(),
            name: formData.name,
            username: formData.username,
            password: formData.password,
            role: formData.role,
            gender: formData.gender,
            createdAt: new Date().toISOString(),
            ...(formData.role === 'student' && { 
              grade: formData.grade,
              section: formData.section
            }),
            ...(formData.role === 'teacher' && {
              education: formData.education,
              maritalStatus: formData.maritalStatus
            })
          };
          
          // Add new user to school
          registrations[schoolIndex].users.push(newUser);
          
          // Save back to localStorage
          localStorage.setItem('schoolRegistrations', JSON.stringify(registrations));
          
          // Update school data
          setSchoolData(registrations[schoolIndex]);
          
          // Close dialog
          setIsAddDialogOpen(false);
          
          toast.success('User added successfully');
        }
      }
    } catch (error) {
      console.error('Error adding user:', error);
      toast.error('Failed to add user');
    }
  };

  const handleSubmitEdit = () => {
    // Validate form
    if (!formData.name || !formData.username) {
      toast.error('Please fill in all required fields');
      return;
    }
    
    try {
      // Get existing registrations
      const registrationsString = localStorage.getItem('schoolRegistrations');
      if (registrationsString && currentUser && selectedUser) {
        const registrations = JSON.parse(registrationsString);
        
        // Find the school
        const schoolIndex = registrations.findIndex((s: any) => s.id === currentUser.schoolId);
        
        if (schoolIndex !== -1) {
          // Check if username already exists in this school (except for the current user)
          const usernameExists = registrations[schoolIndex].users.some(
            (u: any) => u.username === formData.username && u.id !== selectedUser.id
          );
          
          if (usernameExists) {
            toast.error('Username already exists');
            return;
          }
          
          // Find the user
          const userIndex = registrations[schoolIndex].users.findIndex(
            (u: any) => u.id === selectedUser.id
          );
          
          if (userIndex !== -1) {
            // Update user with additional fields
            registrations[schoolIndex].users[userIndex] = {
              ...registrations[schoolIndex].users[userIndex],
              name: formData.name,
              username: formData.username,
              gender: formData.gender,
              ...(formData.role === 'student' && { 
                grade: formData.grade,
                section: formData.section
              }),
              ...(formData.role === 'teacher' && {
                education: formData.education,
                maritalStatus: formData.maritalStatus
              })
            };
            
            // Save back to localStorage
            localStorage.setItem('schoolRegistrations', JSON.stringify(registrations));
            
            // Update school data
            setSchoolData(registrations[schoolIndex]);
            
            // Close dialog
            setIsEditDialogOpen(false);
            
            toast.success('User updated successfully');
          }
        }
      }
    } catch (error) {
      console.error('Error updating user:', error);
      toast.error('Failed to update user');
    }
  };

  const handleSubmitReset = () => {
    // Validate form
    if (!formData.password) {
      toast.error('Please enter a new password');
      return;
    }
    
    if (formData.password.length < 6) {
      toast.error('Password must be at least 6 characters long');
      return;
    }
    
    try {
      // Get existing registrations
      const registrationsString = localStorage.getItem('schoolRegistrations');
      if (registrationsString && currentUser && selectedUser) {
        const registrations = JSON.parse(registrationsString);
        
        // Find the school
        const schoolIndex = registrations.findIndex((s: any) => s.id === currentUser.schoolId);
        
        if (schoolIndex !== -1) {
          // Find the user
          const userIndex = registrations[schoolIndex].users.findIndex(
            (u: any) => u.id === selectedUser.id
          );
          
          if (userIndex !== -1) {
            // Update user password
            registrations[schoolIndex].users[userIndex].password = formData.password;
            
            // Save back to localStorage
            localStorage.setItem('schoolRegistrations', JSON.stringify(registrations));
            
            // Update school data
            setSchoolData(registrations[schoolIndex]);
            
            // Close dialog
            setIsResetDialogOpen(false);
            
            toast.success('Password reset successfully');
          }
        }
      }
    } catch (error) {
      console.error('Error resetting password:', error);
      toast.error('Failed to reset password');
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      
      <div className="container mx-auto px-4 py-8">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-8">
          <div>
            <h1 className="text-2xl font-bold">Manage Users</h1>
            <p className="text-gray-600">
              Add, edit, and manage teachers and students for {schoolData?.schoolName || 'your school'}
            </p>
          </div>
          
          <Button variant="outline" onClick={() => navigate('/school-admin-dashboard')} className="mt-4 md:mt-0">
            Back to Dashboard
          </Button>
        </div>
        
        <Card>
          <CardHeader>
            <div className="flex justify-between items-center">
              <CardTitle>{activeTab === 'teachers' ? 'Teachers' : 'Students'}</CardTitle>
              <Button onClick={handleAddUser} className="flex items-center gap-2">
                <Plus className="h-4 w-4" />
                <span>Add {activeTab === 'teachers' ? 'Teacher' : 'Student'}</span>
              </Button>
            </div>
          </CardHeader>
          <CardContent>
            <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
              <TabsList className="grid w-full max-w-md grid-cols-2 mb-6">
                <TabsTrigger value="teachers">Teachers</TabsTrigger>
                <TabsTrigger value="students">Students</TabsTrigger>
              </TabsList>
              
              <div className="mb-6">
                <Input
                  placeholder={`Search ${activeTab}...`}
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                />
              </div>
              
              <TabsContent value="teachers">
                {filteredUsers.length > 0 ? (
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Name</TableHead>
                        <TableHead>Username</TableHead>
                        <TableHead>Gender</TableHead>
                        <TableHead>Education</TableHead>
                        <TableHead>Marital Status</TableHead>
                        <TableHead>Created On</TableHead>
                        <TableHead className="text-right">Actions</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {filteredUsers.map((user: any) => (
                        <TableRow key={user.id}>
                          <TableCell className="font-medium">{user.name}</TableCell>
                          <TableCell>{user.username}</TableCell>
                          <TableCell>{user.gender || 'N/A'}</TableCell>
                          <TableCell>{user.education || 'N/A'}</TableCell>
                          <TableCell>{user.maritalStatus || 'N/A'}</TableCell>
                          <TableCell className="text-sm">
                            {new Date(user.createdAt).toLocaleDateString()}
                          </TableCell>
                          <TableCell className="text-right">
                            <div className="flex justify-end space-x-2">
                              <Button 
                                variant="ghost" 
                                size="sm"
                                onClick={() => handleResetPassword(user)}
                                title="Reset Password"
                              >
                                <Key className="h-4 w-4 text-amber-600" />
                              </Button>
                              <Button 
                                variant="ghost" 
                                size="sm"
                                onClick={() => handleEditUser(user)}
                              >
                                <Pencil className="h-4 w-4 text-blue-600" />
                              </Button>
                              <Button 
                                variant="ghost" 
                                size="sm"
                                onClick={() => handleDeleteUser(user.id)}
                              >
                                <Trash2 className="h-4 w-4 text-red-600" />
                              </Button>
                            </div>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                ) : (
                  <div className="text-center py-12 text-gray-500">
                    <UserRound className="h-12 w-12 mx-auto mb-3 text-gray-300" />
                    <h2 className="text-xl font-medium mb-2">No Teachers Found</h2>
                    <p>Start by adding teachers to your school.</p>
                    <Button 
                      variant="outline" 
                      className="mt-4"
                      onClick={handleAddUser}
                    >
                      <Plus className="h-4 w-4 mr-2" />
                      Add Teacher
                    </Button>
                  </div>
                )}
              </TabsContent>
              
              <TabsContent value="students">
                {filteredUsers.length > 0 ? (
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Name</TableHead>
                        <TableHead>Username</TableHead>
                        <TableHead>Gender</TableHead>
                        <TableHead>Grade</TableHead>
                        <TableHead>Section</TableHead>
                        <TableHead>Created On</TableHead>
                        <TableHead className="text-right">Actions</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {filteredUsers.map((user: any) => (
                        <TableRow key={user.id}>
                          <TableCell className="font-medium">{user.name}</TableCell>
                          <TableCell>{user.username}</TableCell>
                          <TableCell>{user.gender || 'N/A'}</TableCell>
                          <TableCell>{user.grade || 'N/A'}</TableCell>
                          <TableCell>{user.section || 'N/A'}</TableCell>
                          <TableCell className="text-sm">
                            {new Date(user.createdAt).toLocaleDateString()}
                          </TableCell>
                          <TableCell className="text-right">
                            <div className="flex justify-end space-x-2">
                              <Button 
                                variant="ghost" 
                                size="sm"
                                onClick={() => handleResetPassword(user)}
                                title="Reset Password"
                              >
                                <Key className="h-4 w-4 text-amber-600" />
                              </Button>
                              <Button 
                                variant="ghost" 
                                size="sm"
                                onClick={() => handleEditUser(user)}
                              >
                                <Pencil className="h-4 w-4 text-blue-600" />
                              </Button>
                              <Button 
                                variant="ghost" 
                                size="sm"
                                onClick={() => handleDeleteUser(user.id)}
                              >
                                <Trash2 className="h-4 w-4 text-red-600" />
                              </Button>
                            </div>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                ) : (
                  <div className="text-center py-12 text-gray-500">
                    <BookOpen className="h-12 w-12 mx-auto mb-3 text-gray-300" />
                    <h2 className="text-xl font-medium mb-2">No Students Found</h2>
                    <p>Start by adding students to your school.</p>
                    <Button 
                      variant="outline" 
                      className="mt-4"
                      onClick={handleAddUser}
                    >
                      <Plus className="h-4 w-4 mr-2" />
                      Add Student
                    </Button>
                  </div>
                )}
              </TabsContent>
            </Tabs>
          </CardContent>
        </Card>
      </div>
      
      {/* Add User Dialog */}
      <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Add New {activeTab === 'teachers' ? 'Teacher' : 'Student'}</DialogTitle>
            <DialogDescription>
              Enter the details to add a new {activeTab === 'teachers' ? 'teacher' : 'student'} to your school.
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label htmlFor="name">Full Name *</Label>
              <Input
                id="name"
                name="name"
                value={formData.name}
                onChange={handleInputChange}
                placeholder="Enter full name"
              />
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="username">Username *</Label>
              <Input
                id="username"
                name="username"
                value={formData.username}
                onChange={handleInputChange}
                placeholder="Enter username"
              />
            </div>
            
            <div className="space-y-2">
              <Label>Gender *</Label>
              <RadioGroup 
                value={formData.gender} 
                onValueChange={(value) => handleSelectChange('gender', value)}
                className="flex flex-row space-x-4"
              >
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="male" id="gender-male" />
                  <Label htmlFor="gender-male">Male</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="female" id="gender-female" />
                  <Label htmlFor="gender-female">Female</Label>
                </div>
              </RadioGroup>
            </div>
            
            {activeTab === 'students' && (
              <>
                <div className="space-y-2">
                  <Label htmlFor="grade">Grade/Class *</Label>
                  <Select
                    value={formData.grade}
                    onValueChange={(value) => handleSelectChange('grade', value)}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select grade" />
                    </SelectTrigger>
                    <SelectContent>
                      {[1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12].map((grade) => (
                        <SelectItem key={grade} value={grade.toString()}>
                          Grade {grade}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="section">Section *</Label>
                  <Select
                    value={formData.section}
                    onValueChange={(value) => handleSelectChange('section', value)}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select section" />
                    </SelectTrigger>
                    <SelectContent>
                      {['A', 'B', 'C', 'D', 'E', 'F'].map((section) => (
                        <SelectItem key={section} value={section}>
                          Section {section}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </>
            )}
            
            {activeTab === 'teachers' && (
              <>
                <div className="space-y-2">
                  <Label htmlFor="education">Educational Status *</Label>
                  <Select
                    value={formData.education}
                    onValueChange={(value) => handleSelectChange('education', value)}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select education level" />
                    </SelectTrigger>
                    <SelectContent>
                      {['Diploma', 'Bachelors', 'Masters', 'PhD'].map((edu) => (
                        <SelectItem key={edu} value={edu}>
                          {edu}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="maritalStatus">Marital Status *</Label>
                  <Select
                    value={formData.maritalStatus}
                    onValueChange={(value) => handleSelectChange('maritalStatus', value)}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select marital status" />
                    </SelectTrigger>
                    <SelectContent>
                      {['Single', 'Married', 'Divorced', 'Widowed'].map((status) => (
                        <SelectItem key={status} value={status.toLowerCase()}>
                          {status}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </>
            )}
            
            <div className="space-y-2">
              <Label htmlFor="password">Password *</Label>
              <Input
                id="password"
                name="password"
                type="password"
                value={formData.password}
                onChange={handleInputChange}
                placeholder="Enter password"
              />
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="confirmPassword">Confirm Password *</Label>
              <Input
                id="confirmPassword"
                name="confirmPassword"
                type="password"
                value={formData.confirmPassword}
                onChange={handleInputChange}
                placeholder="Confirm password"
              />
            </div>
          </div>
          
          <DialogFooter className="sm:justify-between">
            <Button
              variant="outline"
              onClick={() => setIsAddDialogOpen(false)}
            >
              Cancel
            </Button>
            <Button
              onClick={handleSubmitAdd}
              className={`${
                activeTab === 'teachers' 
                  ? 'bg-ethio-primary hover:bg-blue-700' 
                  : 'bg-ethio-accent hover:bg-purple-700'
              }`}
            >
              Add {activeTab === 'teachers' ? 'Teacher' : 'Student'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
      
      {/* Edit User Dialog */}
      <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Edit {selectedUser?.role === 'teacher' ? 'Teacher' : 'Student'}</DialogTitle>
            <DialogDescription>
              Update the details for {selectedUser?.name}.
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label htmlFor="name">Full Name *</Label>
              <Input
                id="name"
                name="name"
                value={formData.name}
                onChange={handleInputChange}
                placeholder="Enter full name"
              />
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="username">Username *</Label>
              <Input
                id="username"
                name="username"
                value={formData.username}
                onChange={handleInputChange}
                placeholder="Enter username"
              />
            </div>
            
            <div className="space-y-2">
              <Label>Gender *</Label>
              <RadioGroup 
                value={formData.gender} 
                onValueChange={(value) => handleSelectChange('gender', value)}
                className="flex flex-row space-x-4"
              >
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="male" id="edit-gender-male" />
                  <Label htmlFor="edit-gender-male">Male</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="female" id="edit-gender-female" />
                  <Label htmlFor="edit-gender-female">Female</Label>
                </div>
              </RadioGroup>
            </div>
            
            {formData.role === 'student' && (
              <>
                <div className="space-y-2">
                  <Label htmlFor="grade">Grade/Class *</Label>
                  <Select
                    value={formData.grade}
                    onValueChange={(value) => handleSelectChange('grade', value)}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select grade" />
                    </SelectTrigger>
                    <SelectContent>
                      {[1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12].map((grade) => (
                        <SelectItem key={grade} value={grade.toString()}>
                          Grade {grade}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="section">Section *</Label>
                  <Select
                    value={formData.section}
                    onValueChange={(value) => handleSelectChange('section', value)}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select section" />
                    </SelectTrigger>
                    <SelectContent>
                      {['A', 'B', 'C', 'D', 'E', 'F'].map((section) => (
                        <SelectItem key={section} value={section}>
                          Section {section}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </>
            )}
            
            {formData.role === 'teacher' && (
              <>
                <div className="space-y-2">
                  <Label htmlFor="education">Educational Status *</Label>
                  <Select
                    value={formData.education}
                    onValueChange={(value) => handleSelectChange('education', value)}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select education level" />
                    </SelectTrigger>
                    <SelectContent>
                      {['Diploma', 'Bachelors', 'Masters', 'PhD'].map((edu) => (
                        <SelectItem key={edu} value={edu}>
                          {edu}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="maritalStatus">Marital Status *</Label>
                  <Select
                    value={formData.maritalStatus}
                    onValueChange={(value) => handleSelectChange('maritalStatus', value)}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select marital status" />
                    </SelectTrigger>
                    <SelectContent>
                      {['Single', 'Married', 'Divorced', 'Widowed'].map((status) => (
                        <SelectItem key={status} value={status.toLowerCase()}>
                          {status}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </>
            )}
          </div>
          
          <DialogFooter className="sm:justify-between">
            <Button
              variant="outline"
              onClick={() => setIsEditDialogOpen(false)}
            >
              Cancel
            </Button>
            <Button
              onClick={handleSubmitEdit}
              className={`${
                formData.role === 'teacher' 
                  ? 'bg-ethio-primary hover:bg-blue-700' 
                  : 'bg-ethio-accent hover:bg-purple-700'
              }`}
            >
              Update {formData.role === 'teacher' ? 'Teacher' : 'Student'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
      
      {/* Reset Password Dialog */}
      <Dialog open={isResetDialogOpen} onOpenChange={setIsResetDialogOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Reset Password</DialogTitle>
            <DialogDescription>
              Set a new password for {selectedUser?.name}.
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label htmlFor="resetPassword">New Password *</Label>
              <Input
                id="resetPassword"
                name="password"
                value={formData.password}
                onChange={handleInputChange}
                placeholder="Enter new password"
              />
            </div>
          </div>
          
          <DialogFooter className="sm:justify-between">
            <Button
              variant="outline"
              onClick={() => setIsResetDialogOpen(false)}
            >
              Cancel
            </Button>
            <Button
              onClick={handleSubmitReset}
              className="bg-ethio-warning hover:bg-amber-600"
            >
              Reset Password
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default ManageUsers;
