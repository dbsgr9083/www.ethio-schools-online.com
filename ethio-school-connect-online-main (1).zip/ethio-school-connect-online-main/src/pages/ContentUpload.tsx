import React, { useState, useEffect } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Switch } from '@/components/ui/switch';
import { toast } from 'sonner';
import { FileText, FileClock, Video, Upload, Plus, Trash2, Eye, EyeOff, Lock, Unlock, Globe } from 'lucide-react';
import Header from '@/components/Header';
import { v4 as uuidv4 } from 'uuid';
import QuizTimeLimit from '@/components/QuizTimeLimit';
import QuizAttemptLimit from '@/components/QuizAttemptLimit';

const ContentUpload = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const [currentUser, setCurrentUser] = useState<any>(null);
  const [activeTab, setActiveTab] = useState('note');
  const [isSubmitting, setIsSubmitting] = useState(false);

  const [noteForm, setNoteForm] = useState({
    title: '',
    subject: '',
    grade: '1',
    description: '',
    content: '',
    file: null as File | null,
    fileName: '',
    isPrivate: false,
    isGlobal: false
  });

  const [quizForm, setQuizForm] = useState({
    title: '',
    subject: '',
    grade: '1',
    description: '',
    questions: [
      {
        question: '',
        options: ['', '', '', ''],
        correctOption: 0
      }
    ],
    isPrivate: false,
    isGlobal: false,
    timeLimit: 30,
    hasTimeLimit: false,
    attemptLimit: 1,
    hasAttemptLimit: false
  });

  const [videoForm, setVideoForm] = useState({
    title: '',
    subject: '',
    grade: '1',
    description: '',
    videoUrl: '',
    file: null as File | null,
    fileName: '',
    isPrivate: false,
    isGlobal: false
  });

  useEffect(() => {
    const userString = localStorage.getItem('currentUser');
    if (userString) {
      const user = JSON.parse(userString);
      setCurrentUser(user);
      
      if (user.role !== 'teacher' && user.role !== 'system_admin') {
        navigate('/');
        return;
      }
    } else {
      navigate('/');
      return;
    }
    
    const params = new URLSearchParams(location.search);
    const contentType = params.get('type');
    if (contentType && ['note', 'quiz', 'video'].includes(contentType)) {
      setActiveTab(contentType);
    }
  }, [navigate, location.search]);

  const handleTabChange = (value: string) => {
    setActiveTab(value);
  };

  const handleNoteChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setNoteForm(prev => ({ ...prev, [name]: value }));
  };

  const handleNoteSelectChange = (name: string, value: string) => {
    setNoteForm(prev => ({ ...prev, [name]: value }));
  };

  const handleNoteFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setNoteForm(prev => ({
        ...prev,
        file,
        fileName: file.name
      }));
    }
  };

  const toggleNotePrivacy = (checked: boolean) => {
    setNoteForm(prev => ({ ...prev, isPrivate: checked }));
  };

  const toggleNoteGlobal = (checked: boolean) => {
    setNoteForm(prev => ({ ...prev, isGlobal: checked }));
  };

  const handleQuizChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setQuizForm(prev => ({ ...prev, [name]: value }));
  };

  const handleQuizSelectChange = (name: string, value: string) => {
    setQuizForm(prev => ({ ...prev, [name]: value }));
  };

  const handleQuestionChange = (index: number, e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setQuizForm(prev => {
      const newQuestions = [...prev.questions];
      if (name === 'question') {
        newQuestions[index] = { ...newQuestions[index], question: value };
      }
      return { ...prev, questions: newQuestions };
    });
  };

  const handleOptionChange = (questionIndex: number, optionIndex: number, value: string) => {
    setQuizForm(prev => {
      const newQuestions = [...prev.questions];
      const newOptions = [...newQuestions[questionIndex].options];
      newOptions[optionIndex] = value;
      newQuestions[questionIndex] = { ...newQuestions[questionIndex], options: newOptions };
      return { ...prev, questions: newQuestions };
    });
  };

  const handleCorrectOptionChange = (questionIndex: number, optionIndex: number) => {
    setQuizForm(prev => {
      const newQuestions = [...prev.questions];
      newQuestions[questionIndex] = { ...newQuestions[questionIndex], correctOption: optionIndex };
      return { ...prev, questions: newQuestions };
    });
  };

  const toggleQuizPrivacy = (checked: boolean) => {
    setQuizForm(prev => ({ ...prev, isPrivate: checked }));
  };

  const toggleQuizGlobal = (checked: boolean) => {
    setQuizForm(prev => ({ ...prev, isGlobal: checked }));
  };

  const setTimeLimit = (value: number) => {
    setQuizForm(prev => ({ ...prev, timeLimit: value }));
  };

  const setHasTimeLimit = (value: boolean) => {
    setQuizForm(prev => ({ ...prev, hasTimeLimit: value }));
  };

  const setAttemptLimit = (value: number) => {
    setQuizForm(prev => ({ ...prev, attemptLimit: value }));
  };

  const setHasAttemptLimit = (value: boolean) => {
    setQuizForm(prev => ({ ...prev, hasAttemptLimit: value }));
  };

  const addQuestion = () => {
    setQuizForm(prev => ({
      ...prev,
      questions: [
        ...prev.questions,
        {
          question: '',
          options: ['', '', '', ''],
          correctOption: 0
        }
      ]
    }));
  };

  const removeQuestion = (index: number) => {
    if (quizForm.questions.length > 1) {
      setQuizForm(prev => ({
        ...prev,
        questions: prev.questions.filter((_, i) => i !== index)
      }));
    } else {
      toast.error('Quiz must have at least one question');
    }
  };

  const handleVideoChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setVideoForm(prev => ({ ...prev, [name]: value }));
  };

  const handleVideoSelectChange = (name: string, value: string) => {
    setVideoForm(prev => ({ ...prev, [name]: value }));
  };

  const handleVideoFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (!file.type.startsWith('video/')) {
        toast.error('Please select a valid video file');
        return;
      }
      
      setVideoForm(prev => ({
        ...prev,
        file,
        fileName: file.name
      }));
    }
  };

  const toggleVideoPrivacy = (checked: boolean) => {
    setVideoForm(prev => ({ ...prev, isPrivate: checked }));
  };

  const toggleVideoGlobal = (checked: boolean) => {
    setVideoForm(prev => ({ ...prev, isGlobal: checked }));
  };

  const handleNoteSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    
    if (!noteForm.title || !noteForm.subject || !noteForm.content) {
      toast.error('Please fill in all required fields');
      setIsSubmitting(false);
      return;
    }
    
    try {
      const newNote = {
        id: uuidv4(),
        type: 'note',
        title: noteForm.title,
        subject: noteForm.subject,
        grade: noteForm.grade,
        description: noteForm.description,
        content: noteForm.content,
        fileName: noteForm.fileName,
        fileData: noteForm.file ? 'file-data-placeholder' : null,
        teacherId: currentUser.role === 'system_admin' ? 'system' : currentUser.id,
        teacherName: currentUser.role === 'system_admin' ? 'System Admin' : currentUser.name,
        schoolId: currentUser.role === 'system_admin' ? 'system' : currentUser.schoolId,
        schoolName: currentUser.role === 'system_admin' ? 'System' : currentUser.schoolName,
        isPrivate: noteForm.isPrivate,
        isGlobal: currentUser.role === 'system_admin' ? noteForm.isGlobal : (currentUser.role === 'teacher' && !noteForm.isPrivate),
        createdAt: new Date().toISOString()
      };
      
      const contentString = localStorage.getItem('educationalContent');
      const content = contentString ? JSON.parse(contentString) : [];
      content.push(newNote);
      localStorage.setItem('educationalContent', JSON.stringify(content));
      
      toast.success('Note uploaded successfully');
      
      setNoteForm({
        title: '',
        subject: '',
        grade: '1',
        description: '',
        content: '',
        file: null,
        fileName: '',
        isPrivate: false,
        isGlobal: false
      });
      
      setTimeout(() => {
        navigate('/content-library');
      }, 1500);
    } catch (error) {
      console.error('Error uploading note:', error);
      toast.error('Failed to upload note');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleQuizSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    
    if (!quizForm.title || !quizForm.subject) {
      toast.error('Please fill in all required fields');
      setIsSubmitting(false);
      return;
    }
    
    const invalidQuestions = quizForm.questions.some(q => 
      !q.question || q.options.some(opt => !opt)
    );
    
    if (invalidQuestions) {
      toast.error('Please fill in all questions and options');
      setIsSubmitting(false);
      return;
    }
    
    try {
      const newQuiz = {
        id: uuidv4(),
        type: 'quiz',
        title: quizForm.title,
        subject: quizForm.subject,
        grade: quizForm.grade,
        description: quizForm.description,
        questions: quizForm.questions,
        teacherId: currentUser.role === 'system_admin' ? 'system' : currentUser.id,
        teacherName: currentUser.role === 'system_admin' ? 'System Admin' : currentUser.name,
        schoolId: currentUser.role === 'system_admin' ? 'system' : currentUser.schoolId,
        schoolName: currentUser.role === 'system_admin' ? 'System' : currentUser.schoolName,
        isPrivate: quizForm.isPrivate,
        isGlobal: currentUser.role === 'system_admin' ? quizForm.isGlobal : (currentUser.role === 'teacher' && !quizForm.isPrivate),
        timeLimit: quizForm.hasTimeLimit ? quizForm.timeLimit : null,
        attemptLimit: quizForm.hasAttemptLimit ? quizForm.attemptLimit : null,
        createdAt: new Date().toISOString()
      };
      
      const contentString = localStorage.getItem('educationalContent');
      const content = contentString ? JSON.parse(contentString) : [];
      content.push(newQuiz);
      localStorage.setItem('educationalContent', JSON.stringify(content));
      
      toast.success('Quiz created successfully');
      
      setQuizForm({
        title: '',
        subject: '',
        grade: '1',
        description: '',
        questions: [
          {
            question: '',
            options: ['', '', '', ''],
            correctOption: 0
          }
        ],
        isPrivate: false,
        isGlobal: false,
        timeLimit: 30,
        hasTimeLimit: false,
        attemptLimit: 1,
        hasAttemptLimit: false
      });
      
      setTimeout(() => {
        navigate('/content-library');
      }, 1500);
    } catch (error) {
      console.error('Error creating quiz:', error);
      toast.error('Failed to create quiz');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleVideoSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    
    if (!videoForm.title || !videoForm.subject || (!videoForm.videoUrl && !videoForm.file)) {
      toast.error('Please fill in all required fields and provide either a URL or file');
      setIsSubmitting(false);
      return;
    }
    
    try {
      const newVideo = {
        id: uuidv4(),
        type: 'video',
        title: videoForm.title,
        subject: videoForm.subject,
        grade: videoForm.grade,
        description: videoForm.description,
        videoUrl: videoForm.videoUrl,
        fileName: videoForm.fileName,
        fileData: videoForm.file ? 'video-data-placeholder' : null,
        teacherId: currentUser.role === 'system_admin' ? 'system' : currentUser.id,
        teacherName: currentUser.role === 'system_admin' ? 'System Admin' : currentUser.name,
        schoolId: currentUser.role === 'system_admin' ? 'system' : currentUser.schoolId,
        schoolName: currentUser.role === 'system_admin' ? 'System' : currentUser.schoolName,
        isPrivate: videoForm.isPrivate,
        isGlobal: currentUser.role === 'system_admin' ? videoForm.isGlobal : (currentUser.role === 'teacher' && !videoForm.isPrivate),
        createdAt: new Date().toISOString()
      };
      
      const contentString = localStorage.getItem('educationalContent');
      const content = contentString ? JSON.parse(contentString) : [];
      content.push(newVideo);
      localStorage.setItem('educationalContent', JSON.stringify(content));
      
      toast.success('Video uploaded successfully');
      
      setVideoForm({
        title: '',
        subject: '',
        grade: '1',
        description: '',
        videoUrl: '',
        file: null,
        fileName: '',
        isPrivate: false,
        isGlobal: false
      });
      
      setTimeout(() => {
        navigate('/content-library');
      }, 1500);
    } catch (error) {
      console.error('Error uploading video:', error);
      toast.error('Failed to upload video');
    } finally {
      setIsSubmitting(false);
    }
  };

  const getDashboardRoute = () => {
    if (currentUser?.role === 'system_admin') {
      return '/admin-dashboard';
    } else if (currentUser?.role === 'teacher') {
      return '/teacher-dashboard';
    }
    return '/';
  };

  const toggleNotePublicized = (checked: boolean) => {
    // Removed method as it's no longer needed
  };

  const toggleQuizPublicized = (checked: boolean) => {
    // Removed method as it's no longer needed
  };

  const toggleVideoPublicized = (checked: boolean) => {
    // Removed method as it's no longer needed
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      
      <div className="container mx-auto px-4 py-8">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-8">
          <div>
            <h1 className="text-2xl font-bold">Upload Educational Content</h1>
            <p className="text-gray-600">
              {currentUser?.role === 'system_admin' 
                ? 'Create and share system-wide learning materials for all students'
                : 'Create and share learning materials for your students'}
            </p>
          </div>
          
          <Button variant="outline" onClick={() => navigate(getDashboardRoute())} className="mt-4 md:mt-0">
            Back to Dashboard
          </Button>
        </div>
        
        <Card>
          <CardHeader>
            <CardTitle>Content Upload</CardTitle>
            <CardDescription>Select the type of content you want to upload</CardDescription>
          </CardHeader>
          <CardContent>
            <Tabs value={activeTab} onValueChange={handleTabChange} className="w-full">
              <TabsList className="grid w-full max-w-md grid-cols-3 mb-6">
                <TabsTrigger value="note" className="flex items-center gap-2">
                  <FileText className="h-4 w-4" />
                  <span>Notes</span>
                </TabsTrigger>
                <TabsTrigger value="quiz" className="flex items-center gap-2">
                  <FileClock className="h-4 w-4" />
                  <span>Quizzes</span>
                </TabsTrigger>
                <TabsTrigger value="video" className="flex items-center gap-2">
                  <Video className="h-4 w-4" />
                  <span>Videos</span>
                </TabsTrigger>
              </TabsList>
              
              <TabsContent value="note">
                <form onSubmit={handleNoteSubmit} className="space-y-6">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="space-y-2">
                      <Label htmlFor="note-title">Title *</Label>
                      <Input
                        id="note-title"
                        name="title"
                        value={noteForm.title}
                        onChange={handleNoteChange}
                        placeholder="Enter title"
                      />
                    </div>
                    
                    <div className="space-y-2">
                      <Label htmlFor="note-subject">Subject *</Label>
                      <Input
                        id="note-subject"
                        name="subject"
                        value={noteForm.subject}
                        onChange={handleNoteChange}
                        placeholder="Enter subject"
                      />
                    </div>
                  </div>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="space-y-2">
                      <Label htmlFor="note-grade">Grade/Class *</Label>
                      <Select
                        value={noteForm.grade}
                        onValueChange={(value) => handleNoteSelectChange('grade', value)}
                      >
                        <SelectTrigger>
                          <SelectValue placeholder="Select grade" />
                        </SelectTrigger>
                        <SelectContent>
                          {[1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12].map((grade) => (
                            <SelectItem key={grade} value={grade.toString()}>
                              Grade {grade}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                    
                    <div className="space-y-2">
                      <Label htmlFor="note-file">Upload File (Optional)</Label>
                      <Input
                        id="note-file"
                        type="file"
                        onChange={handleNoteFileChange}
                      />
                      {noteForm.fileName && (
                        <p className="text-xs text-gray-500">Selected: {noteForm.fileName}</p>
                      )}
                    </div>
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="note-description">Description</Label>
                    <Textarea
                      id="note-description"
                      name="description"
                      value={noteForm.description}
                      onChange={handleNoteChange}
                      placeholder="Enter a brief description"
                      rows={2}
                    />
                  </div>
                  
                  <div className="flex items-center space-x-2">
                    <Switch 
                      id="note-privacy" 
                      checked={noteForm.isPrivate}
                      onCheckedChange={toggleNotePrivacy}
                    />
                    <Label htmlFor="note-privacy" className="flex items-center gap-1 cursor-pointer">
                      {noteForm.isPrivate ? (
                        <>
                          <Lock className="h-4 w-4 text-amber-500" />
                          <span>Private (Only for my students)</span>
                        </>
                      ) : (
                        <>
                          <Unlock className="h-4 w-4 text-green-500" />
                          <span>School-wide (Available to specific students from all schools)</span>
                        </>
                      )}
                    </Label>
                  </div>

                  {currentUser?.role === 'system_admin' && (
                    <div className="flex items-center space-x-2">
                      <Switch 
                        id="note-global" 
                        checked={noteForm.isGlobal}
                        onCheckedChange={toggleNoteGlobal}
                      />
                      <Label htmlFor="note-global" className="flex items-center gap-1 cursor-pointer">
                        {noteForm.isGlobal ? (
                          <>
                            <Globe className="h-4 w-4 text-blue-500" />
                            <span>System-wide (Available to all schools)</span>
                          </>
                        ) : (
                          <>
                            <Globe className="h-4 w-4 text-gray-400" />
                            <span>Limited distribution</span>
                          </>
                        )}
                      </Label>
                    </div>
                  )}
                  
                  {currentUser?.role === 'teacher' && !noteForm.isPrivate && (
                    <div className="flex items-center pt-1">
                      <Globe className="h-4 w-4 text-blue-500 mr-2" />
                      <p className="text-sm text-blue-700">
                        Your school-wide content will be available to specific students from all schools who access this platform
                      </p>
                    </div>
                  )}
                  
                  <div className="space-y-2">
                    <Label htmlFor="note-content">Content *</Label>
                    <Textarea
                      id="note-content"
                      name="content"
                      value={noteForm.content}
                      onChange={handleNoteChange}
                      placeholder="Enter your notes content"
                      rows={10}
                    />
                  </div>
                  
                  <Button type="submit" className="w-full" disabled={isSubmitting}>
                    {isSubmitting ? 'Uploading...' : 'Upload Note'}
                  </Button>
                </form>
              </TabsContent>
              
              <TabsContent value="quiz">
                <form onSubmit={handleQuizSubmit} className="space-y-6">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="space-y-2">
                      <Label htmlFor="quiz-title">Quiz Title *</Label>
                      <Input
                        id="quiz-title"
                        name="title"
                        value={quizForm.title}
                        onChange={handleQuizChange}
                        placeholder="Enter quiz title"
                      />
                    </div>
                    
                    <div className="space-y-2">
                      <Label htmlFor="quiz-subject">Subject *</Label>
                      <Input
                        id="quiz-subject"
                        name="subject"
                        value={quizForm.subject}
                        onChange={handleQuizChange}
                        placeholder="Enter subject"
                      />
                    </div>
                  </div>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="space-y-2">
                      <Label htmlFor="quiz-grade">Grade/Class *</Label>
                      <Select
                        value={quizForm.grade}
                        onValueChange={(value) => handleQuizSelectChange('grade', value)}
                      >
                        <SelectTrigger>
                          <SelectValue placeholder="Select grade" />
                        </SelectTrigger>
                        <SelectContent>
                          {[1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12].map((grade) => (
                            <SelectItem key={grade} value={grade.toString()}>
                              Grade {grade}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="quiz-description">Description</Label>
                    <Textarea
                      id="quiz-description"
                      name="description"
                      value={quizForm.description}
                      onChange={handleQuizChange}
                      placeholder="Enter a brief description of the quiz"
                      rows={2}
                    />
                  </div>
                  
                  <div className="flex items-center space-x-2">
                    <Switch 
                      id="quiz-privacy" 
                      checked={quizForm.isPrivate}
                      onCheckedChange={toggleQuizPrivacy}
                    />
                    <Label htmlFor="quiz-privacy" className="flex items-center gap-1 cursor-pointer">
                      {quizForm.isPrivate ? (
                        <>
                          <Lock className="h-4 w-4 text-amber-500" />
                          <span>Private (Only for my students)</span>
                        </>
                      ) : (
                        <>
                          <Unlock className="h-4 w-4 text-green-500" />
                          <span>School-wide (Available to specific students from all schools)</span>
                        </>
                      )}
                    </Label>
                  </div>

                  {currentUser?.role === 'system_admin' && (
                    <div className="flex items-center space-x-2">
                      <Switch 
                        id="quiz-global" 
                        checked={quizForm.isGlobal}
                        onCheckedChange={toggleQuizGlobal}
                      />
                      <Label htmlFor="quiz-global" className="flex items-center gap-1 cursor-pointer">
                        {quizForm.isGlobal ? (
                          <>
                            <Globe className="h-4 w-4 text-blue-500" />
                            <span>System-wide (Available to all schools)</span>
                          </>
                        ) : (
                          <>
                            <Globe className="h-4 w-4 text-gray-400" />
                            <span>Limited distribution</span>
                          </>
                        )}
                      </Label>
                    </div>
                  )}
                  
                  {currentUser?.role === 'teacher' && !quizForm.isPrivate && (
                    <div className="flex items-center pt-1">
                      <Globe className="h-4 w-4 text-blue-500 mr-2" />
                      <p className="text-sm text-blue-700">
                        Your school-wide quiz will be available to specific students from all schools who access this platform
                      </p>
                    </div>
                  )}
                  
                  <div className="border p-4 rounded-lg space-y-4">
                    <h3 className="font-medium">Quiz Settings</h3>
                    <QuizTimeLimit
                      timeLimit={quizForm.timeLimit}
                      setTimeLimit={setTimeLimit}
                      hasTimeLimit={quizForm.hasTimeLimit}
                      setHasTimeLimit={setHasTimeLimit}
                    />
                    
                    <QuizAttemptLimit
                      attemptLimit={quizForm.attemptLimit}
                      setAttemptLimit={setAttemptLimit}
                      hasAttemptLimit={quizForm.hasAttemptLimit}
                      setHasAttemptLimit={setHasAttemptLimit}
                    />
                  </div>
                  
                  <div className="space-y-6">
                    <div className="flex items-center justify-between">
                      <h3 className="text-lg font-medium">Questions</h3>
                      <Button type="button" variant="outline" onClick={addQuestion} className="flex items-center gap-2">
                        <Plus className="h-4 w-4" />
                        <span>Add Question</span>
                      </Button>
                    </div>
                    
                    {quizForm.questions.map((question, qIndex) => (
                      <div key={qIndex} className="border p-4 rounded-lg space-y-4">
                        <div className="flex items-start justify-between">
                          <h4 className="font-medium">Question {qIndex + 1}</h4>
                          <Button 
                            type="button" 
                            variant="ghost" 
                            size="sm"
                            onClick={() => removeQuestion(qIndex)}
                            className="text-red-500 hover:text-red-700"
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </div>
                        
                        <div className="space-y-2">
                          <Label htmlFor={`question-${qIndex}`}>Question Text *</Label>
                          <Input
                            id={`question-${qIndex}`}
                            name="question"
                            value={question.question}
                            onChange={(e) => handleQuestionChange(qIndex, e)}
                            placeholder="Enter question"
                          />
                        </div>
                        
                        <div className="space-y-4">
                          <Label>Options (Select the correct answer) *</Label>
                          {question.options.map((option, oIndex) => (
                            <div key={oIndex} className="flex items-center space-x-3">
                              <input
                                type="radio"
                                id={`option-${qIndex}-${oIndex}`}
                                name={`correct-option-${qIndex}`}
                                checked={question.correctOption === oIndex}
                                onChange={() => handleCorrectOptionChange(qIndex, oIndex)}
                                className="h-4 w-4 text-ethio-primary"
                              />
                              <Input
                                id={`option-text-${qIndex}-${oIndex}`}
                                value={option}
                                onChange={(e) => handleOptionChange(qIndex, oIndex, e.target.value)}
                                placeholder={`Option ${oIndex + 1}`}
                                className="flex-1"
                              />
                            </div>
                          ))}
                        </div>
                      </div>
                    ))}
                  </div>
                  
                  <Button type="submit" className="w-full" disabled={isSubmitting}>
                    {isSubmitting ? 'Creating Quiz...' : 'Create Quiz'}
                  </Button>
                </form>
              </TabsContent>
              
              <TabsContent value="video">
                <form onSubmit={handleVideoSubmit} className="space-y-6">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="space-y-2">
                      <Label htmlFor="video-title">Video Title *</Label>
                      <Input
                        id="video-title"
                        name="title"
                        value={videoForm.title}
                        onChange={handleVideoChange}
                        placeholder="Enter video title"
                      />
                    </div>
                    
                    <div className="space-y-2">
                      <Label htmlFor="video-subject">Subject *</Label>
                      <Input
                        id="video-subject"
                        name="subject"
                        value={videoForm.subject}
                        onChange={handleVideoChange}
                        placeholder="Enter subject"
                      />
                    </div>
                  </div>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="space-y-2">
                      <Label htmlFor="video-grade">Grade/Class *</Label>
                      <Select
                        value={videoForm.grade}
                        onValueChange={(value) => handleVideoSelectChange('grade', value)}
                      >
                        <SelectTrigger>
                          <SelectValue placeholder="Select grade" />
                        </SelectTrigger>
                        <SelectContent>
                          {[1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12].map((grade) => (
                            <SelectItem key={grade} value={grade.toString()}>
                              Grade {grade}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="video-description">Description</Label>
                    <Textarea
                      id="video-description"
                      name="description"
                      value={videoForm.description}
                      onChange={handleVideoChange}
                      placeholder="Enter a brief description of the video"
                      rows={2}
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="video-url">Video URL</Label>
                    <Input
                      id="video-url"
                      name="videoUrl"
                      value={videoForm.videoUrl}
                      onChange={handleVideoChange}
                      placeholder="Enter video URL"
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="video-file">Upload Video File (Optional)</Label>
                    <Input
                      id="video-file"
                      type="file"
                      onChange={handleVideoFileChange}
                    />
                    {videoForm.fileName && (
                      <p className="text-xs text-gray-500">Selected: {videoForm.fileName}</p>
                    )}
                  </div>
                  
                  <div className="flex items-center space-x-2">
                    <Switch 
                      id="video-privacy" 
                      checked={videoForm.isPrivate}
                      onCheckedChange={toggleVideoPrivacy}
                    />
                    <Label htmlFor="video-privacy" className="flex items-center gap-1 cursor-pointer">
                      {videoForm.isPrivate ? (
                        <>
                          <Lock className="h-4 w-4 text-amber-500" />
                          <span>Private (Only for my students)</span>
                        </>
                      ) : (
                        <>
                          <Unlock className="h-4 w-4 text-green-500" />
                          <span>School-wide (Available to specific students from all schools)</span>
                        </>
                      )}
                    </Label>
                  </div>

                  {currentUser?.role === 'system_admin' && (
                    <div className="flex items-center space-x-2">
                      <Switch 
                        id="video-global" 
                        checked={videoForm.isGlobal}
                        onCheckedChange={toggleVideoGlobal}
                      />
                      <Label htmlFor="video-global" className="flex items-center gap-1 cursor-pointer">
                        {videoForm.isGlobal ? (
                          <>
                            <Globe className="h-4 w-4 text-blue-500" />
                            <span>System-wide (Available to all schools)</span>
                          </>
                        ) : (
                          <>
                            <Globe className="h-4 w-4 text-gray-400" />
                            <span>Limited distribution</span>
                          </>
                        )}
                      </Label>
                    </div>
                  )}
                  
                  {currentUser?.role === 'teacher' && !videoForm.isPrivate && (
                    <div className="flex items-center pt-1">
                      <Globe className="h-4 w-4 text-blue-500 mr-2" />
                      <p className="text-sm text-blue-700">
                        Your school-wide content will be available to specific students from all schools who access this platform
                      </p>
                    </div>
                  )}
                  
                  <Button type="submit" className="w-full" disabled={isSubmitting}>
                    {isSubmitting ? 'Uploading...' : 'Upload Video'}
                  </Button>
                </form>
              </TabsContent>
            </Tabs>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default ContentUpload;
