import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useToast } from '@/hooks/use-toast';
import { School, User, ShieldCheck, GraduationCap, Building } from 'lucide-react';
import Header from '@/components/Header';
import { toast } from 'sonner';
import { useLanguage } from '@/contexts/LanguageContext';

const Index = () => {
  const { t } = useLanguage();
  const { toast: shadcnToast } = useToast();
  const navigate = useNavigate();
  const [loginData, setLoginData] = useState({
    username: '',
    password: '',
    role: 'admin',
    schoolId: ''
  });
  const [currentUser, setCurrentUser] = useState<any>(null);
  const [schools, setSchools] = useState<any[]>([]);

  useEffect(() => {
    // Check if user is already logged in
    const user = localStorage.getItem('currentUser');
    if (user) {
      const userData = JSON.parse(user);
      setCurrentUser(userData);
      
      // Redirect based on role
      if (userData.role === 'system_admin') {
        navigate('/admin-dashboard');
      } else if (userData.role === 'admin') {
        navigate('/school-admin-dashboard');
      } else if (userData.role === 'teacher') {
        navigate('/teacher-dashboard');
      } else if (userData.role === 'student') {
        navigate('/student-dashboard');
      }
    }
    
    // Initialize system admin if not exists
    const systemAdmin = localStorage.getItem('systemAdmin');
    if (!systemAdmin) {
      localStorage.setItem('systemAdmin', JSON.stringify({
        username: 'admin',
        password: 'admin123',
        role: 'system_admin',
        name: 'System Administrator'
      }));
    }
    
    // Initialize school registrations array if not exists
    if (!localStorage.getItem('schoolRegistrations')) {
      localStorage.setItem('schoolRegistrations', JSON.stringify([]));
    }
    
    // Create demo accounts if they don't exist
    createDemoAccounts();
    
    // Load approved schools for user login
    const storedRegistrations = localStorage.getItem('schoolRegistrations');
    if (storedRegistrations) {
      const registrations = JSON.parse(storedRegistrations);
      const approvedSchools = registrations.filter((school: any) => 
        school.status === 'approved' && school.setupComplete
      );
      setSchools(approvedSchools);
    }
    
    // Initialize educational content array if not exists
    if (!localStorage.getItem('educationalContent')) {
      localStorage.setItem('educationalContent', JSON.stringify([]));
    }
  }, [navigate]);

  const createDemoAccounts = () => {
    // Check if demo school exists
    const storedRegistrations = localStorage.getItem('schoolRegistrations');
    const registrations = storedRegistrations ? JSON.parse(storedRegistrations) : [];
    
    let demoSchool = registrations.find((school: any) => school.id === 'demo-school-1');
    
    if (!demoSchool) {
      // Create demo school
      demoSchool = {
        id: 'demo-school-1',
        schoolName: 'Demo School',
        schoolType: 'private',
        email: 'demo@school.com',
        phone: '1234567890',
        address: '123 Demo Street',
        principalName: 'Demo Principal',
        licenseNumber: 'DEMO123456',
        status: 'approved',
        setupComplete: true,
        createdAt: new Date().toISOString(),
        users: [
          {
            id: 'demo-admin-1',
            name: 'Demo Admin',
            username: 'admin1',
            password: 'password',
            role: 'admin',
            createdAt: new Date().toISOString()
          },
          {
            id: 'demo-teacher-1',
            name: 'Demo Teacher',
            username: 'teacher1',
            password: 'password',
            role: 'teacher',
            createdAt: new Date().toISOString()
          },
          {
            id: 'demo-student-1',
            name: 'Demo Student',
            username: 'student1',
            password: 'password',
            role: 'student',
            grade: '8',
            createdAt: new Date().toISOString()
          }
        ]
      };
      
      registrations.push(demoSchool);
      localStorage.setItem('schoolRegistrations', JSON.stringify(registrations));
    }
  };

  const handleLoginChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setLoginData(prev => ({ ...prev, [name]: value }));
  };

  const handleRoleChange = (role: string) => {
    setLoginData(prev => ({ ...prev, role }));
  };

  const handleSchoolChange = (schoolId: string) => {
    setLoginData(prev => ({ ...prev, schoolId }));
  };

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!loginData.username || !loginData.password) {
      toast.error("Please enter both username and password");
      return;
    }
    
    if (loginData.role === 'system_admin') {
      // Check system admin credentials
      const systemAdmin = JSON.parse(localStorage.getItem('systemAdmin') || '{}');
      
      if (loginData.username === systemAdmin.username && loginData.password === systemAdmin.password) {
        localStorage.setItem('currentUser', JSON.stringify(systemAdmin));
        toast.success("Logged in successfully");
        navigate('/admin-dashboard');
      } else {
        toast.error("Invalid credentials");
      }
    } else {
      // For all non-system-admin logins, need to select a school
      if (!loginData.schoolId) {
        toast.error("Please select your school");
        return;
      }
      
      // Check school admin/teacher/student credentials
      const schoolRegistrations = JSON.parse(localStorage.getItem('schoolRegistrations') || '[]');
      let userFound = false;
      
      // Find the selected school
      const selectedSchool = schoolRegistrations.find((s: any) => s.id === loginData.schoolId);
      
      if (selectedSchool && selectedSchool.users && Array.isArray(selectedSchool.users)) {
        const user = selectedSchool.users.find((u: any) => 
          u.username === loginData.username && 
          u.password === loginData.password && 
          u.role === loginData.role
        );
        
        if (user) {
          const userData = {
            ...user,
            schoolId: selectedSchool.id,
            schoolName: selectedSchool.schoolName,
            schoolType: selectedSchool.schoolType || 'government'
          };
          
          localStorage.setItem('currentUser', JSON.stringify(userData));
          toast.success("Logged in successfully");
          
          if (user.role === 'admin') {
            navigate('/school-admin-dashboard');
          } else if (user.role === 'teacher') {
            navigate('/teacher-dashboard');
          } else {
            navigate('/student-dashboard');
          }
          
          userFound = true;
        }
      }
      
      if (!userFound) {
        toast.error("Invalid credentials or user not found in selected school");
      }
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      
      <div className="container mx-auto px-4 py-12">
        <div className="flex flex-col lg:flex-row items-center gap-12">
          <div className="lg:w-1/2">
            <h1 className="text-4xl font-bold mb-4 text-ethio-primary">{t('ethio_schools_online')}</h1>
            <p className="text-xl mb-6 text-gray-700">A comprehensive solution for school administration, teacher management, and student tracking.</p>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
              <div className="bg-white p-6 rounded-lg shadow-md border-l-4 border-ethio-primary">
                <h3 className="font-semibold text-lg mb-2">{t('school_management')}</h3>
                <p className="text-gray-600">Easily manage school information, classes, staff, and resources.</p>
              </div>
              <div className="bg-white p-6 rounded-lg shadow-md border-l-4 border-ethio-warning">
                <h3 className="font-semibold text-lg mb-2">{t('student_tracking')}</h3>
                <p className="text-gray-600">Track attendance, grades, and performance efficiently.</p>
              </div>
              <div className="bg-white p-6 rounded-lg shadow-md border-l-4 border-ethio-secondary">
                <h3 className="font-semibold text-lg mb-2">{t('teacher_portal')}</h3>
                <p className="text-gray-600">Tools for teachers to manage classes, assignments, and assessments.</p>
              </div>
              <div className="bg-white p-6 rounded-lg shadow-md border-l-4 border-ethio-accent">
                <h3 className="font-semibold text-lg mb-2">{t('reporting')}</h3>
                <p className="text-gray-600">Generate comprehensive reports on school and student performance.</p>
              </div>
            </div>
            
            <div className="flex flex-wrap gap-4">
              <Link to="/register-school">
                <Button size="lg" className="bg-ethio-primary hover:bg-blue-700">
                  {t('register_your_school')}
                </Button>
              </Link>
              <Button variant="outline" size="lg">
                {t('learn_more')}
              </Button>
            </div>
          </div>
          
          <div className="lg:w-1/2 w-full max-w-md">
            <Card className="w-full">
              <CardHeader>
                <CardTitle>{t('login_to_account')}</CardTitle>
                <CardDescription>{t('enter_credentials')}</CardDescription>
              </CardHeader>
              <CardContent>
                <Tabs value={loginData.role} onValueChange={handleRoleChange} className="w-full">
                  <TabsList className="grid w-full grid-cols-4">
                    <TabsTrigger value="admin" className="flex items-center gap-2">
                      <School className="h-4 w-4" />
                      <span>{t('admin')}</span>
                    </TabsTrigger>
                    <TabsTrigger value="teacher" className="flex items-center gap-2">
                      <User className="h-4 w-4" />
                      <span>{t('teacher')}</span>
                    </TabsTrigger>
                    <TabsTrigger value="student" className="flex items-center gap-2">
                      <GraduationCap className="h-4 w-4" />
                      <span>{t('student')}</span>
                    </TabsTrigger>
                    <TabsTrigger value="system_admin" className="flex items-center gap-2">
                      <ShieldCheck className="h-4 w-4" />
                      <span>{t('system')}</span>
                    </TabsTrigger>
                  </TabsList>
                  
                  <TabsContent value="admin" className="mt-4">
                    <form onSubmit={handleLogin} className="space-y-4">
                      <div className="space-y-2">
                        <Label htmlFor="schoolId-admin">{t('select_school')} *</Label>
                        <Select
                          value={loginData.schoolId}
                          onValueChange={handleSchoolChange}
                        >
                          <SelectTrigger>
                            <SelectValue placeholder={t('choose_school')} />
                          </SelectTrigger>
                          <SelectContent>
                            {schools.map((school) => (
                              <SelectItem key={school.id} value={school.id}>
                                <div className="flex items-center gap-2">
                                  <Building className="h-4 w-4" />
                                  <span className="font-medium">{school.schoolName}</span>
                                  <span className="text-xs text-gray-500 capitalize">({school.schoolType})</span>
                                </div>
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="username">{t('username')}</Label>
                        <Input
                          id="username"
                          name="username"
                          value={loginData.username}
                          onChange={handleLoginChange}
                          placeholder={t('enter_username')}
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="password">{t('password')}</Label>
                        <Input
                          id="password"
                          name="password"
                          type="password"
                          value={loginData.password}
                          onChange={handleLoginChange}
                          placeholder={t('enter_password')}
                        />
                      </div>
                      <Button type="submit" className="w-full">{t('login')}</Button>
                    </form>
                  </TabsContent>
                  
                  <TabsContent value="teacher" className="mt-4">
                    <form onSubmit={handleLogin} className="space-y-4">
                      <div className="space-y-2">
                        <Label htmlFor="schoolId-teacher">{t('select_school')} *</Label>
                        <Select
                          value={loginData.schoolId}
                          onValueChange={handleSchoolChange}
                        >
                          <SelectTrigger>
                            <SelectValue placeholder={t('choose_school')} />
                          </SelectTrigger>
                          <SelectContent>
                            {schools.map((school) => (
                              <SelectItem key={school.id} value={school.id}>
                                <div className="flex items-center gap-2">
                                  <Building className="h-4 w-4" />
                                  <span className="font-medium">{school.schoolName}</span>
                                  <span className="text-xs text-gray-500 capitalize">({school.schoolType})</span>
                                </div>
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="username">{t('username')}</Label>
                        <Input
                          id="username"
                          name="username"
                          value={loginData.username}
                          onChange={handleLoginChange}
                          placeholder={t('enter_username')}
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="password">{t('password')}</Label>
                        <Input
                          id="password"
                          name="password"
                          type="password"
                          value={loginData.password}
                          onChange={handleLoginChange}
                          placeholder={t('enter_password')}
                        />
                      </div>
                      <Button type="submit" className="w-full">{t('login')}</Button>
                    </form>
                  </TabsContent>
                  
                  <TabsContent value="student" className="mt-4">
                    <form onSubmit={handleLogin} className="space-y-4">
                      <div className="space-y-2">
                        <Label htmlFor="schoolId-student">{t('select_school')} *</Label>
                        <Select
                          value={loginData.schoolId}
                          onValueChange={handleSchoolChange}
                        >
                          <SelectTrigger>
                            <SelectValue placeholder={t('choose_school')} />
                          </SelectTrigger>
                          <SelectContent>
                            {schools.map((school) => (
                              <SelectItem key={school.id} value={school.id}>
                                <div className="flex items-center gap-2">
                                  <Building className="h-4 w-4" />
                                  <span className="font-medium">{school.schoolName}</span>
                                  <span className="text-xs text-gray-500 capitalize">({school.schoolType})</span>
                                </div>
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="username">{t('username')}</Label>
                        <Input
                          id="username"
                          name="username"
                          value={loginData.username}
                          onChange={handleLoginChange}
                          placeholder={t('enter_username')}
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="password">{t('password')}</Label>
                        <Input
                          id="password"
                          name="password"
                          type="password"
                          value={loginData.password}
                          onChange={handleLoginChange}
                          placeholder={t('enter_password')}
                        />
                      </div>
                      <Button type="submit" className="w-full">{t('login')}</Button>
                    </form>
                  </TabsContent>
                  
                  <TabsContent value="system_admin" className="mt-4">
                    <form onSubmit={handleLogin} className="space-y-4">
                      <div className="space-y-2">
                        <Label htmlFor="username">{t('username')}</Label>
                        <Input
                          id="username"
                          name="username"
                          value={loginData.username}
                          onChange={handleLoginChange}
                          placeholder={t('enter_username')}
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="password">{t('password')}</Label>
                        <Input
                          id="password"
                          name="password"
                          type="password"
                          value={loginData.password}
                          onChange={handleLoginChange}
                          placeholder={t('enter_password')}
                        />
                      </div>
                      <Button type="submit" className="w-full">{t('login')}</Button>
                    </form>
                  </TabsContent>
                </Tabs>
              </CardContent>
              <CardFooter className="flex flex-col space-y-4">
                <p className="text-sm text-gray-500">Default System Admin: admin / admin123</p>
                <div className="bg-blue-50 p-3 rounded-md w-full">
                  <h3 className="font-medium text-blue-800 mb-1">{t('demo_accounts')}</h3>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-2 text-xs">
                    <div className="bg-white p-2 rounded shadow-sm">
                      <p className="font-semibold">{t('school_admin')}</p>
                      <p>{t('username')}: admin1</p>
                      <p>{t('password')}: password</p>
                    </div>
                    <div className="bg-white p-2 rounded shadow-sm">
                      <p className="font-semibold">{t('teacher')}</p>
                      <p>{t('username')}: teacher1</p>
                      <p>{t('password')}: password</p>
                    </div>
                    <div className="bg-white p-2 rounded shadow-sm">
                      <p className="font-semibold">{t('student')}</p>
                      <p>{t('username')}: student1</p>
                      <p>{t('password')}: password</p>
                    </div>
                  </div>
                </div>
              </CardFooter>
            </Card>
          </div>
        </div>
      </div>
      
      <footer className="bg-gray-100 py-8 border-t border-gray-200 mt-12">
        <div className="container mx-auto px-4">
          <div className="text-center">
            <p className="text-gray-600">© 2025 {t('ethio_schools_online')}. All rights reserved.</p>
            <p className="text-gray-500 text-sm mt-2">A comprehensive school management solution</p>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default Index;
