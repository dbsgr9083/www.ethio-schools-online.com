
import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { BookOpen, Upload, FileText, Video, FileClock, User, Key, Briefcase, MessageSquare, Eye, Library } from 'lucide-react';
import Header from '@/components/Header';
import QuizResults from '@/components/QuizResults';
import ChangePasswordDialog from '@/components/ChangePasswordDialog';
import JobVacancyManagement from '@/components/JobVacancyManagement';

const TeacherDashboard = () => {
  const navigate = useNavigate();
  const [currentUser, setCurrentUser] = useState<any>(null);
  const [schoolData, setSchoolData] = useState<any>(null);
  const [teacherContent, setTeacherContent] = useState<any[]>([]);
  const [contentStats, setContentStats] = useState({
    notes: 0,
    quizzes: 0,
    videos: 0
  });
  const [quizResults, setQuizResults] = useState<any[]>([]);
  const [isPasswordDialogOpen, setIsPasswordDialogOpen] = useState(false);
  const [vacancies, setVacancies] = useState<any[]>([]);

  useEffect(() => {
    const userString = localStorage.getItem('currentUser');
    if (userString) {
      const user = JSON.parse(userString);
      setCurrentUser(user);
      
      const schoolRegistrationsString = localStorage.getItem('schoolRegistrations');
      if (schoolRegistrationsString) {
        const schoolRegistrations = JSON.parse(schoolRegistrationsString);
        const school = schoolRegistrations.find((s: any) => s.id === user.schoolId);
        
        if (school) {
          setSchoolData(school);
        }
      }
      
      const contentString = localStorage.getItem('educationalContent');
      if (contentString) {
        const allContent = JSON.parse(contentString);
        const teacherContent = allContent.filter((content: any) => content.teacherId === user.id);
        
        setTeacherContent(teacherContent);
        
        const notes = teacherContent.filter((content: any) => content.type === 'note').length;
        const quizzes = teacherContent.filter((content: any) => content.type === 'quiz').length;
        const videos = teacherContent.filter((content: any) => content.type === 'video').length;
        
        setContentStats({
          notes,
          quizzes,
          videos
        });
      }
      
      const resultsString = localStorage.getItem('quizResults');
      if (resultsString) {
        const allResults = JSON.parse(resultsString);
        setQuizResults(allResults);
      }

      const vacanciesString = localStorage.getItem('jobVacancies');
      if (vacanciesString) {
        const allVacancies = JSON.parse(vacanciesString);
        const approvedVacancies = allVacancies.filter((vacancy: any) => 
          vacancy.status === 'approved'
        );
        setVacancies(approvedVacancies);
      }
    }
  }, []);

  const getRecentContent = () => {
    if (teacherContent.length > 0) {
      return [...teacherContent]
        .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())
        .slice(0, 5);
    }
    return [];
  };

  const getContentTypeIcon = (type: string) => {
    switch (type) {
      case 'note':
        return <FileText className="h-5 w-5 text-ethio-primary" />;
      case 'quiz':
        return <FileClock className="h-5 w-5 text-ethio-warning" />;
      case 'video':
        return <Video className="h-5 w-5 text-ethio-accent" />;
      default:
        return <BookOpen className="h-5 w-5 text-gray-500" />;
    }
  };

  const handleViewQuiz = (quizId: string) => {
    navigate(`/view-quiz/${quizId}`);
  };

  const handleViewNote = (noteId: string) => {
    navigate(`/view-note/${noteId}`);
  };

  const handleViewVideo = (videoUrl: string) => {
    if (videoUrl) {
      window.open(videoUrl, '_blank');
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      
      <div className="container mx-auto px-4 py-8">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-8">
          <div>
            <h1 className="text-2xl font-bold">Teacher Dashboard</h1>
            <p className="text-gray-600">
              Welcome, {currentUser?.name}! Manage your educational content and resources.
            </p>
          </div>
          
          <div className="flex flex-wrap gap-2 mt-4 md:mt-0">
            <Button variant="outline" className="flex items-center gap-2" onClick={() => setIsPasswordDialogOpen(true)}>
              <Key className="h-4 w-4" />
              <span>Change Password</span>
            </Button>
            <Link to="/communication">
              <Button variant="outline" className="flex items-center gap-2">
                <MessageSquare className="h-4 w-4" />
                <span>Messages</span>
              </Button>
            </Link>
            <Link to="/content-library">
              <Button variant="outline" className="flex items-center gap-2">
                <BookOpen className="h-4 w-4" />
                <span>Content Library</span>
              </Button>
            </Link>
            <Link to="/book-library">
              <Button variant="outline" className="flex items-center gap-2">
                <Library className="h-4 w-4" />
                <span>Book Library</span>
              </Button>
            </Link>
            <Link to="/content-upload">
              <Button className="flex items-center gap-2">
                <Upload className="h-4 w-4" />
                <span>Upload Content</span>
              </Button>
            </Link>
          </div>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-lg">Notes</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-center">
                <FileText className="h-8 w-8 mr-3 text-ethio-primary" />
                <span className="text-3xl font-bold">{contentStats.notes}</span>
              </div>
            </CardContent>
            <CardFooter className="pt-0">
              <Link to="/content-upload?type=note" className="text-sm text-ethio-primary hover:underline">
                Upload New Note
              </Link>
            </CardFooter>
          </Card>
          
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-lg">Quizzes</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-center">
                <FileClock className="h-8 w-8 mr-3 text-ethio-warning" />
                <span className="text-3xl font-bold">{contentStats.quizzes}</span>
              </div>
            </CardContent>
            <CardFooter className="pt-0">
              <Link to="/content-upload?type=quiz" className="text-sm text-ethio-primary hover:underline">
                Create New Quiz
              </Link>
            </CardFooter>
          </Card>
          
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-lg">Video Lessons</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-center">
                <Video className="h-8 w-8 mr-3 text-ethio-accent" />
                <span className="text-3xl font-bold">{contentStats.videos}</span>
              </div>
            </CardContent>
            <CardFooter className="pt-0">
              <Link to="/content-upload?type=video" className="text-sm text-ethio-primary hover:underline">
                Upload New Video
              </Link>
            </CardFooter>
          </Card>
        </div>
        
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2">
            <Card>
              <CardHeader>
                <CardTitle>Recent Content</CardTitle>
                <CardDescription>Your most recently uploaded educational content</CardDescription>
              </CardHeader>
              <CardContent>
                {getRecentContent().length > 0 ? (
                  <div className="space-y-4">
                    {getRecentContent().map((content) => (
                      <div key={content.id} className="flex items-start space-x-4 border-b pb-4">
                        <div className="p-2 bg-gray-100 rounded">
                          {getContentTypeIcon(content.type)}
                        </div>
                        <div className="flex-1">
                          <h3 className="font-medium">{content.title}</h3>
                          <p className="text-sm text-gray-500 mb-1">
                            {content.subject} - Grade {content.grade}
                          </p>
                          <div className="flex flex-wrap items-center gap-2 text-xs text-gray-500">
                            <span>Uploaded: {new Date(content.createdAt).toLocaleDateString()}</span>
                            <Badge 
                              variant="outline"
                              className="capitalize text-xs bg-gray-50"
                            >
                              {content.type}
                            </Badge>
                            {content.isPrivate ? (
                              <Badge className="bg-amber-100 text-amber-800 border-amber-300">
                                Private
                              </Badge>
                            ) : (
                              <Badge className="bg-green-100 text-green-800 border-green-300">
                                School-wide
                              </Badge>
                            )}
                          </div>
                        </div>
                        {content.type === 'quiz' ? (
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => handleViewQuiz(content.id)}
                          >
                            <Eye className="h-4 w-4 mr-1" />
                            View Quiz
                          </Button>
                        ) : content.type === 'note' ? (
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => handleViewNote(content.id)}
                          >
                            <Eye className="h-4 w-4 mr-1" />
                            View Note
                          </Button>
                        ) : content.type === 'video' ? (
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => handleViewVideo(content.videoUrl)}
                          >
                            <Eye className="h-4 w-4 mr-1" />
                            Watch Video
                          </Button>
                        ) : (
                          <Link 
                            to="/content-library"
                            className="shrink-0"
                          >
                            <Button variant="ghost" size="sm">
                              <Eye className="h-4 w-4 mr-1" />
                              View
                            </Button>
                          </Link>
                        )}
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-8 text-gray-500">
                    <BookOpen className="h-12 w-12 mx-auto mb-3 text-gray-300" />
                    <p>You haven't uploaded any content yet</p>
                    <Link to="/content-upload">
                      <Button variant="outline" className="mt-4">
                        <Upload className="h-4 w-4 mr-2" />
                        Upload Content
                      </Button>
                    </Link>
                  </div>
                )}
              </CardContent>
              {getRecentContent().length > 0 && (
                <CardFooter>
                  <Link to="/content-library">
                    <Button variant="outline" className="w-full">View All Content</Button>
                  </Link>
                </CardFooter>
              )}
            </Card>
          </div>
          
          <div>
            <Card>
              <CardHeader>
                <CardTitle>Quick Actions</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <Link to="/content-upload?type=note">
                  <Button variant="outline" className="w-full justify-start">
                    <FileText className="h-4 w-4 mr-2 text-ethio-primary" />
                    Upload Note or Document
                  </Button>
                </Link>
                <Link to="/content-upload?type=quiz">
                  <Button variant="outline" className="w-full justify-start">
                    <FileClock className="h-4 w-4 mr-2 text-ethio-warning" />
                    Create a Quiz
                  </Button>
                </Link>
                <Link to="/content-upload?type=video">
                  <Button variant="outline" className="w-full justify-start">
                    <Video className="h-4 w-4 mr-2 text-ethio-accent" />
                    Upload Video Lesson
                  </Button>
                </Link>
                <Link to="/content-library">
                  <Button variant="outline" className="w-full justify-start">
                    <BookOpen className="h-4 w-4 mr-2" />
                    Browse All Content
                  </Button>
                </Link>
              </CardContent>
            </Card>
            
            <Card className="mt-6">
              <CardHeader>
                <CardTitle>School Information</CardTitle>
              </CardHeader>
              <CardContent className="space-y-2">
                {schoolData ? (
                  <>
                    <p className="font-medium">{schoolData.schoolName}</p>
                    <p className="text-sm text-gray-500 capitalize">{schoolData.schoolType} School</p>
                    <p className="text-sm text-gray-500">{schoolData.address}</p>
                  </>
                ) : (
                  <p className="text-sm text-gray-500">School information not available</p>
                )}
              </CardContent>
            </Card>
            
            <Card className="mt-6">
              <CardHeader className="flex flex-row items-center justify-between pb-2">
                <CardTitle className="text-lg">Job Vacancies</CardTitle>
                <Badge variant="outline" className="bg-blue-50 text-blue-700">
                  {vacancies.length} available
                </Badge>
              </CardHeader>
              <CardContent>
                {vacancies.length > 0 ? (
                  <div className="space-y-3">
                    {vacancies.slice(0, 3).map((vacancy) => (
                      <div key={vacancy.id} className="border-b pb-3">
                        <h3 className="font-medium">{vacancy.position}</h3>
                        <p className="text-sm text-gray-500">{vacancy.schoolName}</p>
                        <div className="flex justify-between items-center mt-2">
                          <Badge variant="outline" className="text-xs">
                            {vacancy.type}
                          </Badge>
                          <Button 
                            variant="ghost" 
                            size="sm"
                            onClick={() => navigate(`/communication?tab=jobs&vacancy=${vacancy.id}`)}
                          >
                            Apply
                          </Button>
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <p className="text-sm text-gray-500 text-center py-2">No vacancies available</p>
                )}
              </CardContent>
              {vacancies.length > 0 && (
                <CardFooter className="pt-0">
                  <Button 
                    variant="ghost" 
                    className="w-full text-sm text-ethio-primary"
                    onClick={() => navigate('/communication?tab=jobs')}
                  >
                    <Briefcase className="h-4 w-4 mr-1" />
                    View All Vacancies
                  </Button>
                </CardFooter>
              )}
            </Card>
          </div>
        </div>
        
        {currentUser && (
          <div className="mt-8">
            <QuizResults 
              teacherId={currentUser.id} 
              schoolId={currentUser.schoolId} 
            />
          </div>
        )}
        
        {vacancies.length > 0 && (
          <div className="mt-8">
            <Card>
              <CardHeader>
                <CardTitle>Job Vacancies</CardTitle>
                <CardDescription>View available teaching and administrative positions</CardDescription>
              </CardHeader>
              <CardContent>
                <JobVacancyManagement viewOnly={true} currentUser={currentUser} />
              </CardContent>
            </Card>
          </div>
        )}
      </div>

      {currentUser && (
        <ChangePasswordDialog
          open={isPasswordDialogOpen}
          onOpenChange={setIsPasswordDialogOpen}
          userId={currentUser.id}
          userRole={currentUser.role}
          schoolId={currentUser.schoolId}
        />
      )}
    </div>
  );
};

export default TeacherDashboard;
