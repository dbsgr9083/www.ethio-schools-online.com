
import React, { useState, useEffect } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { toast } from 'sonner';
import { v4 as uuidv4 } from 'uuid';
import { School, CheckCircle, XCircle, Building, Mail, Phone, MapPin, User } from 'lucide-react';
import Header from '@/components/Header';

const PendingSchools = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const [pendingSchools, setPendingSchools] = useState<any[]>([]);
  const [selectedSchool, setSelectedSchool] = useState<any>(null);
  const [isApprovalOpen, setIsApprovalOpen] = useState(false);
  const [credentialsData, setCredentialsData] = useState({
    username: '',
    password: '',
    confirmPassword: ''
  });

  useEffect(() => {
    // Load pending schools from localStorage
    const schoolRegistrationsString = localStorage.getItem('schoolRegistrations');
    if (schoolRegistrationsString) {
      const schoolRegistrations = JSON.parse(schoolRegistrationsString);
      const pending = schoolRegistrations.filter((school: any) => school.status === 'pending');
      setPendingSchools(pending);
      
      // Check if there's an ID in the query params
      const params = new URLSearchParams(location.search);
      const schoolId = params.get('id');
      
      if (schoolId) {
        const school = pending.find((s: any) => s.id === schoolId);
        if (school) {
          setSelectedSchool(school);
        }
      }
    }
  }, [location.search]);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setCredentialsData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handleApprove = (school: any) => {
    setSelectedSchool(school);
    
    // Generate a random username based on school name
    const schoolNameInitials = school.schoolName
      .split(' ')
      .map((word: string) => word.charAt(0))
      .join('')
      .toLowerCase();
    
    const randomSuffix = Math.floor(1000 + Math.random() * 9000);
    const suggestedUsername = `${schoolNameInitials}${randomSuffix}`;
    
    // Generate a random password
    const randomPassword = Math.random().toString(36).slice(-8);
    
    setCredentialsData({
      username: suggestedUsername,
      password: randomPassword,
      confirmPassword: randomPassword
    });
    
    setIsApprovalOpen(true);
  };

  const handleReject = async (schoolId: string) => {
    if (window.confirm('Are you sure you want to reject this school registration?')) {
      try {
        // Get existing registrations
        const registrationsString = localStorage.getItem('schoolRegistrations');
        if (registrationsString) {
          const registrations = JSON.parse(registrationsString);
          
          // Filter out the rejected school
          const updatedRegistrations = registrations.filter((school: any) => school.id !== schoolId);
          
          // Save back to localStorage
          localStorage.setItem('schoolRegistrations', JSON.stringify(updatedRegistrations));
          
          // Update UI
          setPendingSchools(prev => prev.filter(school => school.id !== schoolId));
          
          toast.success('School registration rejected successfully');
        }
      } catch (error) {
        console.error('Error rejecting school:', error);
        toast.error('Failed to reject school registration');
      }
    }
  };

  const handleConfirmApproval = () => {
    // Validate password match
    if (credentialsData.password !== credentialsData.confirmPassword) {
      toast.error('Passwords do not match');
      return;
    }
    
    // Validate password length
    if (credentialsData.password.length < 6) {
      toast.error('Password must be at least 6 characters long');
      return;
    }
    
    try {
      // Get existing registrations
      const registrationsString = localStorage.getItem('schoolRegistrations');
      if (registrationsString && selectedSchool) {
        const registrations = JSON.parse(registrationsString);
        
        // Find the selected school
        const schoolIndex = registrations.findIndex((s: any) => s.id === selectedSchool.id);
        
        if (schoolIndex !== -1) {
          // Create admin account for the school
          const adminAccount = {
            id: uuidv4(),
            name: 'School Administrator',
            username: credentialsData.username,
            password: credentialsData.password,
            role: 'admin',
            createdAt: new Date().toISOString()
          };
          
          // Update school status and add admin account
          registrations[schoolIndex] = {
            ...registrations[schoolIndex],
            status: 'approved',
            setupComplete: true,
            users: [adminAccount]
          };
          
          // Save back to localStorage
          localStorage.setItem('schoolRegistrations', JSON.stringify(registrations));
          
          // Update UI
          setPendingSchools(prev => prev.filter(school => school.id !== selectedSchool.id));
          setIsApprovalOpen(false);
          setSelectedSchool(null);
          
          toast.success('School approved successfully with admin credentials');
        }
      }
    } catch (error) {
      console.error('Error approving school:', error);
      toast.error('Failed to approve school');
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      
      <div className="container mx-auto px-4 py-8">
        <div className="flex justify-between items-center mb-8">
          <div>
            <h1 className="text-2xl font-bold">Pending School Approvals</h1>
            <p className="text-gray-600">Review and approve school registration requests</p>
          </div>
          
          <Button variant="outline" onClick={() => navigate('/admin-dashboard')}>
            Back to Dashboard
          </Button>
        </div>
        
        {pendingSchools.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {pendingSchools.map(school => (
              <Card key={school.id} className="overflow-hidden">
                <CardHeader className="pb-4">
                  <div className="flex justify-between items-start">
                    <CardTitle className="text-lg">{school.schoolName}</CardTitle>
                    <Badge className="capitalize bg-amber-50 text-amber-700 hover:bg-amber-50">
                      {school.schoolType}
                    </Badge>
                  </div>
                  <CardDescription>
                    Registration Date: {new Date(school.createdAt).toLocaleDateString()}
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="flex items-center text-sm">
                    <Building className="h-4 w-4 mr-2 text-gray-500" />
                    <span>License: {school.licenseNumber}</span>
                  </div>
                  <div className="flex items-center text-sm">
                    <Mail className="h-4 w-4 mr-2 text-gray-500" />
                    <span>{school.email}</span>
                  </div>
                  <div className="flex items-center text-sm">
                    <Phone className="h-4 w-4 mr-2 text-gray-500" />
                    <span>{school.phone}</span>
                  </div>
                  <div className="flex items-center text-sm">
                    <MapPin className="h-4 w-4 mr-2 text-gray-500" />
                    <span className="line-clamp-1">{school.address}</span>
                  </div>
                  <div className="flex items-center text-sm">
                    <User className="h-4 w-4 mr-2 text-gray-500" />
                    <span>Principal: {school.principalName}</span>
                  </div>
                </CardContent>
                <CardFooter className="border-t pt-4 flex justify-between">
                  <Button 
                    variant="outline" 
                    size="sm" 
                    className="border-red-200 text-red-600 hover:bg-red-50 hover:text-red-700"
                    onClick={() => handleReject(school.id)}
                  >
                    <XCircle className="h-4 w-4 mr-1" />
                    Reject
                  </Button>
                  <Button 
                    variant="outline" 
                    size="sm" 
                    className="border-green-200 text-green-600 hover:bg-green-50 hover:text-green-700"
                    onClick={() => handleApprove(school)}
                  >
                    <CheckCircle className="h-4 w-4 mr-1" />
                    Approve
                  </Button>
                </CardFooter>
              </Card>
            ))}
          </div>
        ) : (
          <div className="flex flex-col items-center justify-center py-12 text-gray-500">
            <School className="h-16 w-16 mb-4 text-gray-300" />
            <h2 className="text-xl font-medium mb-2">No Pending Schools</h2>
            <p>There are no schools waiting for approval at this time.</p>
            <Button 
              variant="outline" 
              className="mt-4"
              onClick={() => navigate('/admin-dashboard')}
            >
              Return to Dashboard
            </Button>
          </div>
        )}
      </div>
      
      {/* Approval Dialog */}
      <Dialog open={isApprovalOpen} onOpenChange={setIsApprovalOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Approve School & Create Admin Account</DialogTitle>
            <DialogDescription>
              You are approving {selectedSchool?.schoolName}. Set up admin login credentials for this school.
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label htmlFor="username">Admin Username</Label>
              <Input
                id="username"
                name="username"
                value={credentialsData.username}
                onChange={handleInputChange}
                placeholder="Enter admin username"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="password">Admin Password</Label>
              <Input
                id="password"
                name="password"
                type="password"
                value={credentialsData.password}
                onChange={handleInputChange}
                placeholder="Enter admin password"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="confirmPassword">Confirm Password</Label>
              <Input
                id="confirmPassword"
                name="confirmPassword"
                type="password"
                value={credentialsData.confirmPassword}
                onChange={handleInputChange}
                placeholder="Confirm admin password"
              />
            </div>
          </div>
          
          <DialogFooter className="sm:justify-between">
            <Button
              variant="outline"
              onClick={() => setIsApprovalOpen(false)}
            >
              Cancel
            </Button>
            <Button
              onClick={handleConfirmApproval}
              className="bg-ethio-secondary hover:bg-green-700"
            >
              Approve & Create Account
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default PendingSchools;
