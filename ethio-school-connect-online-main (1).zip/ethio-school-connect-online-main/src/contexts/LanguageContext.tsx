
import React, { createContext, useState, useContext, useEffect, ReactNode } from 'react';

// Define the available languages
export type Language = 'en' | 'am';

// Interface for our language context
interface LanguageContextType {
  language: Language;
  setLanguage: (language: Language) => void;
  t: (key: string) => string;
}

// Create the context with a default value
const LanguageContext = createContext<LanguageContextType | undefined>(undefined);

// Translation dictionary
const translations: Record<Language, Record<string, string>> = {
  en: {
    // Header translations
    'welcome': 'Welcome',
    'logout': 'Logout',
    'manage_users': 'Manage Users',
    'upload_content': 'Upload Content',
    'content_library': 'Content Library',
    'messages': 'Messages',
    'register_school': 'Register School',
    'login': 'Login',
    
    // Common phrases
    'ethio_schools_online': 'Ethio-Schools Online',
    'school_management': 'School Management',
    'student_tracking': 'Student Tracking',
    'teacher_portal': 'Teacher Portal',
    'reporting': 'Reporting',
    'learn_more': 'Learn More',
    'register_your_school': 'Register Your School',
    
    // Login page
    'login_to_account': 'Login to Your Account',
    'enter_credentials': 'Enter your credentials to access the system',
    'admin': 'Admin',
    'teacher': 'Teacher',
    'student': 'Student',
    'system': 'System',
    'select_school': 'Select Your School',
    'choose_school': 'Choose your school',
    'username': 'Username',
    'password': 'Password',
    'enter_username': 'Enter your username',
    'enter_password': 'Enter your password',
    'demo_accounts': 'Demo Accounts',
    'school_admin': 'School Admin',
  },
  am: {
    // Header translations
    'welcome': 'እንኳን ደህና መጡ',
    'logout': 'ውጣ',
    'manage_users': 'ተጠቃሚዎችን አስተዳድር',
    'upload_content': 'ይዘት ስቀል',
    'content_library': 'የይዘት ቤተ-መጻሕፍት',
    'messages': 'መልእክቶች',
    'register_school': 'ትምህርት ቤት መመዝገቢያ',
    'login': 'ግባ',
    
    // Common phrases
    'ethio_schools_online': 'የኢትዮጵያ ትምህርት ቤቶች ኦንላይን',
    'school_management': 'የትምህርት ቤት አስተዳደር',
    'student_tracking': 'የተማሪ ክትትል',
    'teacher_portal': 'የመምህራን ገጽ',
    'reporting': 'ሪፖርት ማድረግ',
    'learn_more': 'ተጨማሪ ይማሩ',
    'register_your_school': 'ትምህርት ቤትዎን ይመዝግቡ',
    
    // Login page
    'login_to_account': 'ወደ መለያዎ ይግቡ',
    'enter_credentials': 'ወደ ሲስተሙ ለመግባት መረጃዎችዎን ያስገቡ',
    'admin': 'አስተዳዳሪ',
    'teacher': 'መምህር',
    'student': 'ተማሪ',
    'system': 'ሲስተም',
    'select_school': 'ትምህርት ቤትዎን ይምረጡ',
    'choose_school': 'ትምህርት ቤትዎን ይምረጡ',
    'username': 'የተጠቃሚ ስም',
    'password': 'የይለፍ ቃል',
    'enter_username': 'የተጠቃሚ ስምዎን ያስገቡ',
    'enter_password': 'የይለፍ ቃልዎን ያስገቡ',
    'demo_accounts': 'የሙከራ መለያዎች',
    'school_admin': 'የትምህርት ቤት አስተዳዳሪ',
  }
};

// Provider component
export const LanguageProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  // Try to get the language from localStorage, default to English
  const [language, setLanguageState] = useState<Language>(() => {
    const savedLanguage = localStorage.getItem('language') as Language;
    return savedLanguage === 'am' ? 'am' : 'en';
  });

  // Update localStorage when language changes
  useEffect(() => {
    localStorage.setItem('language', language);
  }, [language]);

  // Function to change the language
  const setLanguage = (newLanguage: Language) => {
    setLanguageState(newLanguage);
  };

  // Translation function
  const t = (key: string): string => {
    return translations[language][key] || key;
  };

  return (
    <LanguageContext.Provider value={{ language, setLanguage, t }}>
      {children}
    </LanguageContext.Provider>
  );
};

// Custom hook to use the language context
export const useLanguage = (): LanguageContextType => {
  const context = useContext(LanguageContext);
  if (context === undefined) {
    throw new Error('useLanguage must be used within a LanguageProvider');
  }
  return context;
};
