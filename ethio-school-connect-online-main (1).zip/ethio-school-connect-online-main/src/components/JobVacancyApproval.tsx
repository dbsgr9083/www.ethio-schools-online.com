
import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Briefcase, School, Calendar, UserCheck, UserX, Eye } from 'lucide-react';
import { toast } from 'sonner';

interface JobVacancy {
  id: string;
  schoolId: string;
  schoolName: string;
  title: string;
  description: string;
  requirements: string;
  position: string;
  location: string;
  createdAt: string;
  status?: 'pending' | 'approved' | 'rejected';
  reviewedBy?: string;
  reviewedAt?: string;
  reviewNotes?: string;
}

const JobVacancyApproval: React.FC<{ currentUser: any }> = ({ currentUser }) => {
  const [vacancies, setVacancies] = useState<JobVacancy[]>([]);
  const [selectedVacancy, setSelectedVacancy] = useState<JobVacancy | null>(null);
  const [viewMode, setViewMode] = useState<'pending' | 'all'>('pending');
  const [isDetailsOpen, setIsDetailsOpen] = useState(false);
  
  useEffect(() => {
    // Load job vacancies from localStorage
    loadVacancies();
  }, []);
  
  const loadVacancies = () => {
    const vacanciesString = localStorage.getItem('jobVacancies');
    if (vacanciesString) {
      let allVacancies: JobVacancy[] = JSON.parse(vacanciesString);
      
      // Ensure all vacancies have a status field
      allVacancies = allVacancies.map((vacancy: any) => {
        if (!vacancy.status) {
          return { ...vacancy, status: 'pending' as const };
        }
        return vacancy as JobVacancy;
      });
      
      // Update localStorage with statuses if needed
      localStorage.setItem('jobVacancies', JSON.stringify(allVacancies));
      setVacancies(allVacancies);
    }
  };
  
  const viewVacancyDetails = (vacancy: JobVacancy) => {
    setSelectedVacancy(vacancy);
    setIsDetailsOpen(true);
  };
  
  const handleAction = (vacancyId: string, action: 'approve' | 'reject') => {
    // Update the vacancy status
    const updatedVacancies = vacancies.map(vacancy => {
      if (vacancy.id === vacancyId) {
        return {
          ...vacancy,
          status: action === 'approve' ? 'approved' as const : 'rejected' as const,
          reviewedBy: currentUser.id,
          reviewedAt: new Date().toISOString()
        };
      }
      return vacancy;
    });
    
    // Update state and localStorage
    setVacancies(updatedVacancies);
    localStorage.setItem('jobVacancies', JSON.stringify(updatedVacancies));
    
    // Close the details dialog
    setIsDetailsOpen(false);
    
    // Show toast notification
    toast.success(`Job vacancy ${action === 'approve' ? 'approved' : 'rejected'} successfully`);
    
    // Add activity log for the school
    if (selectedVacancy) {
      const activityLogsString = localStorage.getItem('schoolActivityLogs');
      const activityLogs = activityLogsString ? JSON.parse(activityLogsString) : [];
      
      activityLogs.push({
        id: Date.now().toString(),
        schoolId: selectedVacancy.schoolId,
        activity: `Job vacancy "${selectedVacancy.title}" was ${action === 'approve' ? 'approved' : 'rejected'} by System Administrator`,
        timestamp: new Date().toISOString(),
        userId: currentUser.id,
        userRole: currentUser.role
      });
      
      localStorage.setItem('schoolActivityLogs', JSON.stringify(activityLogs));
    }
  };
  
  // Filter vacancies based on view mode
  const filteredVacancies = viewMode === 'pending' 
    ? vacancies.filter(v => !v.status || v.status === 'pending')
    : vacancies;

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h2 className="text-xl font-bold">Job Vacancy Approval</h2>
          <p className="text-gray-500">Review and approve job vacancies posted by school administrators</p>
        </div>
        
        <div className="flex items-center gap-2">
          <Button 
            variant={viewMode === 'pending' ? 'default' : 'outline'}
            onClick={() => setViewMode('pending')}
          >
            Pending Review
          </Button>
          <Button 
            variant={viewMode === 'all' ? 'default' : 'outline'}
            onClick={() => setViewMode('all')}
          >
            All Vacancies
          </Button>
        </div>
      </div>
      
      <Card>
        <CardHeader>
          <CardTitle>{viewMode === 'pending' ? 'Pending Vacancies' : 'All Vacancies'}</CardTitle>
          <CardDescription>
            {viewMode === 'pending' 
              ? 'Review job vacancies that require your approval' 
              : 'View all job vacancies across schools'}
          </CardDescription>
        </CardHeader>
        <CardContent>
          {filteredVacancies.length === 0 ? (
            <div className="text-center py-10 text-gray-500">
              <Briefcase className="h-12 w-12 mx-auto mb-3 text-gray-400" />
              <p>No {viewMode === 'pending' ? 'pending' : ''} job vacancies found</p>
            </div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Job Title</TableHead>
                  <TableHead>School</TableHead>
                  <TableHead>Position</TableHead>
                  <TableHead>Posted On</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead className="w-[100px]">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredVacancies.map((vacancy) => (
                  <TableRow key={vacancy.id}>
                    <TableCell className="font-medium">{vacancy.title}</TableCell>
                    <TableCell>
                      <div className="flex items-center">
                        <School className="h-4 w-4 mr-2 text-ethio-primary" />
                        {vacancy.schoolName}
                      </div>
                    </TableCell>
                    <TableCell>{vacancy.position}</TableCell>
                    <TableCell>
                      <div className="flex items-center">
                        <Calendar className="h-4 w-4 mr-2 text-ethio-secondary" />
                        {new Date(vacancy.createdAt).toLocaleDateString()}
                      </div>
                    </TableCell>
                    <TableCell>
                      <Badge 
                        variant="outline" 
                        className={`
                          ${!vacancy.status || vacancy.status === 'pending' 
                            ? 'bg-yellow-50 text-yellow-700 hover:bg-yellow-50' 
                            : vacancy.status === 'approved'
                              ? 'bg-green-50 text-green-700 hover:bg-green-50'
                              : 'bg-red-50 text-red-700 hover:bg-red-50'
                          }
                        `}
                      >
                        {!vacancy.status || vacancy.status === 'pending' 
                          ? 'Pending' 
                          : vacancy.status === 'approved' 
                            ? 'Approved' 
                            : 'Rejected'}
                      </Badge>
                    </TableCell>
                    <TableCell>
                      <Button 
                        variant="ghost" 
                        size="sm"
                        className="flex items-center gap-1"
                        onClick={() => viewVacancyDetails(vacancy)}
                      >
                        <Eye className="h-4 w-4" />
                        <span>View</span>
                      </Button>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>
      
      {/* Vacancy Details Dialog */}
      <Dialog open={isDetailsOpen} onOpenChange={setIsDetailsOpen}>
        <DialogContent className="max-w-3xl">
          {selectedVacancy && (
            <>
              <DialogHeader>
                <DialogTitle className="text-xl">{selectedVacancy.title}</DialogTitle>
                <DialogDescription className="flex items-center gap-2 pt-1">
                  <School className="h-4 w-4 text-ethio-primary" />
                  <span>{selectedVacancy.schoolName}</span>
                  <Badge 
                    variant="outline" 
                    className={`ml-2 ${
                      !selectedVacancy.status || selectedVacancy.status === 'pending' 
                        ? 'bg-yellow-50 text-yellow-700' 
                        : selectedVacancy.status === 'approved' 
                          ? 'bg-green-50 text-green-700'
                          : 'bg-red-50 text-red-700'
                    }`}
                  >
                    {!selectedVacancy.status || selectedVacancy.status === 'pending' 
                      ? 'Pending' 
                      : selectedVacancy.status === 'approved' 
                        ? 'Approved' 
                        : 'Rejected'}
                  </Badge>
                </DialogDescription>
              </DialogHeader>
              
              <div className="space-y-4 my-4">
                <div>
                  <h3 className="text-sm font-medium text-gray-500">Position</h3>
                  <p>{selectedVacancy.position}</p>
                </div>
                
                <div>
                  <h3 className="text-sm font-medium text-gray-500">Location</h3>
                  <p>{selectedVacancy.location}</p>
                </div>
                
                <div>
                  <h3 className="text-sm font-medium text-gray-500">Job Description</h3>
                  <p className="whitespace-pre-line">{selectedVacancy.description}</p>
                </div>
                
                <div>
                  <h3 className="text-sm font-medium text-gray-500">Requirements</h3>
                  <p className="whitespace-pre-line">{selectedVacancy.requirements}</p>
                </div>
                
                <div>
                  <h3 className="text-sm font-medium text-gray-500">Posted On</h3>
                  <p>{new Date(selectedVacancy.createdAt).toLocaleString()}</p>
                </div>
                
                {selectedVacancy.status && selectedVacancy.status !== 'pending' && selectedVacancy.reviewedAt && (
                  <div>
                    <h3 className="text-sm font-medium text-gray-500">Reviewed On</h3>
                    <p>{new Date(selectedVacancy.reviewedAt).toLocaleString()}</p>
                  </div>
                )}
              </div>
              
              <DialogFooter className="flex items-center justify-end gap-2">
                {(!selectedVacancy.status || selectedVacancy.status === 'pending') && (
                  <>
                    <Button 
                      variant="outline" 
                      className="flex items-center gap-2 text-red-600" 
                      onClick={() => handleAction(selectedVacancy.id, 'reject')}
                    >
                      <UserX className="h-4 w-4" />
                      Reject Vacancy
                    </Button>
                    
                    <Button 
                      className="flex items-center gap-2" 
                      onClick={() => handleAction(selectedVacancy.id, 'approve')}
                    >
                      <UserCheck className="h-4 w-4" />
                      Approve Vacancy
                    </Button>
                  </>
                )}
                
                {selectedVacancy.status && selectedVacancy.status !== 'pending' && (
                  <Button onClick={() => setIsDetailsOpen(false)}>Close</Button>
                )}
              </DialogFooter>
            </>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default JobVacancyApproval;
