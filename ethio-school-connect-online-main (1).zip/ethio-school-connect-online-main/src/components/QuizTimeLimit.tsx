
import React from 'react';
import { Label } from '@/components/ui/label';
import { Slider } from '@/components/ui/slider';
import { Clock } from 'lucide-react';
import { Switch } from '@/components/ui/switch';

interface QuizTimeLimitProps {
  timeLimit: number;
  setTimeLimit: (value: number) => void;
  hasTimeLimit: boolean;
  setHasTimeLimit: (value: boolean) => void;
  questionCount?: number;
}

const QuizTimeLimit: React.FC<QuizTimeLimitProps> = ({ 
  timeLimit, 
  setTimeLimit, 
  hasTimeLimit, 
  setHasTimeLimit,
  questionCount = 1
}) => {
  const handleSliderChange = (value: number[]) => {
    setTimeLimit(value[0]);
  };

  const toggleTimeLimit = (checked: boolean) => {
    setHasTimeLimit(checked);
    if (!checked) {
      setTimeLimit(0);
    } else if (timeLimit === 0) {
      // Default to 2 minutes per question when enabling
      setTimeLimit(2 * questionCount);
    }
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center space-x-2">
        <Switch 
          id="time-limit-toggle" 
          checked={hasTimeLimit}
          onCheckedChange={toggleTimeLimit}
        />
        <Label htmlFor="time-limit-toggle" className="text-sm font-medium">
          Enable Time Limit
        </Label>
      </div>
      
      {hasTimeLimit && (
        <div className="space-y-2">
          <div className="flex items-center justify-between">
            <Label htmlFor="timeLimit" className="text-sm font-medium">Time Limit (Minutes)</Label>
            <div className="flex items-center space-x-1 text-sm text-ethio-primary font-medium">
              <Clock className="h-4 w-4" />
              <span>{timeLimit} {timeLimit === 1 ? 'minute' : 'minutes'}</span>
              {questionCount > 1 && (
                <span className="text-xs text-gray-500">
                  (~{Math.round(timeLimit / questionCount * 10) / 10} min/question)
                </span>
              )}
            </div>
          </div>
          <Slider
            id="timeLimit"
            value={[timeLimit]}
            max={120}
            min={5}
            step={5}
            onValueChange={handleSliderChange}
            className="w-full"
            disabled={!hasTimeLimit}
          />
          <p className="text-xs text-gray-500 mt-1">
            Students will have {timeLimit} minutes to complete this quiz
            {questionCount > 1 ? ` (about ${Math.round(timeLimit / questionCount * 10) / 10} minutes per question)` : ''}
          </p>
        </div>
      )}
    </div>
  );
};

export default QuizTimeLimit;
