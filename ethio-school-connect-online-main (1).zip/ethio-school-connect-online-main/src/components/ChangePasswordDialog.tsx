
import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { toast } from 'sonner';

interface ChangePasswordDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  userId: string;
  userRole: string;
  schoolId?: string;
}

const ChangePasswordDialog: React.FC<ChangePasswordDialogProps> = ({
  open,
  onOpenChange,
  userId,
  userRole,
  schoolId
}) => {
  const [currentPassword, setCurrentPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);

    // Validate passwords
    if (!currentPassword || !newPassword || !confirmPassword) {
      toast.error('All fields are required');
      setIsSubmitting(false);
      return;
    }

    if (newPassword !== confirmPassword) {
      toast.error('New passwords do not match');
      setIsSubmitting(false);
      return;
    }

    if (newPassword.length < 6) {
      toast.error('New password must be at least 6 characters');
      setIsSubmitting(false);
      return;
    }

    // Handle password change logic
    if (userRole === 'system_admin') {
      // For system admin
      const systemAdminString = localStorage.getItem('systemAdmin');
      if (systemAdminString) {
        const systemAdmin = JSON.parse(systemAdminString);
        
        if (systemAdmin.password !== currentPassword) {
          toast.error('Current password is incorrect');
          setIsSubmitting(false);
          return;
        }
        
        systemAdmin.password = newPassword;
        localStorage.setItem('systemAdmin', JSON.stringify(systemAdmin));
        
        // Update current user if logged in
        const currentUserString = localStorage.getItem('currentUser');
        if (currentUserString) {
          const currentUser = JSON.parse(currentUserString);
          if (currentUser.role === 'system_admin') {
            currentUser.password = newPassword;
            localStorage.setItem('currentUser', JSON.stringify(currentUser));
          }
        }
        
        toast.success('Password changed successfully');
        resetForm();
        onOpenChange(false);
      }
    } else {
      // For school users (admin, teacher, student)
      const schoolsString = localStorage.getItem('schoolRegistrations');
      if (schoolsString && schoolId) {
        const schools = JSON.parse(schoolsString);
        const schoolIndex = schools.findIndex((s: any) => s.id === schoolId);
        
        if (schoolIndex !== -1) {
          const userIndex = schools[schoolIndex].users.findIndex((u: any) => u.id === userId);
          
          if (userIndex !== -1) {
            const user = schools[schoolIndex].users[userIndex];
            
            if (user.password !== currentPassword) {
              toast.error('Current password is incorrect');
              setIsSubmitting(false);
              return;
            }
            
            user.password = newPassword;
            schools[schoolIndex].users[userIndex] = user;
            localStorage.setItem('schoolRegistrations', JSON.stringify(schools));
            
            // Update current user if logged in
            const currentUserString = localStorage.getItem('currentUser');
            if (currentUserString) {
              const currentUser = JSON.parse(currentUserString);
              if (currentUser.id === userId) {
                currentUser.password = newPassword;
                localStorage.setItem('currentUser', JSON.stringify(currentUser));
              }
            }
            
            toast.success('Password changed successfully');
            resetForm();
            onOpenChange(false);
          }
        }
      }
    }
    
    setIsSubmitting(false);
  };

  const resetForm = () => {
    setCurrentPassword('');
    setNewPassword('');
    setConfirmPassword('');
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Change Password</DialogTitle>
          <DialogDescription>
            Update your password for security. Make sure to remember your new password.
          </DialogDescription>
        </DialogHeader>
        
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="current-password">Current Password</Label>
            <Input
              id="current-password"
              type="password"
              value={currentPassword}
              onChange={(e) => setCurrentPassword(e.target.value)}
              placeholder="Enter your current password"
            />
          </div>
          
          <div className="space-y-2">
            <Label htmlFor="new-password">New Password</Label>
            <Input
              id="new-password"
              type="password"
              value={newPassword}
              onChange={(e) => setNewPassword(e.target.value)}
              placeholder="Enter your new password"
            />
          </div>
          
          <div className="space-y-2">
            <Label htmlFor="confirm-password">Confirm New Password</Label>
            <Input
              id="confirm-password"
              type="password"
              value={confirmPassword}
              onChange={(e) => setConfirmPassword(e.target.value)}
              placeholder="Confirm your new password"
            />
          </div>
          
          <DialogFooter className="pt-4">
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>
              Cancel
            </Button>
            <Button type="submit" disabled={isSubmitting}>
              {isSubmitting ? 'Updating...' : 'Update Password'}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
};

export default ChangePasswordDialog;
