
import React from 'react';
import { Label } from '@/components/ui/label';
import { RepeatIcon } from 'lucide-react';
import { Switch } from '@/components/ui/switch';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';

interface QuizAttemptLimitProps {
  attemptLimit: number;
  setAttemptLimit: (value: number) => void;
  hasAttemptLimit: boolean;
  setHasAttemptLimit: (value: boolean) => void;
}

const QuizAttemptLimit: React.FC<QuizAttemptLimitProps> = ({
  attemptLimit,
  setAttemptLimit,
  hasAttemptLimit,
  setHasAttemptLimit
}) => {
  const handleSelectChange = (value: string) => {
    setAttemptLimit(parseInt(value));
  };

  const toggleAttemptLimit = (checked: boolean) => {
    setHasAttemptLimit(checked);
    if (!checked) {
      setAttemptLimit(0);
    } else if (attemptLimit === 0) {
      setAttemptLimit(1); // Default to 1 attempt when enabling
    }
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center space-x-2">
        <Switch 
          id="attempt-limit-toggle" 
          checked={hasAttemptLimit}
          onCheckedChange={toggleAttemptLimit}
        />
        <Label htmlFor="attempt-limit-toggle" className="text-sm font-medium">
          Limit Number of Attempts
        </Label>
      </div>
      
      {hasAttemptLimit && (
        <div className="space-y-2">
          <div className="flex items-center justify-between">
            <Label htmlFor="attemptLimit" className="text-sm font-medium">
              Maximum Attempts
            </Label>
          </div>
          <Select
            disabled={!hasAttemptLimit}
            value={attemptLimit.toString()}
            onValueChange={handleSelectChange}
          >
            <SelectTrigger>
              <SelectValue placeholder="Select maximum attempts" />
            </SelectTrigger>
            <SelectContent>
              {[1, 2, 3, 5, 10].map((value) => (
                <SelectItem key={value} value={value.toString()}>
                  {value} {value === 1 ? 'attempt' : 'attempts'}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
          <p className="text-xs text-gray-500 mt-1">
            {hasAttemptLimit
              ? `Students can attempt this quiz ${attemptLimit} ${attemptLimit === 1 ? 'time' : 'times'}`
              : 'Students can attempt this quiz unlimited times'}
          </p>
        </div>
      )}
    </div>
  );
};

export default QuizAttemptLimit;
