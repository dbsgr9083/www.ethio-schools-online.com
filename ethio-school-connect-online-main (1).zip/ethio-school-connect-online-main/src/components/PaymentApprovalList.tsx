
import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { toast } from 'sonner';
import { supabase } from '@/integrations/supabase/client';
import { FileText, Check, X, ExternalLink } from 'lucide-react';

interface PaymentRecord {
  id: string;
  school_id: string;
  amount: number;
  currency: string;
  transaction_number: string;
  payment_method: string;
  receipt_file_path: string | null;
  payment_status: string;
  admin_verified: boolean;
  created_at: string;
  school_name?: string;
}

const PaymentApprovalList = () => {
  const [payments, setPayments] = useState<PaymentRecord[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedPayment, setSelectedPayment] = useState<PaymentRecord | null>(null);
  const [receiptUrl, setReceiptUrl] = useState<string | null>(null);
  const [viewReceiptOpen, setViewReceiptOpen] = useState(false);
  const [approvalDialogOpen, setApprovalDialogOpen] = useState(false);

  useEffect(() => {
    fetchPaymentRecords();
  }, []);

  const fetchPaymentRecords = async () => {
    setLoading(true);
    try {
      // Fetch payment records
      const { data: paymentData, error: paymentError } = await supabase
        .from('school_payments')
        .select('*')
        .order('created_at', { ascending: false });
        
      if (paymentError) {
        console.error('Error fetching payments:', paymentError);
        toast.error('Failed to load payment records');
        setLoading(false);
        return;
      }
      
      // Get school registrations from localStorage to match school_id with school name
      const schoolRegistrationsString = localStorage.getItem('schoolRegistrations');
      const schoolRegistrations = schoolRegistrationsString 
        ? JSON.parse(schoolRegistrationsString) 
        : [];
      
      // Combine data
      const combinedData = paymentData?.map((payment: PaymentRecord) => {
        const school = schoolRegistrations.find((s: any) => s.id === payment.school_id);
        return {
          ...payment,
          school_name: school ? school.schoolName : 'Unknown School'
        };
      }) || [];
      
      setPayments(combinedData);
    } catch (error) {
      console.error('Error:', error);
      toast.error('An error occurred while fetching payment records');
    } finally {
      setLoading(false);
    }
  };

  const handleViewReceipt = async (payment: PaymentRecord) => {
    if (!payment.receipt_file_path) {
      toast.error('No receipt file available');
      return;
    }
    
    try {
      const { data, error } = await supabase.storage
        .from('school_receipts')
        .createSignedUrl(payment.receipt_file_path, 60); // 60 seconds expiry
        
      if (error) {
        console.error('Error getting receipt URL:', error);
        toast.error('Failed to retrieve receipt file');
        return;
      }
      
      if (data?.signedUrl) {
        setReceiptUrl(data.signedUrl);
        setViewReceiptOpen(true);
      }
    } catch (error) {
      console.error('Error:', error);
      toast.error('An error occurred');
    }
  };

  const handleApprovePayment = (payment: PaymentRecord) => {
    setSelectedPayment(payment);
    setApprovalDialogOpen(true);
  };

  const confirmApproval = async () => {
    if (!selectedPayment) return;
    
    try {
      // Update payment record
      const { error: paymentError } = await supabase
        .from('school_payments')
        .update({
          payment_status: 'approved',
          admin_verified: true,
        })
        .eq('id', selectedPayment.id);
        
      if (paymentError) {
        console.error('Error updating payment:', paymentError);
        toast.error('Failed to approve payment');
        setApprovalDialogOpen(false);
        return;
      }
      
      // Update school status in localStorage
      const schoolRegistrationsString = localStorage.getItem('schoolRegistrations');
      if (schoolRegistrationsString) {
        const schoolRegistrations = JSON.parse(schoolRegistrationsString);
        const updatedRegistrations = schoolRegistrations.map((school: any) => {
          if (school.id === selectedPayment.school_id) {
            return { ...school, status: 'approved' };
          }
          return school;
        });
        
        localStorage.setItem('schoolRegistrations', JSON.stringify(updatedRegistrations));
      }
      
      // Update local state
      setPayments(payments.map(p => 
        p.id === selectedPayment.id 
          ? { ...p, payment_status: 'approved', admin_verified: true } 
          : p
      ));
      
      toast.success('Payment approved and school registration updated');
      setApprovalDialogOpen(false);
      
      // Refresh data
      fetchPaymentRecords();
    } catch (error) {
      console.error('Error:', error);
      toast.error('An error occurred during approval');
      setApprovalDialogOpen(false);
    }
  };

  const handleRejectPayment = async (payment: PaymentRecord) => {
    try {
      const { error } = await supabase
        .from('school_payments')
        .update({
          payment_status: 'rejected',
          admin_verified: true,
        })
        .eq('id', payment.id);
        
      if (error) {
        console.error('Error rejecting payment:', error);
        toast.error('Failed to reject payment');
        return;
      }
      
      // Update local state
      setPayments(payments.map(p => 
        p.id === payment.id 
          ? { ...p, payment_status: 'rejected', admin_verified: true } 
          : p
      ));
      
      toast.success('Payment rejected');
    } catch (error) {
      console.error('Error:', error);
      toast.error('An error occurred');
    }
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle>School Payment Records</CardTitle>
        <CardDescription>Manage and verify school registration payments</CardDescription>
      </CardHeader>
      <CardContent>
        {loading ? (
          <div className="text-center py-8">
            <p>Loading payment records...</p>
          </div>
        ) : payments.length === 0 ? (
          <div className="text-center py-8 text-gray-500">
            <FileText className="h-12 w-12 mx-auto mb-3 text-gray-400" />
            <p>No payment records found</p>
          </div>
        ) : (
          <div className="space-y-4">
            {payments.map((payment) => (
              <div key={payment.id} className="flex items-start justify-between border-b pb-4">
                <div>
                  <h3 className="font-medium">{payment.school_name}</h3>
                  <p className="text-sm text-gray-500">
                    {payment.amount} {payment.currency} via {payment.payment_method}
                  </p>
                  <p className="text-sm text-gray-500">Ref: {payment.transaction_number}</p>
                  <div className="flex items-center mt-1">
                    <p className="text-xs text-gray-500">
                      {new Date(payment.created_at).toLocaleDateString()}
                    </p>
                    <Badge 
                      variant={
                        payment.payment_status === 'approved' 
                          ? 'outline' 
                          : payment.payment_status === 'rejected'
                            ? 'destructive'
                            : 'secondary'
                      }
                      className={`ml-2 ${
                        payment.payment_status === 'approved' 
                          ? 'bg-green-50 text-green-700 hover:bg-green-50' 
                          : payment.payment_status === 'rejected'
                            ? 'bg-red-50'
                            : 'bg-amber-50 text-amber-700 hover:bg-amber-50'
                      }`}
                    >
                      {payment.payment_status.charAt(0).toUpperCase() + payment.payment_status.slice(1)}
                    </Badge>
                  </div>
                </div>
                
                <div className="flex gap-2">
                  {payment.receipt_file_path && (
                    <Button 
                      variant="outline" 
                      size="sm" 
                      onClick={() => handleViewReceipt(payment)}
                    >
                      View Receipt
                    </Button>
                  )}
                  
                  {payment.payment_status === 'pending' && (
                    <>
                      <Button 
                        variant="outline" 
                        size="sm"
                        className="bg-green-50 text-green-600 hover:bg-green-100 border-green-200"
                        onClick={() => handleApprovePayment(payment)}
                      >
                        <Check className="h-4 w-4 mr-1" />
                        Approve
                      </Button>
                      
                      <Button 
                        variant="outline" 
                        size="sm"
                        className="bg-red-50 text-red-600 hover:bg-red-100 border-red-200"
                        onClick={() => handleRejectPayment(payment)}
                      >
                        <X className="h-4 w-4 mr-1" />
                        Reject
                      </Button>
                    </>
                  )}
                </div>
              </div>
            ))}
          </div>
        )}

        {/* Receipt Viewer Dialog */}
        <Dialog open={viewReceiptOpen} onOpenChange={setViewReceiptOpen}>
          <DialogContent className="max-w-3xl">
            <DialogHeader>
              <DialogTitle>Payment Receipt</DialogTitle>
              <DialogDescription>
                Review the uploaded receipt file
              </DialogDescription>
            </DialogHeader>
            
            {receiptUrl && (
              <div className="mt-4">
                {receiptUrl.includes('.pdf') ? (
                  <div className="flex flex-col items-center justify-center py-4">
                    <p className="mb-2">PDF document</p>
                    <Button asChild>
                      <a href={receiptUrl} target="_blank" rel="noopener noreferrer" className="flex items-center">
                        <ExternalLink className="h-4 w-4 mr-2" />
                        Open PDF
                      </a>
                    </Button>
                  </div>
                ) : (
                  <div className="flex justify-center">
                    <img 
                      src={receiptUrl} 
                      alt="Payment Receipt" 
                      className="max-h-[60vh] object-contain"
                    />
                  </div>
                )}
              </div>
            )}
            
            <DialogFooter>
              <Button 
                variant="outline" 
                onClick={() => setViewReceiptOpen(false)}
              >
                Close
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>

        {/* Approval Confirmation Dialog */}
        <Dialog open={approvalDialogOpen} onOpenChange={setApprovalDialogOpen}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Confirm Payment Approval</DialogTitle>
              <DialogDescription>
                Are you sure you want to approve this payment? This will also approve the school registration.
              </DialogDescription>
            </DialogHeader>
            
            <DialogFooter>
              <Button variant="outline" onClick={() => setApprovalDialogOpen(false)}>
                Cancel
              </Button>
              <Button 
                onClick={confirmApproval}
                className="bg-green-600 hover:bg-green-700"
              >
                Approve
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </CardContent>
    </Card>
  );
};

export default PaymentApprovalList;
