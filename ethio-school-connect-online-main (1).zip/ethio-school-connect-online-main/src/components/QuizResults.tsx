
import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { Award, Clock, User, CalendarDays } from 'lucide-react';

interface QuizResultsProps {
  teacherId: string;
  schoolId: string;
}

const QuizResults: React.FC<QuizResultsProps> = ({ teacherId, schoolId }) => {
  const [results, setResults] = useState<any[]>([]);
  const [quizzes, setQuizzes] = useState<any[]>([]);

  useEffect(() => {
    // Load quiz results
    const resultsString = localStorage.getItem('quizResults');
    const quizResultsData = resultsString ? JSON.parse(resultsString) : [];
    
    // Load quizzes created by this teacher
    const contentString = localStorage.getItem('educationalContent');
    const allContent = contentString ? JSON.parse(contentString) : [];
    const teacherQuizzes = allContent.filter((content: any) => 
      content.type === 'quiz' && 
      content.teacherId === teacherId && 
      content.schoolId === schoolId
    );
    
    setQuizzes(teacherQuizzes);
    
    // Filter results for quizzes created by this teacher
    const teacherQuizIds = teacherQuizzes.map((quiz: any) => quiz.id);
    const relevantResults = quizResultsData.filter((result: any) => 
      teacherQuizIds.includes(result.quizId) && 
      result.schoolId === schoolId
    );
    
    setResults(relevantResults);
  }, [teacherId, schoolId]);

  const formatTime = (seconds: number | null) => {
    if (seconds === null) return 'N/A';
    const minutes = Math.floor(seconds / 60);
    const remainingSeconds = seconds % 60;
    return `${minutes}m ${remainingSeconds}s`;
  };

  const getScoreClass = (percentage: number) => {
    if (percentage >= 80) return 'text-green-600';
    if (percentage >= 60) return 'text-yellow-600';
    return 'text-red-600';
  };

  const getAttemptCount = (studentId: string, quizId: string) => {
    const studentAttempts = results.filter(
      (result) => result.studentId === studentId && result.quizId === quizId
    );
    return studentAttempts.length;
  };

  if (results.length === 0) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Quiz Results</CardTitle>
          <CardDescription>
            No quiz results available yet. When students complete your quizzes, their results will appear here.
          </CardDescription>
        </CardHeader>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Quiz Results</CardTitle>
        <CardDescription>
          View student performance on your quizzes
        </CardDescription>
      </CardHeader>
      <CardContent>
        <div className="rounded-md border">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Student</TableHead>
                <TableHead>Quiz</TableHead>
                <TableHead>Score</TableHead>
                <TableHead>Time Spent</TableHead>
                <TableHead>Attempt #</TableHead>
                <TableHead>Date</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {results.map((result) => (
                <TableRow key={result.id}>
                  <TableCell className="font-medium">
                    <div className="flex items-center space-x-2">
                      <User className="h-4 w-4 text-gray-500" />
                      <span>{result.studentName}</span>
                      {result.grade && <Badge variant="outline" className="ml-1 text-xs">Grade {result.grade}</Badge>}
                      {result.section && <Badge variant="outline" className="ml-1 text-xs">Section {result.section}</Badge>}
                    </div>
                  </TableCell>
                  <TableCell>{result.quizTitle}</TableCell>
                  <TableCell>
                    <div className="flex items-center space-x-2">
                      <Award className="h-4 w-4 text-yellow-500" />
                      <span className={`font-medium ${getScoreClass(result.percentage)}`}>
                        {result.score}/{result.total} ({Math.round(result.percentage)}%)
                      </span>
                    </div>
                  </TableCell>
                  <TableCell>
                    <div className="flex items-center space-x-1">
                      <Clock className="h-4 w-4 text-gray-500" />
                      <span>{formatTime(result.timeSpent)}</span>
                    </div>
                  </TableCell>
                  <TableCell>
                    <Badge variant="secondary">
                      {getAttemptCount(result.studentId, result.quizId)}
                    </Badge>
                  </TableCell>
                  <TableCell>
                    <div className="flex items-center space-x-1">
                      <CalendarDays className="h-4 w-4 text-gray-500" />
                      <span>{new Date(result.completedAt).toLocaleDateString()}</span>
                    </div>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
      </CardContent>
    </Card>
  );
};

export default QuizResults;
