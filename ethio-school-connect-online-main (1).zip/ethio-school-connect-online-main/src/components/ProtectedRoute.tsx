
import { Navigate } from "react-router-dom";
import { useEffect, useState } from "react";
import { toast } from "sonner";

export type ProtectedRouteProps = {
  children: React.ReactNode;
  roles: string[];
};

export const ProtectedRoute = ({ children, roles }: ProtectedRouteProps) => {
  const [currentUser, setCurrentUser] = useState<any>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const userString = localStorage.getItem("currentUser");
    
    if (userString) {
      try {
        const user = JSON.parse(userString);
        setCurrentUser(user);
      } catch (error) {
        console.error("Failed to parse user data:", error);
        localStorage.removeItem("currentUser");
      }
    }
    
    setIsLoading(false);
  }, []);

  if (isLoading) {
    return <div className="flex items-center justify-center h-screen">Loading...</div>;
  }

  if (!currentUser) {
    toast.error("You must be logged in to access this page");
    return <Navigate to="/" />;
  }

  if (!roles.includes(currentUser.role)) {
    toast.error("You do not have permission to access this page");
    
    // Redirect based on role
    if (currentUser.role === "system_admin") {
      return <Navigate to="/admin-dashboard" />;
    } else if (currentUser.role === "admin") {
      return <Navigate to="/school-admin-dashboard" />;
    } else if (currentUser.role === "teacher") {
      return <Navigate to="/teacher-dashboard" />;
    } else if (currentUser.role === "student") {
      return <Navigate to="/student-dashboard" />;
    } else {
      return <Navigate to="/" />;
    }
  }

  return <>{children}</>;
};
