import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { SendHorizontal, User, Shield, School, GraduationCap } from 'lucide-react';
import { toast } from 'sonner';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';

interface Message {
  id: string;
  senderId: string;
  senderName: string;
  recipientId: string;
  content: string;
  timestamp: string;
  read: boolean;
}

interface UserMessagingProps {
  currentUser: any;
  allowedRoles: string[];
}

const UserMessaging: React.FC<UserMessagingProps> = ({ currentUser, allowedRoles }) => {
  const [users, setUsers] = useState<any[]>([]);
  const [selectedUser, setSelectedUser] = useState<any | null>(null);
  const [messages, setMessages] = useState<Message[]>([]);
  const [newMessage, setNewMessage] = useState('');
  const [loading, setLoading] = useState(true);
  const [roleFilter, setRoleFilter] = useState('all');

  useEffect(() => {
    // Load users that match the allowed roles for interaction
    const loadUsers = () => {
      setLoading(true);
      const allUsers: any[] = [];
      
      // Get system admin if needed
      if ((allowedRoles.includes('system_admin') && currentUser.role !== 'system_admin') || 
          (currentUser.role === 'system_admin')) {
        const systemAdminString = localStorage.getItem('systemAdmin');
        if (systemAdminString) {
          const systemAdmin = JSON.parse(systemAdminString);
          systemAdmin.schoolName = 'System Administration';
          // Only add if it's not the current user
          if (systemAdmin.id !== currentUser.id) {
            allUsers.push(systemAdmin);
          }
        }
      }
      
      // Get all schools
      const schoolRegistrationsString = localStorage.getItem('schoolRegistrations');
      if (schoolRegistrationsString) {
        const schoolRegistrations = JSON.parse(schoolRegistrationsString);
        
        // For each school, get users with allowed roles
        schoolRegistrations.forEach((school: any) => {
          if (school.users && Array.isArray(school.users)) {
            const filteredUsers = school.users.filter((user: any) => 
              allowedRoles.includes(user.role) && user.id !== currentUser.id
            ).map((user: any) => ({
              ...user,
              schoolName: school.schoolName
            }));
            
            allUsers.push(...filteredUsers);
          }
        });
      }
      
      setUsers(allUsers);
      setLoading(false);
    };
    
    // Load messages
    const loadMessages = () => {
      const messagesString = localStorage.getItem('userMessages');
      if (messagesString) {
        const allMessages = JSON.parse(messagesString);
        // Filter messages for current user
        const userMessages = allMessages.filter((msg: Message) => 
          msg.senderId === currentUser.id || msg.recipientId === currentUser.id
        );
        setMessages(userMessages);
      }
    };
    
    loadUsers();
    loadMessages();
  }, [currentUser, allowedRoles]);

  const selectUser = (user: any) => {
    setSelectedUser(user);
    
    // Mark messages from this user as read
    const updatedMessages = messages.map(msg => {
      if (msg.senderId === user.id && msg.recipientId === currentUser.id && !msg.read) {
        return { ...msg, read: true };
      }
      return msg;
    });
    
    setMessages(updatedMessages);
    
    // Update localStorage
    const messagesString = localStorage.getItem('userMessages');
    if (messagesString) {
      const allMessages = JSON.parse(messagesString);
      const updatedAllMessages = allMessages.map((msg: Message) => {
        if (msg.senderId === user.id && msg.recipientId === currentUser.id && !msg.read) {
          return { ...msg, read: true };
        }
        return msg;
      });
      
      localStorage.setItem('userMessages', JSON.stringify(updatedAllMessages));
    }
  };

  const sendMessage = () => {
    if (!newMessage.trim() || !selectedUser) return;
    
    const newMsg: Message = {
      id: Date.now().toString(),
      senderId: currentUser.id,
      senderName: currentUser.name || currentUser.username,
      recipientId: selectedUser.id,
      content: newMessage,
      timestamp: new Date().toISOString(),
      read: false
    };
    
    // Add to local state
    setMessages(prev => [...prev, newMsg]);
    
    // Add to localStorage
    const messagesString = localStorage.getItem('userMessages');
    const allMessages = messagesString ? JSON.parse(messagesString) : [];
    allMessages.push(newMsg);
    localStorage.setItem('userMessages', JSON.stringify(allMessages));
    
    // Clear input
    setNewMessage('');
    toast.success('Message sent');
  };

  // Filter users based on selected role
  const filteredUsers = roleFilter === 'all' 
    ? users 
    : users.filter(user => user.role === roleFilter);

  // Filter current conversation messages
  const conversationMessages = selectedUser 
    ? messages.filter(msg => 
        (msg.senderId === currentUser.id && msg.recipientId === selectedUser.id) ||
        (msg.senderId === selectedUser.id && msg.recipientId === currentUser.id)
      ).sort((a, b) => new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime())
    : [];

  // Count unread messages from each user
  const getUnreadCount = (userId: string) => {
    return messages.filter(msg => 
      msg.senderId === userId && 
      msg.recipientId === currentUser.id && 
      !msg.read
    ).length;
  };

  // Get role icon
  const getRoleIcon = (role: string) => {
    switch (role) {
      case 'system_admin':
        return <Shield className="h-4 w-4 text-ethio-error" />;
      case 'admin':
        return <School className="h-4 w-4 text-ethio-primary" />;
      case 'teacher':
        return <User className="h-4 w-4 text-ethio-secondary" />;
      case 'student':
        return <GraduationCap className="h-4 w-4 text-ethio-accent" />;
      default:
        return <User className="h-4 w-4" />;
    }
  };

  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-4 h-[500px]">
      <Card className="md:col-span-1 h-full">
        <CardHeader className="pb-2">
          <CardTitle className="flex items-center justify-between">
            <span>Contacts</span>
            <Select value={roleFilter} onValueChange={setRoleFilter}>
              <SelectTrigger className="w-[120px]">
                <SelectValue placeholder="Filter by role" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Roles</SelectItem>
                <SelectItem value="system_admin">System Admin</SelectItem>
                <SelectItem value="admin">School Admin</SelectItem>
                <SelectItem value="teacher">Teacher</SelectItem>
                <SelectItem value="student">Student</SelectItem>
              </SelectContent>
            </Select>
          </CardTitle>
        </CardHeader>
        <CardContent className="overflow-y-auto h-[calc(100%-5rem)]">
          {loading ? (
            <div className="text-center py-10">Loading contacts...</div>
          ) : filteredUsers.length === 0 ? (
            <div className="text-center py-10 text-gray-500">
              No users available to message.
            </div>
          ) : (
            <div className="space-y-2">
              {filteredUsers.map(user => (
                <div 
                  key={user.id}
                  className={`flex items-center p-2 rounded-md cursor-pointer transition-colors hover:bg-gray-100 ${
                    selectedUser?.id === user.id ? 'bg-gray-100' : ''
                  }`}
                  onClick={() => selectUser(user)}
                >
                  <Avatar className="h-10 w-10 mr-3 border-2 border-white shadow-sm">
                    <AvatarFallback className="bg-gradient-to-br from-ethio-primary to-ethio-accent text-white">
                      {user.name?.substring(0, 2).toUpperCase() || 'U'}
                    </AvatarFallback>
                  </Avatar>
                  <div className="flex-1">
                    <div className="flex items-center">
                      <p className="font-medium">{user.name || user.username}</p>
                      <span className="ml-2">{getRoleIcon(user.role)}</span>
                    </div>
                    <p className="text-xs text-gray-500">{user.schoolName || 'Unknown School'}</p>
                  </div>
                  {getUnreadCount(user.id) > 0 && (
                    <span className="bg-ethio-primary text-white text-xs font-bold rounded-full h-5 w-5 flex items-center justify-center">
                      {getUnreadCount(user.id)}
                    </span>
                  )}
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
      
      <Card className="md:col-span-2 h-full flex flex-col">
        <CardHeader className="pb-2">
          <CardTitle>
            {selectedUser ? (
              <div className="flex items-center">
                <Avatar className="h-8 w-8 mr-2 border-2 border-white shadow-sm">
                  <AvatarFallback className="bg-gradient-to-br from-ethio-primary to-ethio-accent text-white">
                    {selectedUser.name?.substring(0, 2).toUpperCase() || 'U'}
                  </AvatarFallback>
                </Avatar>
                <div>
                  <div className="flex items-center">
                    <p>{selectedUser.name || selectedUser.username}</p>
                    <span className="ml-2">{getRoleIcon(selectedUser.role)}</span>
                  </div>
                  <p className="text-xs text-gray-500">{selectedUser.schoolName || 'Unknown School'}</p>
                </div>
              </div>
            ) : 'Select a user to start messaging'}
          </CardTitle>
        </CardHeader>
        <CardContent className="flex-1 overflow-y-auto pb-0 flex flex-col">
          {!selectedUser ? (
            <div className="flex flex-col items-center justify-center h-full text-gray-500">
              <User className="h-12 w-12 mx-auto mb-3 text-gray-400" />
              <p>Select a user to start a conversation</p>
            </div>
          ) : conversationMessages.length === 0 ? (
            <div className="flex items-center justify-center h-full text-gray-500">
              <p>No messages yet. Start the conversation!</p>
            </div>
          ) : (
            <div className="space-y-3 flex-1 p-2">
              {conversationMessages.map(msg => (
                <div 
                  key={msg.id} 
                  className={`flex ${msg.senderId === currentUser.id ? 'justify-end' : 'justify-start'}`}
                >
                  <div 
                    className={`max-w-[70%] p-3 rounded-lg ${
                      msg.senderId === currentUser.id 
                        ? 'bg-ethio-primary text-white rounded-br-none' 
                        : 'bg-gray-100 rounded-bl-none'
                    }`}
                  >
                    <p>{msg.content}</p>
                    <p className={`text-xs mt-1 ${
                      msg.senderId === currentUser.id ? 'text-white/80' : 'text-gray-500'
                    }`}>
                      {new Date(msg.timestamp).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          )}
          
          {selectedUser && (
            <div className="py-3 border-t mt-auto">
              <div className="flex gap-2">
                <Input
                  placeholder="Type your message..."
                  value={newMessage}
                  onChange={(e) => setNewMessage(e.target.value)}
                  onKeyDown={(e) => e.key === 'Enter' && sendMessage()}
                  className="flex-1"
                />
                <Button onClick={sendMessage} disabled={!newMessage.trim()} 
                  className="bg-ethio-primary hover:bg-ethio-primary/90">
                  <SendHorizontal className="h-4 w-4" />
                  <span className="sr-only">Send</span>
                </Button>
              </div>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
};

export default UserMessaging;
