
import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Switch } from '@/components/ui/switch';
import { Badge } from '@/components/ui/badge';
import { toast } from 'sonner';
import { supabase } from '@/integrations/supabase/client';
import { CreditCard, PlusCircle, Pencil, Trash2 } from 'lucide-react';

interface PaymentMethod {
  id: string;
  bank_name: string;
  account_number: string;
  account_name: string;
  is_telebirr: boolean;
  created_at: string;
}

const PaymentSettings = () => {
  const [paymentMethods, setPaymentMethods] = useState<PaymentMethod[]>([]);
  const [loading, setLoading] = useState(true);
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);
  const [selectedMethod, setSelectedMethod] = useState<PaymentMethod | null>(null);
  const [formData, setFormData] = useState({
    bank_name: '',
    account_number: '',
    account_name: '',
    is_telebirr: false
  });

  useEffect(() => {
    fetchPaymentMethods();
  }, []);

  const fetchPaymentMethods = async () => {
    setLoading(true);
    try {
      const { data, error } = await supabase
        .from('payment_settings')
        .select('*')
        .order('created_at', { ascending: true });
        
      if (error) {
        console.error('Error fetching payment methods:', error);
        toast.error('Failed to load payment settings');
      } else {
        setPaymentMethods(data || []);
      }
    } catch (error) {
      console.error('Error:', error);
      toast.error('An error occurred while fetching payment settings');
    } finally {
      setLoading(false);
    }
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSwitchChange = (checked: boolean) => {
    setFormData(prev => ({ ...prev, is_telebirr: checked }));
  };

  const resetForm = () => {
    setFormData({
      bank_name: '',
      account_number: '',
      account_name: '',
      is_telebirr: false
    });
    setSelectedMethod(null);
  };

  const handleAdd = async () => {
    if (!formData.bank_name || !formData.account_number || !formData.account_name) {
      toast.error('Please fill in all required fields');
      return;
    }
    
    try {
      const { error } = await supabase
        .from('payment_settings')
        .insert({
          bank_name: formData.bank_name,
          account_number: formData.account_number,
          account_name: formData.account_name,
          is_telebirr: formData.is_telebirr
        });
        
      if (error) {
        console.error('Error adding payment method:', error);
        toast.error('Failed to add payment method');
        return;
      }
      
      toast.success('Payment method added successfully');
      resetForm();
      setIsAddDialogOpen(false);
      fetchPaymentMethods();
    } catch (error) {
      console.error('Error:', error);
      toast.error('An error occurred');
    }
  };

  const handleEdit = (method: PaymentMethod) => {
    setSelectedMethod(method);
    setFormData({
      bank_name: method.bank_name,
      account_number: method.account_number,
      account_name: method.account_name,
      is_telebirr: method.is_telebirr
    });
    setIsEditDialogOpen(true);
  };

  const handleUpdate = async () => {
    if (!selectedMethod) return;
    
    if (!formData.bank_name || !formData.account_number || !formData.account_name) {
      toast.error('Please fill in all required fields');
      return;
    }
    
    try {
      const { error } = await supabase
        .from('payment_settings')
        .update({
          bank_name: formData.bank_name,
          account_number: formData.account_number,
          account_name: formData.account_name,
          is_telebirr: formData.is_telebirr,
          updated_at: new Date().toISOString()
        })
        .eq('id', selectedMethod.id);
        
      if (error) {
        console.error('Error updating payment method:', error);
        toast.error('Failed to update payment method');
        return;
      }
      
      toast.success('Payment method updated successfully');
      resetForm();
      setIsEditDialogOpen(false);
      fetchPaymentMethods();
    } catch (error) {
      console.error('Error:', error);
      toast.error('An error occurred');
    }
  };

  const handleDelete = async (id: string) => {
    if (!confirm('Are you sure you want to delete this payment method?')) return;
    
    try {
      const { error } = await supabase
        .from('payment_settings')
        .delete()
        .eq('id', id);
        
      if (error) {
        console.error('Error deleting payment method:', error);
        toast.error('Failed to delete payment method');
        return;
      }
      
      toast.success('Payment method deleted successfully');
      fetchPaymentMethods();
    } catch (error) {
      console.error('Error:', error);
      toast.error('An error occurred');
    }
  };

  const renderForm = () => (
    <div className="space-y-4">
      <div className="space-y-2">
        <Label htmlFor="bank_name">Bank/Service Name *</Label>
        <Input
          id="bank_name"
          name="bank_name"
          value={formData.bank_name}
          onChange={handleInputChange}
          placeholder="Enter bank or service name"
        />
      </div>
      
      <div className="space-y-2">
        <Label htmlFor="account_name">Account Name *</Label>
        <Input
          id="account_name"
          name="account_name"
          value={formData.account_name}
          onChange={handleInputChange}
          placeholder="Enter account name"
        />
      </div>
      
      <div className="space-y-2">
        <Label htmlFor="account_number">Account/Phone Number *</Label>
        <Input
          id="account_number"
          name="account_number"
          value={formData.account_number}
          onChange={handleInputChange}
          placeholder="Enter account or phone number"
        />
      </div>
      
      <div className="flex items-center space-x-2">
        <Switch
          id="is_telebirr"
          checked={formData.is_telebirr}
          onCheckedChange={handleSwitchChange}
        />
        <Label htmlFor="is_telebirr">This is a TeleBirr account</Label>
      </div>
    </div>
  );

  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between">
        <div>
          <CardTitle>Payment Methods</CardTitle>
          <CardDescription>Manage bank accounts and TeleBirr numbers for school payments</CardDescription>
        </div>
        <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
          <DialogTrigger asChild>
            <Button className="flex items-center gap-2" onClick={() => resetForm()}>
              <PlusCircle className="h-4 w-4" />
              Add Payment Method
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Add Payment Method</DialogTitle>
              <DialogDescription>
                Add a new bank account or TeleBirr number for school registration payments
              </DialogDescription>
            </DialogHeader>
            
            {renderForm()}
            
            <DialogFooter>
              <Button variant="outline" onClick={() => setIsAddDialogOpen(false)}>
                Cancel
              </Button>
              <Button onClick={handleAdd}>
                Add Payment Method
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </CardHeader>
      <CardContent>
        {loading ? (
          <div className="text-center py-8">
            <p>Loading payment methods...</p>
          </div>
        ) : paymentMethods.length === 0 ? (
          <div className="text-center py-8 text-gray-500">
            <CreditCard className="h-12 w-12 mx-auto mb-3 text-gray-400" />
            <p>No payment methods configured</p>
            <p className="text-sm mt-2">Add a payment method to accept school registration payments</p>
          </div>
        ) : (
          <div className="space-y-4">
            {paymentMethods.map((method) => (
              <div key={method.id} className="flex items-start justify-between border-b pb-4">
                <div>
                  <h3 className="font-medium flex items-center">
                    {method.bank_name}
                    {method.is_telebirr && (
                      <Badge className="ml-2 bg-blue-100 text-blue-800 hover:bg-blue-100">
                        TeleBirr
                      </Badge>
                    )}
                  </h3>
                  <p className="text-sm text-gray-500">Account: {method.account_name}</p>
                  <p className="text-sm text-gray-500">
                    {method.is_telebirr ? "Phone" : "Account"} Number: {method.account_number}
                  </p>
                </div>
                
                <div className="flex gap-2">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => handleEdit(method)}
                  >
                    <Pencil className="h-4 w-4 mr-1" />
                    Edit
                  </Button>
                  
                  <Button
                    variant="outline"
                    size="sm"
                    className="text-red-600 hover:bg-red-50"
                    onClick={() => handleDelete(method.id)}
                  >
                    <Trash2 className="h-4 w-4 mr-1" />
                    Delete
                  </Button>
                </div>
              </div>
            ))}
          </div>
        )}

        {/* Edit Dialog */}
        <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Edit Payment Method</DialogTitle>
              <DialogDescription>
                Update the details for this payment method
              </DialogDescription>
            </DialogHeader>
            
            {renderForm()}
            
            <DialogFooter>
              <Button variant="outline" onClick={() => setIsEditDialogOpen(false)}>
                Cancel
              </Button>
              <Button onClick={handleUpdate}>
                Update Payment Method
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </CardContent>
    </Card>
  );
};

export default PaymentSettings;
