
import React from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { School, LogOut, MessageSquare, HelpCircle } from 'lucide-react';
import LanguageSelector from './LanguageSelector';
import { useLanguage } from '@/contexts/LanguageContext';

const Header = () => {
  const navigate = useNavigate();
  const { t } = useLanguage();
  const currentUserString = localStorage.getItem('currentUser');
  const currentUser = currentUserString ? JSON.parse(currentUserString) : null;

  const handleLogout = () => {
    localStorage.removeItem('currentUser');
    navigate('/');
  };

  const getDashboardLink = () => {
    if (!currentUser) return '/';
    
    switch (currentUser.role) {
      case 'system_admin':
        return '/admin-dashboard';
      case 'admin':
        return '/school-admin-dashboard';
      case 'teacher':
        return '/teacher-dashboard';
      case 'student':
        return '/student-dashboard';
      default:
        return '/';
    }
  };

  return (
    <header className="bg-white shadow-sm border-b border-gray-200">
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between h-16">
          <Link to={getDashboardLink()} className="flex items-center space-x-2">
            <School className="h-8 w-8 text-ethio-primary" />
            <span className="font-bold text-xl text-gray-900">{t('ethio_schools_online')}</span>
          </Link>
          
          <div className="flex items-center space-x-4">
            {currentUser ? (
              <>
                <span className="text-sm font-medium text-gray-700">
                  {t('welcome')}, {currentUser.name || currentUser.username}
                  {currentUser.schoolName && (
                    <span className="ml-1 text-xs text-ethio-secondary">
                      ({currentUser.schoolName})
                    </span>
                  )}
                </span>
                
                {currentUser.role === 'teacher' && (
                  <Link to="/content-upload">
                    <Button variant="outline" size="sm">{t('upload_content')}</Button>
                  </Link>
                )}
                
                <Link to="/content-library">
                  <Button variant="outline" size="sm">{t('content_library')}</Button>
                </Link>
                
                <Link to="/communication">
                  <Button variant="outline" size="sm" className="flex items-center gap-1">
                    <MessageSquare className="h-4 w-4" />
                    <span>{t('messages')}</span>
                  </Button>
                </Link>
                
                {currentUser.role === 'admin' && (
                  <Link to="/manage-users">
                    <Button variant="outline" size="sm">{t('manage_users')}</Button>
                  </Link>
                )}
                
                <Link to="/about">
                  <Button variant="outline" size="sm" className="flex items-center gap-1">
                    <HelpCircle className="h-4 w-4" />
                    <span>Help</span>
                  </Button>
                </Link>
                
                <LanguageSelector />
                
                <Button 
                  variant="ghost" 
                  size="sm" 
                  onClick={handleLogout}
                  className="text-gray-700 hover:text-ethio-error"
                >
                  <LogOut className="h-4 w-4 mr-1" />
                  {t('logout')}
                </Button>
              </>
            ) : (
              <div className="flex space-x-2">
                <Link to="/register-school">
                  <Button variant="outline" size="sm">{t('register_school')}</Button>
                </Link>
                <Link to="/">
                  <Button size="sm">{t('login')}</Button>
                </Link>
                <Link to="/about">
                  <Button variant="outline" size="sm" className="flex items-center gap-1">
                    <HelpCircle className="h-4 w-4" />
                    <span>About</span>
                  </Button>
                </Link>
                <LanguageSelector />
              </div>
            )}
          </div>
        </div>
      </div>
    </header>
  );
};

export default Header;
