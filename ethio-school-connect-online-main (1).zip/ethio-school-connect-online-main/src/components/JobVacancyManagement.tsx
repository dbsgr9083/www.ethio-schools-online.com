import React, { useState, useEffect } from 'react';
import { Card, CardHeader, CardTitle, CardDescription, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { toast } from 'sonner';
import { v4 as uuidv4 } from 'uuid';
import { Briefcase, Plus, Trash2, PenLine, ChevronDown, ChevronUp } from 'lucide-react';

type JobVacancyProps = {
  currentUser: any;
  viewOnly?: boolean;
  onSelect?: (vacancy: any) => void;
};

const JobVacancyManagement = ({ currentUser, viewOnly = false, onSelect }: JobVacancyProps) => {
  const [vacancies, setVacancies] = useState<any[]>([]);
  const [newVacancy, setNewVacancy] = useState({
    id: '',
    title: '',
    description: '',
    requirements: '',
    location: '',
    salary: '',
    type: 'full-time',
    schoolId: currentUser.schoolId,
    schoolName: currentUser.schoolName,
    createdAt: new Date().toISOString()
  });
  const [editingVacancyId, setEditingVacancyId] = useState<string | null>(null);
  const [expandedVacancyId, setExpandedVacancyId] = useState<string | null>(null);

  useEffect(() => {
    loadVacancies();
  }, []);

  const loadVacancies = () => {
    const storedVacancies = localStorage.getItem('jobVacancies');
    if (storedVacancies) {
      const allVacancies = JSON.parse(storedVacancies);
      const filteredVacancies = viewOnly ? allVacancies : allVacancies.filter((vacancy: any) => vacancy.schoolId === currentUser.schoolId);
      setVacancies(filteredVacancies);
    }
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setNewVacancy(prev => ({ ...prev, [name]: value }));
  };

  const handleSelectChange = (value: string) => {
    setNewVacancy(prev => ({ ...prev, type: value }));
  };

  const addVacancy = () => {
    if (!newVacancy.title || !newVacancy.description || !newVacancy.requirements || !newVacancy.location || !newVacancy.salary) {
      toast.error("Please fill in all fields");
      return;
    }

    const vacancyToAdd = { ...newVacancy, id: uuidv4() };
    const storedVacancies = localStorage.getItem('jobVacancies');
    const existingVacancies = storedVacancies ? JSON.parse(storedVacancies) : [];
    const updatedVacancies = [...existingVacancies, vacancyToAdd];
    localStorage.setItem('jobVacancies', JSON.stringify(updatedVacancies));
    loadVacancies();
    setNewVacancy({
      id: '',
      title: '',
      description: '',
      requirements: '',
      location: '',
      salary: '',
      type: 'full-time',
      schoolId: currentUser.schoolId,
      schoolName: currentUser.schoolName,
      createdAt: new Date().toISOString()
    });
    toast.success("Job vacancy added successfully");
  };

  const startEditing = (vacancyId: string) => {
    setEditingVacancyId(vacancyId);
    const vacancyToEdit = vacancies.find(vacancy => vacancy.id === vacancyId);
    if (vacancyToEdit) {
      setNewVacancy(vacancyToEdit);
    }
  };

  const cancelEditing = () => {
    setEditingVacancyId(null);
    setNewVacancy({
      id: '',
      title: '',
      description: '',
      requirements: '',
      location: '',
      salary: '',
      type: 'full-time',
      schoolId: currentUser.schoolId,
      schoolName: currentUser.schoolName,
      createdAt: new Date().toISOString()
    });
  };

  const updateVacancy = () => {
    if (!newVacancy.title || !newVacancy.description || !newVacancy.requirements || !newVacancy.location || !newVacancy.salary) {
      toast.error("Please fill in all fields");
      return;
    }

    const storedVacancies = localStorage.getItem('jobVacancies');
    if (storedVacancies) {
      const existingVacancies = JSON.parse(storedVacancies);
      const updatedVacancies = existingVacancies.map((vacancy: any) =>
        vacancy.id === newVacancy.id ? newVacancy : vacancy
      );
      localStorage.setItem('jobVacancies', JSON.stringify(updatedVacancies));
      loadVacancies();
      setEditingVacancyId(null);
      setNewVacancy({
        id: '',
        title: '',
        description: '',
        requirements: '',
        location: '',
        salary: '',
        type: 'full-time',
        schoolId: currentUser.schoolId,
        schoolName: currentUser.schoolName,
        createdAt: new Date().toISOString()
      });
      toast.success("Job vacancy updated successfully");
    }
  };

  const deleteVacancy = (vacancyId: string) => {
    const storedVacancies = localStorage.getItem('jobVacancies');
    if (storedVacancies) {
      const existingVacancies = JSON.parse(storedVacancies);
      const updatedVacancies = existingVacancies.filter((vacancy: any) => vacancy.id !== vacancyId);
      localStorage.setItem('jobVacancies', JSON.stringify(updatedVacancies));
      loadVacancies();
      toast.success("Job vacancy deleted successfully");
    }
  };

  const toggleVacancyExpansion = (vacancyId: string) => {
    setExpandedVacancyId(expandedVacancyId === vacancyId ? null : vacancyId);
  };

  const vacancyTypeOptions = [
    { value: 'full-time', label: 'Full-time' },
    { value: 'part-time', label: 'Part-time' },
    { value: 'contract', label: 'Contract' },
    { value: 'temporary', label: 'Temporary' },
    { value: 'internship', label: 'Internship' }
  ];

  return (
    <div className="space-y-4">
      {!viewOnly && (
        <Card>
          <CardHeader>
            <CardTitle>Add Job Vacancy</CardTitle>
            <CardDescription>Post a new job opening at your school</CardDescription>
          </CardHeader>
          <CardContent className="grid gap-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <Label htmlFor="title">Title</Label>
                <Input
                  id="title"
                  name="title"
                  value={newVacancy.title}
                  onChange={handleInputChange}
                  placeholder="Job Title"
                />
              </div>
              <div>
                <Label htmlFor="location">Location</Label>
                <Input
                  id="location"
                  name="location"
                  value={newVacancy.location}
                  onChange={handleInputChange}
                  placeholder="Location"
                />
              </div>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <Label htmlFor="salary">Salary</Label>
                <Input
                  id="salary"
                  name="salary"
                  value={newVacancy.salary}
                  onChange={handleInputChange}
                  placeholder="Salary"
                />
              </div>
              <div>
                <Label htmlFor="type">Type</Label>
                <Select onValueChange={handleSelectChange} defaultValue={newVacancy.type}>
                  <SelectTrigger className="w-full">
                    <SelectValue placeholder="Select type" />
                  </SelectTrigger>
                  <SelectContent>
                    {vacancyTypeOptions.map((option) => (
                      <SelectItem key={option.value} value={option.value}>
                        {option.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div>
              <Label htmlFor="description">Description</Label>
              <Textarea
                id="description"
                name="description"
                value={newVacancy.description}
                onChange={handleInputChange}
                placeholder="Job Description"
              />
            </div>
            <div>
              <Label htmlFor="requirements">Requirements</Label>
              <Textarea
                id="requirements"
                name="requirements"
                value={newVacancy.requirements}
                onChange={handleInputChange}
                placeholder="Job Requirements"
              />
            </div>
            {editingVacancyId ? (
              <div className="flex justify-end gap-2">
                <Button variant="ghost" onClick={cancelEditing}>
                  Cancel
                </Button>
                <Button onClick={updateVacancy}>Update Vacancy</Button>
              </div>
            ) : (
              <Button onClick={addVacancy}>Add Vacancy</Button>
            )}
          </CardContent>
        </Card>
      )}

      <Card>
        <CardHeader>
          <CardTitle>Job Vacancies</CardTitle>
          <CardDescription>List of job openings at {currentUser.schoolName}</CardDescription>
        </CardHeader>
        <CardContent>
          {vacancies.length === 0 ? (
            <div className="text-center py-4">
              <Briefcase className="h-6 w-6 mx-auto mb-2 text-gray-400" />
              <p className="text-gray-500">No job vacancies found.</p>
            </div>
          ) : (
            <div className="space-y-4">
              {vacancies.map((vacancy) => (
                <Card key={vacancy.id} className="border">
                  <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                    <CardTitle className="text-sm font-medium">{vacancy.title}</CardTitle>
                    <div className="flex items-center space-x-2">
                      {!viewOnly && (
                        <>
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => startEditing(vacancy.id)}
                          >
                            <PenLine className="h-4 w-4 mr-2" />
                            Edit
                          </Button>
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => deleteVacancy(vacancy.id)}
                          >
                            <Trash2 className="h-4 w-4 mr-2" />
                            Delete
                          </Button>
                        </>
                      )}
                      {onSelect && (
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => onSelect(vacancy)}
                        >
                          Select
                        </Button>
                      )}
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => toggleVacancyExpansion(vacancy.id)}
                      >
                        {expandedVacancyId === vacancy.id ? (
                          <ChevronUp className="h-4 w-4" />
                        ) : (
                          <ChevronDown className="h-4 w-4" />
                        )}
                      </Button>
                    </div>
                  </CardHeader>
                  {expandedVacancyId === vacancy.id && (
                    <CardContent className="pl-4 pt-0">
                      <div className="space-y-2">
                        <p className="text-sm text-gray-500">
                          <span className="font-semibold">Location:</span> {vacancy.location}
                        </p>
                        <p className="text-sm text-gray-500">
                          <span className="font-semibold">Salary:</span> {vacancy.salary}
                        </p>
                        <p className="text-sm text-gray-500">
                          <span className="font-semibold">Type:</span> {vacancy.type}
                        </p>
                        <p className="text-sm text-gray-500">
                          <span className="font-semibold">Description:</span> {vacancy.description}
                        </p>
                        <p className="text-sm text-gray-500">
                          <span className="font-semibold">Requirements:</span> {vacancy.requirements}
                        </p>
                      </div>
                    </CardContent>
                  )}
                </Card>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
};

export default JobVacancyManagement;
