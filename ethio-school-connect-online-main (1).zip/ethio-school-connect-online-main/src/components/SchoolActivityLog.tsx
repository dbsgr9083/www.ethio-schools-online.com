
import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { User, Clock, FileText, Pencil, Video, GraduationCap } from 'lucide-react';

interface SchoolActivityLogProps {
  schoolId: string;
}

const SchoolActivityLog: React.FC<SchoolActivityLogProps> = ({ schoolId }) => {
  const [activities, setActivities] = useState<any[]>([]);

  useEffect(() => {
    // Fetch all relevant activity data
    const quizResultsString = localStorage.getItem('quizResults');
    const quizResults = quizResultsString ? JSON.parse(quizResultsString) : [];
    
    const contentString = localStorage.getItem('educationalContent');
    const content = contentString ? JSON.parse(contentString) : [];
    
    // Filter for activities in this school
    const schoolQuizResults = quizResults.filter((result: any) => result.schoolId === schoolId);
    
    // Transform quiz results into activity items
    const quizActivities = schoolQuizResults.map((result: any) => ({
      id: result.id,
      type: 'quiz_completed',
      title: `Quiz Completed: ${result.quizTitle}`,
      userRole: 'student',
      userName: result.studentName,
      userId: result.studentId,
      details: `Score: ${result.score}/${result.total} (${Math.round(result.percentage)}%)`,
      timestamp: result.completedAt
    }));
    
    // Transform content creation into activity items
    const schoolContent = content.filter((item: any) => item.schoolId === schoolId);
    const contentActivities = schoolContent.map((item: any) => ({
      id: item.id,
      type: `${item.type}_created`,
      title: `${item.type.charAt(0).toUpperCase() + item.type.slice(1)} Created: ${item.title}`,
      userRole: 'teacher',
      userName: item.teacherName,
      userId: item.teacherId,
      details: item.subject ? `${item.subject} - Grade ${item.grade || 'N/A'}` : '',
      timestamp: item.createdAt
    }));
    
    // Combine all activities and sort by timestamp
    const allActivities = [...quizActivities, ...contentActivities].sort((a, b) => 
      new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime()
    );
    
    setActivities(allActivities.slice(0, 20)); // Only show last 20 activities
  }, [schoolId]);

  const getActivityIcon = (type: string) => {
    if (type === 'quiz_completed') return <Pencil className="h-4 w-4 text-ethio-warning" />;
    if (type === 'quiz_created') return <FileText className="h-4 w-4 text-ethio-warning" />;
    if (type === 'note_created') return <FileText className="h-4 w-4 text-ethio-primary" />;
    if (type === 'video_created') return <Video className="h-4 w-4 text-ethio-accent" />;
    return <Clock className="h-4 w-4 text-gray-500" />;
  };

  const getUserIcon = (role: string) => {
    if (role === 'teacher') return <User className="h-4 w-4 text-ethio-primary" />;
    if (role === 'student') return <GraduationCap className="h-4 w-4 text-ethio-accent" />;
    return <User className="h-4 w-4 text-gray-500" />;
  };

  if (activities.length === 0) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>School Activity Log</CardTitle>
          <CardDescription>
            No activities recorded yet. Activities will appear here as teachers upload content and students complete quizzes.
          </CardDescription>
        </CardHeader>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>School Activity Log</CardTitle>
        <CardDescription>
          Recent activity from teachers and students
        </CardDescription>
      </CardHeader>
      <CardContent>
        <div className="rounded-md border">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Activity</TableHead>
                <TableHead>User</TableHead>
                <TableHead>Details</TableHead>
                <TableHead>Date</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {activities.map((activity) => (
                <TableRow key={activity.id + activity.type}>
                  <TableCell className="font-medium">
                    <div className="flex items-center space-x-2">
                      {getActivityIcon(activity.type)}
                      <span>{activity.title}</span>
                    </div>
                  </TableCell>
                  <TableCell>
                    <div className="flex items-center space-x-2">
                      {getUserIcon(activity.userRole)}
                      <span>{activity.userName}</span>
                      <Badge variant="outline" className="capitalize text-xs">
                        {activity.userRole}
                      </Badge>
                    </div>
                  </TableCell>
                  <TableCell>{activity.details}</TableCell>
                  <TableCell>{new Date(activity.timestamp).toLocaleDateString()}</TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
      </CardContent>
    </Card>
  );
};

export default SchoolActivityLog;
