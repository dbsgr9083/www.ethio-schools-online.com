
import { Route, Routes } from 'react-router-dom';
import './App.css';
import Index from './pages/Index';
import NotFound from './pages/NotFound';
import { ProtectedRoute } from './components/ProtectedRoute';
import { Toaster } from './components/ui/sonner';
import ManageUsers from './pages/ManageUsers';
import RegisterSchool from './pages/RegisterSchool';
import ManageSchools from './pages/ManageSchools';
import PendingSchools from './pages/PendingSchools';
import SchoolAdminDashboard from './pages/SchoolAdminDashboard';
import AdminDashboard from './pages/AdminDashboard';
import TeacherDashboard from './pages/TeacherDashboard';
import StudentDashboard from './pages/StudentDashboard';
import ContentUpload from './pages/ContentUpload';
import ContentLibrary from './pages/ContentLibrary';
import Communication from './pages/Communication';
import ViewQuiz from './pages/ViewQuiz';
import ViewNote from './pages/ViewNote';
import BookLibrary from './pages/BookLibrary';
import About from './pages/About';
import PaymentSettingsPage from './pages/PaymentSettingsPage';
import { LanguageProvider } from './contexts/LanguageContext';

function App() {
  return (
    <LanguageProvider>
      <Routes>
        <Route path="/" element={<Index />} />
        <Route path="/manage-users" element={<ProtectedRoute roles={['system_admin', 'admin']}><ManageUsers /></ProtectedRoute>} />
        <Route path="/register-school" element={<RegisterSchool />} />
        <Route path="/manage-schools" element={<ProtectedRoute roles={['system_admin']}><ManageSchools /></ProtectedRoute>} />
        <Route path="/pending-schools" element={<ProtectedRoute roles={['system_admin']}><PendingSchools /></ProtectedRoute>} />
        <Route path="/payment-settings" element={<ProtectedRoute roles={['system_admin']}><PaymentSettingsPage /></ProtectedRoute>} />
        <Route path="/school-admin-dashboard" element={<ProtectedRoute roles={['admin']}><SchoolAdminDashboard /></ProtectedRoute>} />
        <Route path="/admin-dashboard" element={<ProtectedRoute roles={['system_admin']}><AdminDashboard /></ProtectedRoute>} />
        <Route path="/teacher-dashboard" element={<ProtectedRoute roles={['teacher']}><TeacherDashboard /></ProtectedRoute>} />
        <Route path="/student-dashboard" element={<ProtectedRoute roles={['student']}><StudentDashboard /></ProtectedRoute>} />
        <Route path="/content-upload" element={<ProtectedRoute roles={['teacher']}><ContentUpload /></ProtectedRoute>} />
        <Route path="/content-library" element={<ProtectedRoute roles={['system_admin', 'admin', 'teacher', 'student']}><ContentLibrary /></ProtectedRoute>} />
        <Route path="/book-library" element={<ProtectedRoute roles={['system_admin', 'admin', 'teacher', 'student']}><BookLibrary /></ProtectedRoute>} />
        <Route path="/communication" element={<ProtectedRoute roles={['system_admin', 'admin', 'teacher', 'student']}><Communication /></ProtectedRoute>} />
        <Route path="/view-quiz/:quizId" element={<ProtectedRoute roles={['system_admin', 'admin', 'teacher', 'student']}><ViewQuiz /></ProtectedRoute>} />
        <Route path="/view-note/:noteId" element={<ProtectedRoute roles={['system_admin', 'admin', 'teacher', 'student']}><ViewNote /></ProtectedRoute>} />
        <Route path="/about" element={<About />} />
        <Route path="*" element={<NotFound />} />
      </Routes>
      <Toaster />
    </LanguageProvider>
  );
}

export default App;
